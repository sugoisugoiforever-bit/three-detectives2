#!/usr/bin/env bash
# يبني APK محلياً. المتطلبات: JDK 17 وAndroid SDK (متغير ANDROID_HOME أو ملف local.properties).
# الاستعمال:  ./build-apk.sh        ← الناتج: dist/ThreeDetectives.apk
set -euo pipefail
cd "$(dirname "$0")"

if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ] && [ ! -f local.properties ]; then
  echo "لم أجد Android SDK. ثبّت Android Studio (يثبّت الـ SDK) أو اضبط ANDROID_HOME،"
  echo "أو افتح المجلد في Android Studio واختر Build > Build APK(s)."
  exit 1
fi
if ! command -v java >/dev/null 2>&1; then
  echo "لم أجد Java. ثبّت JDK 17."
  exit 1
fi

chmod +x gradlew
./gradlew :engine:selfTest :app:assembleRelease
mkdir -p dist
cp app/build/outputs/apk/release/*.apk dist/ThreeDetectives.apk
echo "تم: dist/ThreeDetectives.apk"
