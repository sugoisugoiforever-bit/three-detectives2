"""مولّد أرقام عشوائية حتمي: نفس (السمة، البذرة) يعطي نفس القضية دائماً."""
import random


class Rng:
    def __init__(self, *parts):
        self.r = random.Random("|".join(str(p) for p in parts))

    def pick(self, seq):
        return seq[self.r.randrange(len(seq))]

    def shuffle(self, seq):
        s = list(seq)
        self.r.shuffle(s)
        return s

    def sample(self, seq, k):
        return self.r.sample(list(seq), k)

    def rint(self, a, b):
        return self.r.randint(a, b)

    def chance(self, p):
        return self.r.random() < p


def fmt_time(minutes):
    minutes %= 24 * 60
    return "%02d:%02d" % (minutes // 60, minutes % 60)


def parse_time(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)
