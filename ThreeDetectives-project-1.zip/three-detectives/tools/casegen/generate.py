# -*- coding: utf-8 -*-
"""مولّد القضايا (بناء عكسي): الحقيقة أولاً ← الأسئلة ← الوثائق ← التشويش."""
import datetime
import json
import sys

from rng import Rng, fmt_time
from pools import (MALE, FEMALE, SURNAMES, PORTRAITS_M, PORTRAITS_F, VENUES, STAMPS, MONTHS,
                   WEEKDAYS, WITNESS_NAMES, NOISE_DOCS)
from forms import FORMS, FORM_TITLES, money
from gen_core import Ctx, DocB, fill
from content_motives import MOTIVES
from content_who import KEY_TYPES, NOISE_TEXT, witness_decoy, alibi
import theme_museum
import theme_techco
import theme_warehouse

THEMES = {m.THEME["id"]: m.THEME for m in (theme_museum, theme_techco, theme_warehouse)}
ROLES = ["analyst", "field", "comms"]
ROLE_VAR = {"analyst": "fin", "field": "field", "comms": "comms"}
ALL = {"analyst", "field", "comms"}

ALLOWED = {
    "who_A": {"comms", "field"}, "who_B": ALL, "who_WD": {"field", "comms"}, "who_WR": ALL,
    "how_K": {"field", "comms"}, "how_S": ALL, "how_D": ALL, "how_R": ALL,
    "why_K": ALL, "why_S": ALL, "why_D": ALL, "why_R": ALL,
}
DIFF_PAIRS = [("who_A", "who_B"), ("how_K", "how_S"), ("why_K", "why_S"),
              ("who_WD", "who_WR"), ("how_D", "how_R"), ("why_D", "why_R")]
IMPORTANT = ["who_A", "who_B", "how_K", "how_S", "why_K", "why_S"]
WINDOWS = {
    "who_A": (1, 4), "who_B": (1, 4), "how_K": (1, 4), "why_K": (1, 4),
    "how_S": (1, 4), "why_S": (1, 4),
    "who_WD": (1, 2), "how_D": (1, 2), "why_D": (1, 2),
    "who_WR": (2, 5), "how_R": (2, 5), "why_R": (2, 5),
    "n0": (1, 4), "n1": (1, 4), "n2": (1, 4),
}
CAPS = [5, 4, 3, 2, 1]
REFUTES = {"who_WR": "who_WD", "how_R": "how_D", "why_R": "why_D"}


def assign_roles(rng):
    slots = sorted(ALLOWED)
    for _ in range(20000):
        a = {s: rng.pick(sorted(ALLOWED[s])) for s in slots}
        if any(a[x] == a[y] for x, y in DIFF_PAIRS):
            continue
        cnt = {r: sum(1 for s in slots if a[s] == r) for r in ROLES}
        if max(cnt.values()) > 5:
            continue
        imp = {r: sum(1 for s in IMPORTANT if a[s] == r) for r in ROLES}
        if min(imp.values()) < 1 or max(imp.values()) > 3:
            continue
        noise_roles = []
        for r in ROLES:
            noise_roles += [r] * (5 - cnt[r])
        noise_roles = rng.shuffle(noise_roles)
        for i, r in enumerate(noise_roles):
            a["n%d" % i] = r
        return a
    raise RuntimeError("no role assignment found")


def assign_rounds(rng, roles):
    slots = sorted(WINDOWS)
    for _ in range(40000):
        counts = [0] * 5
        rnd = {}
        ok = True
        order = sorted(rng.shuffle(slots), key=lambda s: WINDOWS[s][1] - WINDOWS[s][0])
        for s in order:
            lo, hi = WINDOWS[s]
            cand = [r for r in range(lo, hi + 1) if counts[r - 1] < CAPS[r - 1]]
            if not cand:
                ok = False
                break
            r = rng.pick(cand)
            rnd[s] = r
            counts[r - 1] += 1
        if not ok:
            continue
        if any(rnd[ref] < rnd[dec] for ref, dec in REFUTES.items()):
            continue
        if max(rnd[s] for s in ("who_A", "who_B", "how_K", "why_K")) != 4:
            continue
        good = True
        for role in ROLES:
            per = [sum(1 for s in slots if roles[s] == role and rnd[s] == r) for r in range(1, 6)]
            if max(per) > 2 or min(per[:3]) < 1:
                good = False
                break
        if good:
            return rnd
    raise RuntimeError("no round assignment found")


def make_ev(rng, ctx, doc, variant, vals, tmap, minute, off):
    form, data = variant
    f = lambda s: fill(s, doc, vals, tmap)
    ev = {"form": form}
    if form in ("report", "witness"):
        ev["text"] = f(data)
        if form == "witness":
            ev["witness"] = rng.pick(WITNESS_NAMES)
    elif form == "chat":
        ev["msgs"] = [(minute, data[0], f(data[1]))]
        doc.mention(ctx.time_topic(minute))
    elif form in ("access", "calls"):
        ev["rows"] = [(minute, [f(data[0]), f(data[1])])]
        doc.mention(ctx.time_topic(minute))
    elif form == "bank":
        ev["rows"] = [(off, [f(data[0]), f(data[1])])]
    elif form == "invoice":
        ev["rows"] = [(0, [f(data[0]), data[1], f(data[2])])]
        ev["date_off"] = off
    return ev


def refute_ev(rng, ctx, doc, role, text, vals, tmap):
    t = fill(text, doc, vals, tmap)
    if role == "analyst":
        return {"form": "memo", "text": t, "date_off": 1}
    if role == "field":
        return {"form": "report", "text": t, "date_off": 1}
    return {"form": "chat", "msgs": [(ctx.safe_time(rng), "قسم التدقيق", t)], "chat_name": "رد قسم التدقيق",
            "date_off": 1}


def noise_ev(rng, ctx, form, persons, pmention):
    """وثيقة تشويش: حشو مع إشارة عابرة إلى شخص (قد تطابق طلب لاعب فتزيد الالتباس)."""
    ev = {"form": form}
    p = rng.pick(persons)
    mention = rng.chance(0.6)
    if form in ("report", "witness", "memo"):
        text = rng.pick(NOISE_TEXT)
        if mention:
            text += " وقّع %s على محضر الاستلام اليومي." % p["name"]
            pmention.append(p["id"])
        ev["text"] = text
        if form == "witness":
            ev["witness"] = rng.pick(WITNESS_NAMES)
    elif form == "chat" and mention:
        ev["msgs"] = [(ctx.safe_time(rng), "سلمى", "هل رأى أحدكم %s؟ لم يوقّع على كشف الحضور اليوم." % p["name"])]
        pmention.append(p["id"])
    elif form == "bank" and mention:
        ev["rows"] = [(-rng.rint(1, 20), ["تحويل راتب — " + p["name"], "-" + money(rng.rint(600, 1800))])]
        pmention.append(p["id"])
    elif form == "invoice" and mention:
        ev["kv"] = [("المستلم", p["name"])]
        pmention.append(p["id"])
    elif form == "calls" and mention:
        ev["rows"] = [(ctx.safe_time(rng), [p["name"], "0:55"])]
        pmention.append(p["id"])
    elif form == "access" and mention:
        ev["rows"] = [(ctx.safe_time(rng), ["ممر الموظفين", "دخول " + p["name"]])]
        pmention.append(p["id"])
    return ev


def generate(theme_id, seed):
    theme = THEMES[theme_id]
    rng = Rng(theme_id, seed)

    tc = rng.rint(1290 // 5, 1410 // 5) * 5
    start, end = tc - 25, tc + 25
    month, day = rng.rint(1, 12), rng.rint(3, 25)
    base = datetime.date(2026, month, day)
    ctx = Ctx(theme, base, start, end, tc)
    next_day = theme.get("next_day", theme["id"] == "techco")
    brief_date = base + datetime.timedelta(days=1 if next_day else 0)
    date_ar = "%s %d %s" % (WEEKDAYS[(brief_date.weekday() + 1) % 7], brief_date.day, MONTHS[brief_date.month - 1])

    # --- المشتبهون
    n_f = rng.rint(3, 4)
    genders = rng.shuffle(["f"] * n_f + ["m"] * (7 - n_f))
    firsts_m, firsts_f = rng.sample(MALE, 7 - n_f), rng.sample(FEMALE, n_f)
    port_m, port_f = rng.sample(PORTRAITS_M, 7 - n_f), rng.sample(PORTRAITS_F, n_f)
    sur = rng.sample(SURNAMES, 7)
    jobs = rng.shuffle(theme["jobs"])
    persons = []
    for i, g in enumerate(genders):
        first = firsts_f.pop() if g == "f" else firsts_m.pop()
        port = port_f.pop() if g == "f" else port_m.pop()
        persons.append({"id": "p%d" % i, "name": first + " " + sur[i], "first": first, "g": g,
                        "job": jobs[i][1 if g == "f" else 0], "portrait": port})
    for p in persons:
        ctx.topic("person", p["name"])
    for place in theme["places"]:
        ctx.topic("place", place)

    # --- الحقيقة
    methods = rng.shuffle(theme["methods"])
    motives = rng.shuffle(MOTIVES)
    t_who, t_how, t_why = rng.rint(0, 6), rng.rint(0, 6), rng.rint(0, 6)
    d_who = rng.pick([i for i in range(7) if i != t_who])
    d_how = rng.pick([i for i in range(7) if i != t_how])
    d_why = rng.pick([i for i in range(7) if i != t_why])
    culprit, decoy_p = persons[t_who], persons[d_who]
    m_t, m_d, y_t, y_d = methods[t_how], methods[d_how], motives[t_why], motives[d_why]

    # --- رموز الربط
    ktype = rng.pick(sorted(KEY_TYPES))
    kt = KEY_TYPES[ktype]
    K = kt["gen"](rng)
    kid = ctx.topic("key", "%s %s" % (kt["word"], K))
    codes = rng.sample(range(1000, 9999), 4)
    link = {}
    for name, obj, code in (("hT", m_t, codes[0]), ("hD", m_d, codes[1]), ("yT", y_t, codes[2]), ("yD", y_d, codes[3])):
        link[name] = (str(code), ctx.topic("key", "%s %s" % (obj["lw"], code)))

    roles = assign_roles(rng)
    rnd = assign_rounds(rng, roles)

    base_vals = lambda: {"amt": money(rng.rint(25, 480) * 100), "sm": money(rng.rint(20, 300)),
                         "fee": money(rng.rint(5, 40)), "eq": money(rng.rint(15, 480) * 10)}
    built = {}

    def finish(slot, ev, doc):
        form = ev["form"]
        lines = FORMS[form](ctx, ev, rng)
        built[slot] = {"slot": slot, "owner": roles[slot], "round": rnd[slot], "kind": form,
                       "title": ev.get("title") or rng.pick(FORM_TITLES[form]),
                       "stamp": rng.pick(STAMPS), "serial": rng.rint(1000, 9999),
                       "lines": lines, "topics": list(doc.topics)}

    # ===== سلسلة من؟ =====
    doc = DocB("who_A")
    minute = tc - rng.rint(0, 2) * 5
    vals = dict(base_vals(), K=K, t=fmt_time(minute), door=theme["door"])
    ev = make_ev(rng, ctx, doc, kt["A"][roles["who_A"]], vals, {"K": kid}, minute, 0)
    doc.mention(ctx.time_topic(minute))
    finish("who_A", ev, doc)

    doc = DocB("who_B")
    vals = dict(base_vals(), K=K, name=culprit["name"], job=culprit["job"], t="")
    ev = make_ev(rng, ctx, doc, kt["B"][roles["who_B"]], vals, {"K": kid, "name": culprit["id"]},
                 ctx.safe_time(rng), -rng.rint(60, 400))
    finish("who_B", ev, doc)

    doc = DocB("who_WD")
    place = rng.pick(theme["places"])
    t_d = start + rng.rint(1, 8) * 5
    ev = witness_decoy(roles["who_WD"], decoy_p["name"], decoy_p["g"], place, fmt_time(t_d), t_d, rng.pick(WITNESS_NAMES))
    doc.mention(decoy_p["id"])
    doc.mention(ctx.topic("place", place))
    doc.mention(ctx.time_topic(t_d))
    finish("who_WD", ev, doc)

    doc = DocB("who_WR")
    venue = rng.pick(VENUES)
    t1, t2 = start - rng.rint(5, 12) * 5, end + rng.rint(5, 12) * 5
    ev = alibi(roles["who_WR"], decoy_p["name"], decoy_p["g"], venue, t1, t2, tc, money(rng.rint(15, 60)))
    doc.mention(decoy_p["id"])
    doc.mention(ctx.time_topic(t1))
    doc.mention(ctx.time_topic(t2))
    if roles["who_WR"] == "analyst":
        doc.mention(ctx.time_topic(tc))
    finish("who_WR", ev, doc)

    # ===== سلاسل كيف؟ ولماذا؟ =====
    def chain(prefix, truth_obj, decoy_obj, tkey, dkey):
        tcode, tlid = link[tkey]
        dcode, dlid = link[dkey]
        for slot, support in ((prefix + "_K", False), (prefix + "_S", True)):
            doc = DocB(slot)
            role = roles[slot]
            vals = dict(base_vals(), L=tcode)
            minute = tc - rng.rint(2, 7) * 5
            ev = make_ev(rng, ctx, doc, truth_obj[ROLE_VAR[role]], vals, {"L": tlid}, minute, -rng.rint(2, 9))
            finish(slot, ev, doc)
        slot = prefix + "_D"
        doc = DocB(slot)
        vals = dict(base_vals(), L=dcode)
        minute = tc - rng.rint(12, 36) * 5
        ev = make_ev(rng, ctx, doc, decoy_obj[ROLE_VAR[roles[slot]]], vals, {"L": dlid}, minute, -rng.rint(15, 60))
        finish(slot, ev, doc)
        slot = prefix + "_R"
        doc = DocB(slot)
        ev = refute_ev(rng, ctx, doc, roles[slot], decoy_obj["innocent"], dict(base_vals(), L=dcode), {"L": dlid})
        finish(slot, ev, doc)

    chain("how", m_t, m_d, "hT", "hD")
    chain("why", y_t, y_d, "yT", "yD")

    # ===== وثائق التشويش =====
    pool = {r: rng.shuffle(NOISE_DOCS[r]) for r in ROLES}
    for slot in ("n0", "n1", "n2"):
        role = roles[slot]
        form, title = pool[role].pop()
        doc = DocB(slot)
        pm = []
        ev = noise_ev(rng, ctx, form, persons, pm)
        for pid in pm:
            doc.mention(pid)
        ev["title"] = title
        finish(slot, ev, doc)

    # ===== ترتيب الوثائق ومعرّفاتها =====
    ordered = sorted(built.values(), key=lambda d: (d["round"], ROLES.index(d["owner"]), d["slot"]))
    sid = {}
    docs = []
    for i, d in enumerate(ordered, 1):
        sid[d["slot"]] = "d%d" % i
        docs.append(d)
    for d in docs:
        d["id"] = sid[d["slot"]]

    claims = [
        {"q": "who", "opt": t_who, "w": 3, "needs": [sid["who_A"], sid["who_B"]]},
        {"q": "who", "opt": d_who, "w": 2, "needs": [sid["who_WD"]]},
        {"q": "who", "opt": d_who, "w": -4, "needs": [sid["who_WR"]]},
    ]
    for pre, t_i, d_i in (("how", t_how, d_how), ("why", t_why, d_why)):
        claims += [
            {"q": pre, "opt": t_i, "w": 3, "needs": [sid[pre + "_K"]]},
            {"q": pre, "opt": t_i, "w": 2, "needs": [sid[pre + "_S"]]},
            {"q": pre, "opt": d_i, "w": 2, "needs": [sid[pre + "_D"]]},
            {"q": pre, "opt": d_i, "w": -4, "needs": [sid[pre + "_R"]]},
        ]
    # أزواج الإثبات المقبولة (أول زوج هو الأساسي ويتشارك رمز ربط).
    # زوج (الدليل الأساسي، التفنيد) يُضاف فقط إن كان المالكان مختلفين.
    proof = {
        "who": [[sid["who_A"], sid["who_B"]]],
        "how": [[sid["how_K"], sid["how_S"]]],
        "why": [[sid["why_K"], sid["why_S"]]],
    }
    for pre in ("how", "why"):
        if roles[pre + "_K"] != roles[pre + "_R"]:
            proof[pre].append([sid[pre + "_K"], sid[pre + "_R"]])
    important = {sid[s] for s in ("who_A", "who_B", "who_WR", "how_K", "how_S", "how_R", "why_K", "why_S", "why_R")}
    for d in docs:
        d["rel"] = "decisive" if d["id"] in important else "noise"
        del d["slot"]

    case = {
        "v": 1, "id": "%s-%04d" % (theme_id, seed), "theme": theme_id, "seed": seed,
        "title": theme["title"].format(item=rng.pick(theme["items"])),
        "org": rng.pick(theme["orgs"]), "date": date_ar,
        "window": [fmt_time(start), fmt_time(end)],
        "persons": persons,
        "questions": [
            {"id": "who", "prompt": "من الفاعل؟",
             "options": [{"id": "w%d" % i, "label": p["name"], "sub": p["job"], "person": p["id"]}
                         for i, p in enumerate(persons)]},
            {"id": "how", "prompt": theme["how_prompt"],
             "options": [{"id": "h%d" % i, "label": m["label"]} for i, m in enumerate(methods)]},
            {"id": "why", "prompt": "ما الدافع وراء الجريمة؟",
             "options": [{"id": "y%d" % i, "label": m["label"]} for i, m in enumerate(motives)]},
        ],
        "topics": ctx.topics,
        "docs": docs,
        "truth": {"who": t_who, "how": t_how, "why": t_why},
        "claims": claims,
        "proof": proof,
    }
    # نص التقديم يحتاج عنصراً ثابتاً للمادة والمكان
    item = case["title"].split("«")[1].split("»")[0] if "«" in case["title"] else ""
    case["brief"] = theme["brief"].format(date=date_ar, item=item, room=rng.pick(theme["rooms"]),
                                          org=case["org"], start=fmt_time(start), end=fmt_time(end))
    return case


if __name__ == "__main__":
    tid = sys.argv[1] if len(sys.argv) > 1 else "museum"
    sd = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    print(json.dumps(generate(tid, sd), ensure_ascii=False, indent=1))
