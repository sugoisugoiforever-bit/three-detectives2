# -*- coding: utf-8 -*-
"""المدقّق (Solver): يشهد أن القضية عادلة وقابلة للحل قبل شحنها في المكتبة.

الفحوص:
 1. البنية: 15 وثيقة، 5 لكل لاعب، توزيع الجولات 5/4/3/2/1، لا بقايا قوالب.
 2. المنطق: مع كل الوثائق تتفوق الإجابة الصحيحة بهامش ≥ 2، والطُّعم مغرٍ فعلاً وله تفنيد.
 3. التعاون: كل زوج إثبات من لاعبَين مختلفَين ويتشاركان رمز ربط يمكن السؤال عنه.
 4. الجدوى: توجد خطة تجمع الأدلة بثلاث نجوم قبل نهاية الجولة 4 بحدّ أدنى من النقاط.
 5. عدم التسريب: اسم الفاعل لا يظهر إلا في وثيقة الربط (ب).
"""
import itertools
import json
from collections import Counter

ROLES = ["analyst", "field", "comms"]
CAPS = [5, 4, 3, 2, 1]
QS = ("who", "how", "why")


def _strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from _strings(v)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            yield from _strings(v)


def scores(case, visible, q):
    n = len(next(x for x in case["questions"] if x["id"] == q)["options"])
    s = [0] * n
    for c in case["claims"]:
        if c["q"] == q and all(d in visible for d in c["needs"]):
            s[c["opt"]] += c["w"]
    return s


def belief(case, visible, q):
    s = scores(case, visible, q)
    top = max(s)
    if top <= 0:
        return None
    idx = [i for i, v in enumerate(s) if v == top]
    return idx[0] if len(idx) == 1 else None


def _schedulable(shares, owner, rnd, last_round):
    by = {}
    for d, _p in shares:
        by.setdefault(owner[d], []).append(rnd[d])
    for rel in by.values():
        r = 1
        for x in sorted(rel):
            r = max(r, x)
            if r > last_round:
                return False
            r += 1
    return True


def min_plan(case, last_round=4):
    """أقل عدد مشاركات (نقاط) يلزم لإحالة زوج إثبات مقبول لكل سؤال قبل نهاية الجولة المحددة."""
    owner = {d["id"]: d["owner"] for d in case["docs"]}
    rnd = {d["id"]: d["round"] for d in case["docs"]}
    best = None
    for choice in itertools.product(*(case["proof"][q] for q in QS)):
        # كل وثائق الأزواج يجب أن تصل قبل نهاية الجولة المحددة (مشاركة أو ملكاً)
        if any(rnd[d] > last_round for pair in choice for d in pair):
            continue
        for citers in itertools.product(ROLES, repeat=3):
            shares = set()
            for pair, p in zip(choice, citers):
                for d in pair:
                    if owner[d] != p:
                        shares.add((d, p))
            if best is not None and len(shares) >= best[0]:
                continue
            if _schedulable(shares, owner, rnd, last_round):
                best = (len(shares), sorted(shares), choice, citers)
    return best


def verify(case, credits=7):
    errs = []
    docs = {d["id"]: d for d in case["docs"]}
    topics = {t["id"]: t for t in case["topics"]}
    if len(docs) != 15:
        errs.append("docs=%d" % len(docs))
    own = Counter(d["owner"] for d in case["docs"])
    if any(own[r] != 5 for r in ROLES):
        errs.append("owner balance %s" % dict(own))
    per_round = [sum(1 for d in case["docs"] if d["round"] == r) for r in range(1, 6)]
    if per_round != CAPS:
        errs.append("rounds %s" % per_round)
    for q in case["questions"]:
        if len(q["options"]) != 7:
            errs.append("options %s" % q["id"])
    for d in case["docs"]:
        for t in d["topics"]:
            if t not in topics:
                errs.append("unknown topic %s in %s" % (t, d["id"]))
        if any("{" in s or "}" in s or "None" in s for s in _strings(d["lines"])):
            errs.append("leftover template in %s" % d["id"])
        rows = [json.dumps(l, ensure_ascii=False, sort_keys=True) for l in d["lines"]]
        if len(rows) != len(set(rows)):
            errs.append("duplicate line in %s" % d["id"])
    for c in case["claims"]:
        for n in c["needs"]:
            if n not in docs:
                errs.append("claim needs unknown doc %s" % n)
    if errs:
        return errs, {}

    everything = set(docs)
    for q in QS:
        t = case["truth"][q]
        s = scores(case, everything, q)
        if s[t] - max(v for i, v in enumerate(s) if i != t) < 2:
            errs.append("belief margin %s %s" % (q, s))
        decoys = [c for c in case["claims"] if c["q"] == q and c["opt"] != t and c["w"] > 0]
        refs = [c for c in case["claims"] if c["q"] == q and c["w"] < 0]
        if not decoys or not refs:
            errs.append("missing decoy/refutation %s" % q)
            continue
        if belief(case, set(decoys[0]["needs"]), q) != decoys[0]["opt"]:
            errs.append("decoy not tempting %s" % q)
        a, b = docs[decoys[0]["needs"][0]], docs[refs[0]["needs"][0]]
        if a["owner"] == b["owner"]:
            errs.append("decoy and refutation share owner %s" % q)
        if not (set(a["topics"]) & set(b["topics"])):
            errs.append("decoy/refutation not linkable %s" % q)

    for q in QS:
        for i, pair in enumerate(case["proof"][q]):
            a, b = docs[pair[0]], docs[pair[1]]
            if a["owner"] == b["owner"]:
                errs.append("proof pair same owner %s" % q)
            shared = set(a["topics"]) & set(b["topics"])
            if i == 0 and not any(topics[t]["kind"] == "key" for t in shared):
                errs.append("proof pair no shared key %s" % q)

    culprit = case["persons"][case["truth"]["who"]]["name"]
    b_doc = case["proof"]["who"][0][1]
    for d in case["docs"]:
        if d["id"] != b_doc and d["rel"] != "noise":
            if culprit in json.dumps(d["lines"], ensure_ascii=False):
                errs.append("culprit leaked in %s" % d["id"])

    plan = min_plan(case)
    if plan is None:
        errs.append("no feasible plan by round 4")
        return errs, {}
    if plan[0] > credits - 2:
        errs.append("plan too expensive %d" % plan[0])
    return errs, {"min_credits": plan[0]}
