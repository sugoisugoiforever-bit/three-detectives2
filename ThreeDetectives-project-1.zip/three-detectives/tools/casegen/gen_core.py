# -*- coding: utf-8 -*-
"""أدوات مساعدة للمولّد: سياق القضية، مُنشئ الوثيقة، تعبئة القوالب."""
import datetime
import re

from rng import fmt_time


class DocB:
    """يجمع الموضوعات (topics) التي تُذكر داخل وثيقة واحدة."""

    def __init__(self, slot):
        self.slot = slot
        self.topics = []

    def mention(self, tid):
        if tid and tid not in self.topics:
            self.topics.append(tid)


class Ctx:
    def __init__(self, theme, base_date, start, end, tc):
        self.theme = theme
        self.base_date = base_date
        self.start, self.end, self.tc = start, end, tc
        self.place_default = theme["rooms"][0]
        self.topics = []
        self._idx = {}
        self._count = {"p": 0, "l": 0, "t": 0, "k": 0}

    def topic(self, kind, label):
        key = (kind, label)
        if key in self._idx:
            return self._idx[key]
        pre = {"person": "p", "place": "l", "time": "t", "key": "k"}[kind]
        tid = "%s%d" % (pre, self._count[pre])
        self._count[pre] += 1
        self.topics.append({"id": tid, "kind": kind, "label": label})
        self._idx[key] = tid
        return tid

    def time_topic(self, minutes):
        return self.topic("time", fmt_time(minutes))

    def date(self, off):
        d = self.base_date + datetime.timedelta(days=off)
        return d.strftime("%d/%m")

    def safe_time(self, rng):
        """وقت عشوائي بعيد عن نافذة الحادثة (لا يخلق أدلة عرضية)."""
        lo, hi = 8 * 60, self.start - 100
        return rng.rint(lo // 5, hi // 5) * 5


_VAR = re.compile(r"\{(\w+)\}")


def fill(text, doc, values, topic_of):
    """يعبّئ المتغيرات ويسجّل الموضوعات المرتبطة بها كإشارات داخل الوثيقة."""
    for k in _VAR.findall(text):
        if k in topic_of:
            doc.mention(topic_of[k])
    return text.format_map(values)
