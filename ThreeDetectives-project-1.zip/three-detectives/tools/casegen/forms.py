# -*- coding: utf-8 -*-
"""تنسيق الوثائق: يحوّل «عنصر الدليل» + الحشو إلى أسطر قابلة للعرض في التطبيق.

أنواع الأسطر:
  kv   {k, v}                 حقل نموذج (مفتاح: قيمة)
  p    {v}                    فقرة مطبوعة
  hrow {c:[...]}              رأس جدول
  row  {c:[...]}              صف جدول
  msg  {who, time, v}         رسالة محادثة
"""
from pools import (BANKS, BANK_FILLER, INVOICE_FILLER, CALL_FILLER, ACCESS_FILLER,
                   CHAT_FILLER, REPORT_FILLER, WITNESS_FILLER)
from rng import fmt_time


def kv(k, v):
    return {"t": "kv", "k": k, "v": v}


def para(v):
    return {"t": "p", "v": v}


def hrow(c):
    return {"t": "hrow", "c": c}


def row(c):
    return {"t": "row", "c": c}


def msg(who, minutes, v):
    return {"t": "msg", "who": who, "time": fmt_time(minutes), "v": v}


def money(x):
    return "{:,.3f}".format(x)


def parse_money(s):
    return float(s.replace(",", "").replace("+", "").replace("-", "") or 0)


def f_bank(ctx, ev, rng):
    bank = rng.pick(BANKS)
    acct = "%d-%d" % (rng.rint(1000, 9999), rng.rint(100, 999))
    rows = [(-rng.rint(1, 28), d, a) for d, a in rng.sample(BANK_FILLER, rng.rint(3, 4))]
    for k, cells in ev.get("rows", []):
        rows.append((k, cells[0], cells[1]))
    rows.sort(key=lambda r: r[0])
    lines = [kv("المصرف", bank), kv("رقم الحساب", acct),
             kv("الفترة", "%s – %s" % (ctx.date(rows[0][0] - 1), ctx.date(rows[-1][0] + 1)))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    lines.append(hrow(["التاريخ", "البيان", "المبلغ (د.أ)"]))
    for k, d, a in rows:
        lines.append(row([ctx.date(k), d, a]))
    return lines


def f_invoice(ctx, ev, rng):
    items = [list(r) for r in rng.sample(INVOICE_FILLER, rng.rint(2, 3))]
    for k, cells in ev.get("rows", []):
        items.insert(rng.rint(0, len(items)), list(cells))
    total = sum(parse_money(c[2]) * int(c[1]) for c in items)
    lines = [kv("رقم الفاتورة", str(rng.rint(1000, 9999))),
             kv("التاريخ", ctx.date(ev.get("date_off", -rng.rint(3, 20))))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    lines.append(hrow(["البند", "الكمية", "السعر (د.أ)"]))
    for it in items:
        lines.append(row(it))
    lines.append(row(["المجموع", "", money(total)]))
    return lines


def f_report(ctx, ev, rng):
    lines = [kv("التاريخ", ctx.date(ev.get("date_off", 0))),
             kv("رقم المحضر", "م-%d" % rng.rint(100, 999)),
             kv("الموقع", ev.get("place", ctx.place_default))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    paras = [para(t) for t in rng.sample(REPORT_FILLER, 2)]
    paras.insert(rng.rint(0, 2), para(ev["text"]))
    return lines + paras


def f_witness(ctx, ev, rng):
    wname, _g = ev["witness"]
    lines = [kv("اسم الشاهد", wname), kv("التاريخ", ctx.date(ev.get("date_off", 0)))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    lines.append(para("أدلي بإفادتي طواعية، وأقول:"))
    lines.append(para(ev["text"]))
    lines.append(para(rng.pick(WITNESS_FILLER)))
    return lines


def _timed_rows(ctx, ev, rng, pool):
    pool = ev.get("filler_pool", pool)
    rows = [(ctx.safe_time(rng), list(c)) for c in rng.sample(pool, min(rng.rint(3, 4), len(pool)))]
    for k, cells in ev.get("rows", []):
        rows.append((k, list(cells)))
    rows.sort(key=lambda r: r[0])
    return rows


def f_calls(ctx, ev, rng):
    rows = _timed_rows(ctx, ev, rng, CALL_FILLER)
    lines = [kv("الخط", "06-%d" % rng.rint(1000, 9999)), kv("التاريخ", ctx.date(ev.get("date_off", 0)))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    lines.append(hrow(["الوقت", "الطرف", "المدة"]))
    for k, c in rows:
        lines.append(row([fmt_time(k)] + c))
    return lines


def f_access(ctx, ev, rng):
    rows = _timed_rows(ctx, ev, rng, ACCESS_FILLER)
    lines = [kv("النظام", ev.get("system", "نظام الدخول والمراقبة")),
             kv("التاريخ", ctx.date(ev.get("date_off", 0)))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    lines.append(hrow(["الوقت", "الجهاز", "الحدث"]))
    for k, c in rows:
        lines.append(row([fmt_time(k)] + c))
    return lines


def f_chat(ctx, ev, rng):
    msgs = [(ctx.safe_time(rng), w, t) for w, t in rng.sample(CHAT_FILLER, rng.rint(2, 3))]
    for k, w, t in ev.get("msgs", []):
        msgs.append((k, w, t))
    msgs.sort(key=lambda m: m[0])
    lines = [kv("المحادثة", ev.get("chat_name", "نسخة محادثة نصية")),
             kv("التاريخ", ctx.date(ev.get("date_off", 0)))]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    for k, w, t in msgs:
        lines.append(msg(w, k, t))
    return lines


def f_memo(ctx, ev, rng):
    lines = [kv("التاريخ", ctx.date(ev.get("date_off", 0))), kv("من", "قسم التدقيق الداخلي"),
             kv("إلى", "فريق التحقيق")]
    lines.extend(kv(k, v) for k, v in ev.get("kv", []))
    lines.append(para(ev["text"]))
    lines.append(para(rng.pick(REPORT_FILLER)))
    return lines


FORMS = {"bank": f_bank, "invoice": f_invoice, "report": f_report, "witness": f_witness,
         "calls": f_calls, "access": f_access, "chat": f_chat, "memo": f_memo}

FORM_TITLES = {
    "bank": ["كشف حساب مصرفي"], "invoice": ["فاتورة"],
    "report": ["محضر معاينة ميدانية", "تقرير ميداني"], "witness": ["إفادة شاهد"],
    "calls": ["سجل المكالمات"], "chat": ["نسخة محادثة نصية"],
    "access": ["سجل الدخول والمراقبة"], "memo": ["مذكرة تدقيق داخلية"],
}
