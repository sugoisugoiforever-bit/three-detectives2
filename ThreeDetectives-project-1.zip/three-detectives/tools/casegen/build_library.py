# -*- coding: utf-8 -*-
"""يبني مكتبة القضايا المعتمدة: ./build_library.py --per-theme 60 --out cases.jsonl"""
import argparse
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json  # noqa: E402
from generate import generate, THEMES  # noqa: E402
from verify import verify  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-theme", type=int, default=60)
    ap.add_argument("--out", default="cases.jsonl")
    ap.add_argument("--seed-start", type=int, default=1)
    ap.add_argument("--array-out", default="", help="نسخة JSON مصفوفة (للخادم)")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    out, rejects, plans = [], Counter(), Counter()
    for tid in sorted(THEMES):
        seed, made = args.seed_start, 0
        while made < args.per_theme and seed < args.seed_start + args.per_theme * 6:
            try:
                case = generate(tid, seed)
                errs, info = verify(case)
            except Exception as e:  # noqa: BLE001
                errs, info, case = ["exception: %s" % e], {}, None
            if errs:
                rejects[errs[0].split(" ")[0]] += 1
                if not args.quiet:
                    print("REJECT %s-%d: %s" % (tid, seed, errs[:2]))
            else:
                out.append(json.dumps(case, ensure_ascii=False, separators=(",", ":")))
                plans[info["min_credits"]] += 1
                made += 1
            seed += 1
        print("%s: %d cases (seeds up to %d)" % (tid, made, seed - 1))

    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    if args.array_out:
        with open(args.array_out, "w", encoding="utf-8") as f:
            f.write("[" + ",\n".join(out) + "]\n")
    size = os.path.getsize(args.out)
    print("total=%d size=%.1fKB rejects=%s min-credit-plans=%s" % (
        len(out), size / 1024, dict(rejects), dict(sorted(plans.items()))))


if __name__ == "__main__":
    main()
