# -*- coding: utf-8 -*-
"""أيقونة التطبيق: ملف قضية مع عدسة مكبّرة نحاسية وختم شمعي على خلفية خشب الجوز."""
import os
import numpy as np
import cv2
from common import *
from objects import BRASS
from wood import desk

RES = os.environ.get("RES_DIR", "")


def foreground(S=864):
    """فنّ الواجهة الأمامية على شفافية؛ الحيّز الآمن هو الثلثان الأوسطان."""
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    img = np.zeros((S, S, 3), np.float32)
    alpha = np.zeros((S, S), np.float32)
    # ملف أصفر مانيلا
    fx0, fy0, fx1, fy1 = S * 0.27, S * 0.34, S * 0.73, S * 0.72
    folder = np.zeros((S, S), np.float32)
    cv2.fillPoly(folder, [np.array([[fx0, fy0 + S * 0.03], [fx0 + S * 0.10, fy0 + S * 0.03], [fx0 + S * 0.13, fy0 - S * 0.02], [fx0 + S * 0.26, fy0 - S * 0.02], [fx0 + S * 0.29, fy0 + S * 0.03], [fx1, fy0 + S * 0.03], [fx1, fy1], [fx0, fy1]], np.int32)], 1.0, cv2.LINE_AA)
    folder = blur(folder, 1.2)
    paper_m = np.zeros((S, S), np.float32)
    cv2.rectangle(paper_m, (int(fx0 + S * 0.03), int(fy0 - S * 0.045)), (int(fx1 - S * 0.04), int(fy0 + S * 0.10)), 1.0, -1, cv2.LINE_AA)
    paper_m = blur(paper_m, 1.2)
    hmap = blur(folder, 4.0) * 1.4 + blur(paper_m, 3.0) * 0.5
    diff, spec = light(hmap * 10.0, strength=2.2, spec=0.2, amb=0.55)
    mc = np.array([214, 168, 100], np.float32)[None, None, :] * (0.55 + 0.55 * diff)[..., None] * (0.94 + 0.08 * fbm(S, S, 3, 4, 6))[..., None]
    pc = np.array([238, 228, 200], np.float32)[None, None, :] * (0.8 + 0.2 * diff)[..., None]
    img = pc * paper_m[..., None] * (1 - folder[..., None] * 0.0)
    img = img * (1 - folder[..., None]) + mc * folder[..., None]
    img += np.where(paper_m[..., None] > 0.5, 0, 0)
    alpha = np.maximum(folder, paper_m)
    # عدسة مكبّرة نحاسية
    cx, cy, R = S * 0.56, S * 0.50, S * 0.20
    rr = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    ring = np.exp(-(((rr - R) / (S * 0.030)) ** 2 / 1.0))
    ringm = np.clip((S * 0.038 - np.abs(rr - R)) / 2.0 + 0.5, 0, 1)
    glass = np.clip((R - rr) / 2.0 + 0.5, 0, 1)
    handle = np.zeros((S, S), np.float32)
    ang = np.pi / 4
    p0 = (int(cx + np.cos(ang) * R * 1.02), int(cy + np.sin(ang) * R * 1.02))
    p1 = (int(cx + np.cos(ang) * (R + S * 0.20)), int(cy + np.sin(ang) * (R + S * 0.20)))
    cv2.line(handle, p0, p1, 1.0, int(S * 0.058), cv2.LINE_AA)
    handle = blur(handle, 1.0)
    h2 = blur(ringm, 2.5) * 2.0 + blur(handle, 3.0) * 1.6
    diff2, spec2 = light(h2 * 8.0, strength=2.4, spec=1.0, shin=24, amb=0.38)
    brass = cmap(np.clip(0.14 + 0.52 * diff2 + 1.25 * spec2, 0, 1), BRASS)
    hcol = np.array([58, 36, 22], np.float32)[None, None, :] * (0.55 + 0.6 * diff2)[..., None] + (spec2 * 255 * 0.35)[..., None]
    # ظل المكبّرة على الملف
    shm = blur(np.roll(np.roll(np.maximum(ringm, handle), int(S * 0.018), axis=0), int(S * 0.014), axis=1), S * 0.012)
    img *= (1 - 0.45 * shm * alpha)[..., None]
    # زجاج: عتمة خفيفة وانعكاس
    glass_tint = np.array([255, 244, 214], np.float32)
    img = img * (1 - glass[..., None] * 0.10) + glass_tint * glass[..., None] * 0.10 * 0.0
    refl = np.clip(1 - np.abs((x - cx) * 0.9 + (y - cy) * 0.5 + R * 0.2) / (R * 0.22), 0, 1) * glass * 0.18
    img += refl[..., None] * 255
    # ظل الزجاج الداخلي
    img *= (1 - 0.22 * (glass * np.clip((rr - R * 0.85) / (R * 0.15), 0, 1))[..., None])
    img = img * (1 - handle[..., None]) + hcol * handle[..., None]
    img = img * (1 - ringm[..., None]) + brass * ringm[..., None]
    alpha = np.maximum(alpha, np.maximum(handle, np.maximum(ringm, glass * 0.0)))
    # ختم شمعي صغير على الملف
    sx, sy, sr = S * 0.355, S * 0.635, S * 0.062
    sd = np.sqrt((x - sx) ** 2 + (y - sy) ** 2)
    wm = np.clip((sr - sd) / 1.5 + 0.5, 0, 1)
    wh = np.clip((sr - sd) / (sr * 0.5), 0, 1)
    wd, wsp = light(blur(wh, 1.5) * 3.0, strength=2.0, spec=0.9, shin=26, amb=0.45)
    wax = np.array([160, 22, 28], np.float32)[None, None, :] * (0.4 + 0.8 * wd)[..., None] + (wsp * 255 * 0.7)[..., None]
    img = img * (1 - wm[..., None]) + wax * wm[..., None]
    alpha = np.maximum(alpha, wm)
    # ظل ساقط عام
    sh = drop_shadow(alpha, S * 0.010, S * 0.016, S * 0.012, 0.55)
    out_a = np.clip(alpha + sh * (1 - alpha), 0, 1)
    return to_img(img * alpha[..., None], out_a * 255)


def background(S=864):
    d = desk(S, S, seed=17)
    arr = np.asarray(d).astype(np.float32)
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    glow = np.exp(-(((x - S * 0.45) / (S * 0.55)) ** 2 + ((y - S * 0.40) / (S * 0.55)) ** 2))
    arr *= (0.55 + 0.85 * glow)[..., None]
    return to_img(arr)


def composite(fg, bg):
    o = bg.convert("RGBA")
    o.alpha_composite(fg)
    return o


def build(res_dir=None):
    fg = foreground(864)
    bg = background(864)
    save_dir = res_dir or OUT
    os.makedirs(save_dir, exist_ok=True)
    full = composite(fg, bg)
    full.resize((512, 512), Image.LANCZOS).convert("RGB").save(os.path.join(OUT, "ic_launcher_512.png"))
    out = {}
    if res_dir:
        sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
        for dn, px in sizes.items():
            d = os.path.join(res_dir, "mipmap-" + dn)
            os.makedirs(d, exist_ok=True)
            sq = full.resize((px, px), Image.LANCZOS)
            # زوايا مستديرة للقديم
            m = np.asarray(Image.fromarray((rounded_mask(px, px, px * 0.18) * 255).astype(np.uint8)))
            sq.putalpha(Image.fromarray(m))
            sq.save(os.path.join(d, "ic_launcher.png"))
            yy, xx = np.mgrid[0:px, 0:px].astype(np.float32)
            circ = np.clip((px / 2 - np.sqrt((xx - px / 2 + 0.5) ** 2 + (yy - px / 2 + 0.5) ** 2)) + 0.5, 0, 1)
            rd = full.resize((px, px), Image.LANCZOS)
            rd.putalpha(Image.fromarray((circ * 255).astype(np.uint8)))
            rd.save(os.path.join(d, "ic_launcher_round.png"))
        d = os.path.join(res_dir, "drawable-nodpi")
        os.makedirs(d, exist_ok=True)
        fg.resize((432, 432), Image.LANCZOS).save(os.path.join(d, "ic_launcher_fg.png"))
        bg.resize((432, 432), Image.LANCZOS).convert("RGB").save(os.path.join(d, "ic_launcher_bg.png"))
    print("  launcher icons done")


if __name__ == "__main__":
    build(os.environ.get("RES_DIR") or None)
