# -*- coding: utf-8 -*-
"""لوحة الحالة النحاسية، لوحة الأسماء، بطاقات الأفعال، الأيقونات، مشبك الورق، إطار البولارويد."""
import numpy as np
import cv2
from common import *
from objects import BRASS, star_poly, SS
from wood import plank
from paper import paper
from leather import rr_points


def sdf_rr(h, w, r):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    qx = np.abs(x - (w - 1) / 2) - ((w - 1) / 2 - r)
    qy = np.abs(y - (h - 1) / 2) - ((h - 1) / 2 - r)
    outside = np.sqrt(np.maximum(qx, 0) ** 2 + np.maximum(qy, 0) ** 2)
    inside = np.minimum(np.maximum(qx, qy), 0)
    return outside + inside - r  # سالب داخل الشكل


def smooth(t):
    t = np.clip(t, 0, 1)
    return t * t * (3 - 2 * t)


def brass_surface(hmap, streak, spec=1.0):
    diff, sp = light(hmap, strength=2.4, spec=spec, shin=26, amb=0.40)
    t = np.clip(0.16 + 0.48 * diff + 1.25 * sp + 0.10 * (streak - 0.5), 0, 1)
    return cmap(t, BRASS)


def screw(img, cx, cy, r, ang):
    h, w = img.shape[:2]
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    m = np.clip(r - d + 0.5, 0, 1)
    sh = 0.55 + 0.6 * np.clip(1 - np.sqrt((x - cx + r * 0.3) ** 2 + (y - cy + r * 0.3) ** 2) / r, 0, 1)
    col = np.array([176, 134, 66], np.float32)[None, None, :] * sh[..., None]
    slot = np.zeros((h, w), np.float32)
    dx, dy = np.cos(ang) * r * 0.8, np.sin(ang) * r * 0.8
    cv2.line(slot, (int(cx - dx), int(cy - dy)), (int(cx + dx), int(cy + dy)), 1.0, max(1, int(r * 0.3)), cv2.LINE_AA)
    col *= (1 - 0.8 * blur(slot, 0.6))[..., None]
    ring = np.exp(-((d - r - 0.8) / 0.9) ** 2) * 0.6
    img *= (1 - ring)[..., None]
    img[:] = img * (1 - m[..., None]) + col * m[..., None]


def plaque(W=1000, H=170, T=15, pad=36, seed=51):
    sd = sdf_rr(H, W, 20)
    d = -sd
    inside = np.clip(d + 0.5, 0, 1)
    streak = blur(np.random.default_rng(seed).random((H, W)).astype(np.float32), 34, 0.7)
    streak = (streak - streak.min()) / (streak.max() - streak.min() + 1e-9)
    # ارتفاع الإطار: حافة مستديرة ثم سطح مستو ثم شطف داخلي
    hf = smooth(d / 4.5) * (1 - 0.68 * smooth((d - (T - 5.5)) / 5.5))
    inset = np.clip((d - T) / 3.0, 0, 1)
    hmap = np.where(d < T, hf * 3.0, 0.7)
    frame = brass_surface(hmap, streak)
    # اللوح الداخلي: خشب جوز داكن
    pw, _ = plank(H, W, seed + 4, 0.8)
    panel = pw * 0.55
    k = smooth((d - T) / 22.0)
    panel *= (0.45 + 0.55 * k)[..., None]
    # خط نحاسي رفيع مطعّم داخل اللوح
    line = np.exp(-(((d - (T + 8)) / 1.1) ** 2))
    panel = panel * (1 - line[..., None] * 0.9) + np.array([160, 118, 56], np.float32) * line[..., None] * 0.9
    img = np.where((d < T)[..., None], frame, panel)
    for (cx, cy, a) in ((30, 30, 0.6), (W - 31, 30, 2.0), (30, H - 31, 1.1), (W - 31, H - 31, 2.6)):
        screw(img, cx, cy, 7.0, a)
    img += grain(H, W, seed + 8, 1.6)
    return pack_with_shadow(img, inside, W, H, pad, 0.58, 7, 12, 13)


def pack_with_shadow(img, mask, W, H, pad, op, dx, dy, sig):
    HH, WW = H + 2 * pad, W + 2 * pad
    canvas = np.zeros((HH, WW, 3), np.float32)
    alpha = np.zeros((HH, WW), np.float32)
    canvas[pad:pad + H, pad:pad + W] = img
    alpha[pad:pad + H, pad:pad + W] = mask
    sh = drop_shadow(alpha, dx, dy, sig, op)
    out_a = np.clip(alpha + sh * (1 - alpha), 0, 1)
    return to_img(canvas * alpha[..., None], out_a * 255)


def brass_plate(W=360, H=96, pad=24, seed=61):
    sd = sdf_rr(H, W, 14)
    d = -sd
    inside = np.clip(d + 0.5, 0, 1)
    streak = blur(np.random.default_rng(seed).random((H, W)).astype(np.float32), 30, 0.6)
    streak = (streak - streak.min()) / (streak.max() - streak.min() + 1e-9)
    hf = smooth(d / 4.0) * (1 - 0.55 * smooth((d - 6) / 5.0))
    hmap = hf * 2.6
    surf = brass_surface(hmap, streak, 0.9)
    # لوح داخلي مصقول أفتح لنص داكن
    k = smooth((d - 11) / 2.5)
    img = surf * (1 - k[..., None] * 0.0)
    img = img * (1 - 0.0) + (np.array([212, 172, 96], np.float32)[None, None, :] * (0.88 + 0.16 * streak)[..., None]) * k[..., None] * 0.62 + img * (1 - k[..., None] * 0.62)
    for (cx, cy, a) in ((16, 16, 0.5), (W - 17, 16, 2.1), (16, H - 17, 1.4), (W - 17, H - 17, 0.2)):
        screw(img, cx, cy, 4.4, a)
    img += grain(H, W, seed + 3, 1.2)
    return pack_with_shadow(img, inside, W, H, pad, 0.5, 5, 8, 8)


def card(W=260, H=360, pad=26, seed=71):
    base = np.asarray(paper(W, H, seed, (242, 233, 208), 0.55, fold=False, rough=False)).astype(np.float32)[..., :3].copy()
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    lines = np.zeros((H, W), np.float32)
    for inset, th in ((10, 3), (18, 1)):
        pts = np.array(rr_points(inset, inset, W - 1 - inset, H - 1 - inset, 12, 1.5), np.int32)
        cv2.polylines(lines, [pts], True, 1.0, th, cv2.LINE_AA)
    for (cx, cy) in ((24, 24), (W - 25, 24), (24, H - 25), (W - 25, H - 25)):
        cv2.fillPoly(lines, [np.array([[cx, cy - 5], [cx + 5, cy], [cx, cy + 5], [cx - 5, cy]], np.int32)], 1.0, cv2.LINE_AA)
    lines = blur(lines, 0.5)
    ink = np.array([96, 62, 38], np.float32)
    base = base * (1 - 0.8 * lines[..., None]) + ink * 0.8 * lines[..., None]
    # بروز خفيف
    diff, _ = light(lines * 1.3, strength=1.5, spec=0.0, amb=0.9)
    base *= diff[..., None]
    # تدرج يضيء منتصف البطاقة
    base *= (0.90 + 0.14 * np.exp(-(((x - W / 2) / (W * 0.8)) ** 2 + ((y - H * 0.4) / (H * 0.7)) ** 2)))[..., None]
    mask = rounded_mask(H, W, 16)
    return pack_with_shadow(base, mask, W, H, pad, 0.55, 6, 10, 9)


# ───────── أيقونات حبر بنّية ─────────
def ink_icon(draw, size=224, seed=0):
    S = size * SS
    m = np.zeros((S, S), np.float32)
    U = lambda v: int(round(v * S))
    P = lambda a, b: (U(a), U(b))
    draw(m, U, P, S)
    m = blur(m, SS * 0.55)
    m = np.clip(m * 1.15, 0, 1)
    tex = 0.86 + 0.14 * fbm(S, S, seed + 1, 4, 24)
    ink = np.zeros((S, S, 3), np.float32)
    ink[:] = np.array([52, 32, 20], np.float32)
    ink *= tex[..., None]
    img = to_img(ink, m * 255 * np.clip(tex + 0.1, 0, 1))
    return img.resize((size, size), Image.LANCZOS)


def th(S, v):
    return max(2, int(S * v))


def d_ask(m, U, P, S):
    cv2.circle(m, P(0.42, 0.42), U(0.27), 1.0, th(S, 0.065), cv2.LINE_AA)
    cv2.circle(m, P(0.42, 0.42), U(0.19), 0.25, th(S, 0.02), cv2.LINE_AA)
    cv2.line(m, P(0.62, 0.62), P(0.86, 0.86), 1.0, th(S, 0.115), cv2.LINE_AA)
    cv2.ellipse(m, P(0.42, 0.42), (U(0.20), U(0.20)), 0, 200, 260, 0.9, th(S, 0.03), cv2.LINE_AA)


def d_send(m, U, P, S):
    cv2.rectangle(m, P(0.16, 0.30), P(0.84, 0.72), 1.0, th(S, 0.055), cv2.LINE_AA)
    cv2.polylines(m, [np.array([P(0.16, 0.30), P(0.50, 0.55), P(0.84, 0.30)])], False, 1.0, th(S, 0.05), cv2.LINE_AA)
    cv2.line(m, P(0.16, 0.72), P(0.40, 0.50), 1.0, th(S, 0.035), cv2.LINE_AA)
    cv2.line(m, P(0.84, 0.72), P(0.60, 0.50), 1.0, th(S, 0.035), cv2.LINE_AA)
    for yy in (0.80, 0.88):
        cv2.line(m, P(0.18, yy), P(0.18 + (0.22 if yy < 0.85 else 0.14), yy), 1.0, th(S, 0.03), cv2.LINE_AA)


def d_say(m, U, P, S):
    cv2.polylines(m, [np.array(rr_points(U(0.12), U(0.18), U(0.88), U(0.66), U(0.09), 3.0), np.int32)], True, 1.0, th(S, 0.055), cv2.LINE_AA)
    cv2.fillPoly(m, [np.array([P(0.30, 0.64), P(0.26, 0.88), P(0.52, 0.64)])], 1.0, cv2.LINE_AA)
    for yy, xe in ((0.32, 0.72), (0.42, 0.62), (0.52, 0.68)):
        cv2.line(m, P(0.26, yy), P(xe, yy), 1.0, th(S, 0.04), cv2.LINE_AA)


def d_audit(m, U, P, S):
    cv2.rectangle(m, P(0.20, 0.10), P(0.80, 0.90), 1.0, th(S, 0.05), cv2.LINE_AA)
    for yy in (0.26, 0.38, 0.50):
        cv2.line(m, P(0.30, yy), P(0.70, yy), 1.0, th(S, 0.032), cv2.LINE_AA)
    cv2.polylines(m, [np.array([P(0.36, 0.70), P(0.48, 0.82), P(0.74, 0.54)])], False, 1.0, th(S, 0.075), cv2.LINE_AA)


def d_raid(m, U, P, S):
    cv2.circle(m, P(0.30, 0.32), U(0.17), 1.0, th(S, 0.06), cv2.LINE_AA)
    cv2.circle(m, P(0.30, 0.32), U(0.045), 1.0, -1, cv2.LINE_AA)
    cv2.line(m, P(0.42, 0.44), P(0.84, 0.86), 1.0, th(S, 0.07), cv2.LINE_AA)
    cv2.line(m, P(0.62, 0.64), P(0.76, 0.50), 1.0, th(S, 0.06), cv2.LINE_AA)
    cv2.line(m, P(0.74, 0.76), P(0.88, 0.62), 1.0, th(S, 0.06), cv2.LINE_AA)


def d_intercept(m, U, P, S):
    cv2.ellipse(m, P(0.5, 0.55), (U(0.34), U(0.34)), 0, 180, 360, 1.0, th(S, 0.065), cv2.LINE_AA)
    for sx in (0.14, 0.72):
        cv2.polylines(m, [np.array(rr_points(U(sx), U(0.52), U(sx + 0.14), U(0.80), U(0.04), 3.0), np.int32)], True, 1.0, -1 if False else th(S, 0.04), cv2.LINE_AA)
        cv2.fillPoly(m, [np.array(rr_points(U(sx), U(0.52), U(sx + 0.14), U(0.80), U(0.04), 3.0), np.int32)], 1.0, cv2.LINE_AA)
    for k, a in enumerate((0.30, 0.42)):
        cv2.ellipse(m, P(0.5, 0.55), (U(a * 0.6), U(a * 0.6)), 0, 215, 325, 0.9, th(S, 0.032), cv2.LINE_AA)


def d_notes(m, U, P, S):
    cv2.polylines(m, [np.array([P(0.50, 0.26), P(0.12, 0.20), P(0.12, 0.78), P(0.50, 0.84)])], False, 1.0, th(S, 0.05), cv2.LINE_AA)
    cv2.polylines(m, [np.array([P(0.50, 0.26), P(0.88, 0.20), P(0.88, 0.78), P(0.50, 0.84)])], False, 1.0, th(S, 0.05), cv2.LINE_AA)
    cv2.line(m, P(0.50, 0.26), P(0.50, 0.84), 1.0, th(S, 0.04), cv2.LINE_AA)
    for yy in (0.36, 0.48, 0.60):
        cv2.line(m, P(0.20, yy), P(0.42, yy + 0.015), 1.0, th(S, 0.028), cv2.LINE_AA)
        cv2.line(m, P(0.58, yy + 0.015), P(0.80, yy), 1.0, th(S, 0.028), cv2.LINE_AA)


def d_accuse(m, U, P, S):
    head = np.array([P(0.16, 0.30), P(0.50, 0.12), P(0.62, 0.34), P(0.28, 0.52)])
    cv2.fillPoly(m, [head], 1.0, cv2.LINE_AA)
    cv2.line(m, P(0.50, 0.46), P(0.84, 0.82), 1.0, th(S, 0.085), cv2.LINE_AA)
    cv2.polylines(m, [np.array(rr_points(U(0.14), U(0.80), U(0.62), U(0.90), U(0.03), 3.0), np.int32)], True, 1.0, th(S, 0.05), cv2.LINE_AA)
    cv2.line(m, P(0.20, 0.30), P(0.54, 0.14), 0.0, th(S, 0.02), cv2.LINE_AA)


def d_people(m, U, P, S):
    for cx in (0.28, 0.5, 0.72):
        cv2.circle(m, P(cx, 0.36), U(0.09), 1.0, th(S, 0.045), cv2.LINE_AA)
        cv2.ellipse(m, P(cx, 0.78), (U(0.13), U(0.20)), 0, 180, 360, 1.0, th(S, 0.045), cv2.LINE_AA)


ICONS = {"ask": d_ask, "send": d_send, "say": d_say, "audit": d_audit, "raid": d_raid, "intercept": d_intercept,
         "notes": d_notes, "accuse": d_accuse, "people": d_people}


def paperclip(W=76, H=176, seed=5):
    S = SS * 2
    big = np.zeros((H * S, W * S), np.float32)
    pts = [(44, 112), (44, 138), (34, 153), (22, 153), (12, 138), (12, 40), (18, 20), (32, 10), (46, 20), (52, 40), (52, 126), (46, 142), (38, 142), (32, 130), (32, 62)]
    P = np.array([(int(a * S), int(b * S)) for a, b in pts], np.int32)
    cv2.polylines(big, [P], False, 1.0, 7 * S // 2, cv2.LINE_AA)
    core = np.zeros_like(big)
    cv2.polylines(core, [P], False, 1.0, 3 * S // 2, cv2.LINE_AA)
    m = cv2.resize(big, (W, H), interpolation=cv2.INTER_AREA)
    c = cv2.resize(core, (W, H), interpolation=cv2.INTER_AREA)
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    col = np.zeros((H, W, 3), np.float32)
    col[:] = np.array([98, 100, 110], np.float32)
    col = col * (1 - c[..., None]) + np.array([214, 216, 224], np.float32) * c[..., None] * (0.75 + 0.25 * np.sin(y / 9.0))[..., None]
    sh = blur(np.roll(np.roll(m, 4, axis=0), 3, axis=1), 2.5) * 0.45
    a = np.clip(m + sh * (1 - m), 0, 1)
    return to_img(col * m[..., None], a * 255)


def polaroid_frame(W=330, H=410, win=(22, 22, 308, 308), seed=81):
    base = np.asarray(paper(W, H, seed, (240, 236, 224), 0.35, fold=False, rough=False)).astype(np.float32)[..., :3].copy()
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    x0, y0, x1, y1 = win
    hole = ((x >= x0) & (x < x1) & (y >= y0) & (y < y1)).astype(np.float32)
    hole = blur(hole, 0.7)
    # خط ظل رفيع حول نافذة الصورة وتدرّج عند الأسفل
    edge = np.clip(1 - np.abs(blur(hole, 1.5) - 0.5) * 6, 0, 1)
    base *= (1 - 0.30 * edge)[..., None]
    base *= (0.97 + 0.05 * (y / H))[..., None]
    mask = rounded_mask(H, W, 6)
    # لمعان زجاجي مائل فوق النافذة
    gl = np.clip(1 - np.abs((x - x0) * 0.9 + (y - y0) * 0.55 - 190) / 55.0, 0, 1) * 0.12 + 0.03
    alpha = mask * (1 - hole) + hole * gl * mask
    col = base * (1 - hole[..., None]) + np.array([255, 255, 255], np.float32) * hole[..., None]
    return to_img(col, alpha * 255)


def star(filled=True, size=120):
    S = size * SS
    cx = cy = S / 2
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    st = np.zeros((S, S), np.float32)
    cv2.fillPoly(st, [(star_poly(cx, cy, S * 0.46, S * 0.19)).astype(np.int32)], 1.0, cv2.LINE_AA)
    if filled:
        h = blur(st, SS * 2.2) * 1.2 + blur(st, SS * 0.7) * 0.3
        diff, spec = light(h * 18.0, strength=2.2, spec=1.0, shin=24, amb=0.4)
        col = cmap(np.clip(0.2 + 0.5 * diff + 1.2 * spec, 0, 1), BRASS)
        sh = blur(np.roll(np.roll(st, 5 * SS, axis=0), 4 * SS, axis=1), 4 * SS) * 0.5
    else:
        h = -blur(st, SS * 2.0) * 1.0
        diff, spec = light(h * 14.0, strength=2.0, spec=0.4, shin=20, amb=0.5)
        col = np.array([36, 26, 20], np.float32)[None, None, :] * (0.5 + 0.7 * diff)[..., None]
        sh = np.zeros_like(st)
    a = np.clip(st + sh * (1 - st), 0, 1)
    return to_img(col * st[..., None], a * 255).resize((size, size), Image.LANCZOS)


def build():
    save(plaque(), "plaque", quality=90)
    save(brass_plate(), "plate_brass", quality=90)
    save(card(), "card_vintage", quality=90)
    for n, f in ICONS.items():
        save(ink_icon(f, 224, sum(map(ord, n))), "icon_" + n, quality=92)
    save(paperclip(), "paperclip", quality=92)
    save(polaroid_frame(), "polaroid", quality=90)
    save(star(True), "star_gold", quality=92)
    save(star(False), "star_empty", quality=92)


if __name__ == "__main__":
    build()
