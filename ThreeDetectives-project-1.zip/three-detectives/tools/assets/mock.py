# -*- coding: utf-8 -*-
"""معاينة تركيبية لمشهد اللعب (للمراجعة البصرية فقط؛ الواجهة الحقيقية تُرسم في Compose)."""
import os
import sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONTB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def L(n):
    return Image.open(os.path.join(OUT, n + ".webp")).convert("RGBA")


def f(sz, bold=False):
    return ImageFont.truetype(FONTB if bold else FONT, sz, layout_engine=ImageFont.Layout.RAQM)


def ar(draw, xy, text, font, fill, anchor="ra"):
    draw.text(xy, text, font=font, fill=fill, anchor=anchor, direction="rtl", language="ar")


def paste_rot(base, im, cx, cy, ang, scale=1.0, shadow=True):
    if scale != 1.0:
        im = im.resize((int(im.width * scale), int(im.height * scale)), Image.LANCZOS)
    if ang:
        im = im.rotate(ang, resample=Image.BICUBIC, expand=True)
    if shadow:
        a = im.split()[3].filter(ImageFilter.GaussianBlur(6)).point(lambda v: int(v * 0.55))
        sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
        sh.putalpha(a)
        base.alpha_composite(sh, (int(cx - im.width / 2 + 5), int(cy - im.height / 2 + 9)))
    base.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2)))


def polaroid(i, name, role):
    fr = L("polaroid")
    por = L("portrait_%02d" % i).resize((286, 286), Image.LANCZOS)
    c = Image.new("RGBA", fr.size, (0, 0, 0, 0))
    c.alpha_composite(por, (22, 22))
    c.alpha_composite(fr)
    d = ImageDraw.Draw(c)
    ar(d, (fr.width - 28, 352), name, f(34, True), (40, 30, 24, 255))
    ar(d, (fr.width - 28, 386), role, f(24), (90, 70, 54, 255))
    return c


def main():
    W, H = 1920, 864
    bg = L("desk_wood").resize((W, int(1600 * 0 + H * 1.0) if False else H), Image.LANCZOS)
    bg = L("desk_wood").crop((0, 0, 1600, 900)).resize((W, H), Image.LANCZOS)
    S = bg.copy()
    d = ImageDraw.Draw(S)
    # دفتر
    nb = L("notebook")
    paste_rot(S, nb, 340, 470, 0, 0.58, shadow=False)
    # لوحة فلين
    ck = L("corkboard")
    paste_rot(S, ck, 1560, 470, 0, 0.60, shadow=False)
    # لوحة الحالة
    pq = L("plaque")
    paste_rot(S, pq, 960, 98, 0, 0.64, shadow=False)
    ar(d, (1180, 70), "الجولة 2 / 5", f(30, True), (236, 214, 160, 255))
    d.text((960, 92), "02:41", font=f(64, True), fill=(250, 226, 170, 255), anchor="mm")
    coin, empty = L("coin").resize((44, 44), Image.LANCZOS), L("coin_empty").resize((44, 44), Image.LANCZOS)
    for k in range(7):
        S.alpha_composite(coin if k < 5 else empty, (738 + k * 46, 120))
    # وثائق في الوسط
    docs = ["paper_cream", "paper_white", "paper_legal", "paper_cream", "paper_white"]
    titles = ["كشف حساب مصرفي", "فاتورة — مطعم النخلة", "إفادة شاهد", "محضر معاينة", "سجل مكالمات"]
    pos = [(770, 430, -6), (960, 450, 3), (1150, 430, 7), (860, 640, 4), (1070, 640, -4)]
    for (n, t, (cx, cy, a)) in zip(docs, titles, pos):
        im = L(n).resize((200, 274), Image.LANCZOS)
        dd = ImageDraw.Draw(im)
        ar(dd, (186, 44), t, f(16, True), (50, 38, 30, 255))
        for k in range(6):
            dd.line((24, 76 + k * 22, 170, 76 + k * 22), fill=(80, 70, 60, 120), width=2)
        paste_rot(S, im, cx, cy, a, 1.0)
    clip = L("paperclip").resize((30, 70), Image.LANCZOS)
    S.alpha_composite(clip, (880, 300))
    # بولارويد على اللوحة
    names = ["سامر النجار", "لمى الدباغ", "ياسر الحداد", "رنا الخياط", "فادي العطار", "هبة الصباغ"]
    roles = ["مدير الأمن", "أمينة المعرض", "مرمّم", "محاسبة", "سائق", "مشرفة الصالة"]
    ports = [0, 8, 3, 10, 5, 12]
    pcs = [(1390, 285, -5), (1560, 270, 4), (1730, 290, -3), (1400, 520, 3), (1570, 530, -5), (1740, 515, 4)]
    for (i, n, r_, (cx, cy, a)) in zip(ports, names, roles, pcs):
        p = polaroid(i, n, r_)
        paste_rot(S, p, cx, cy, a, 0.40)
        pin = L(["pin_red", "pin_blue", "pin_yellow", "pin_green"][i % 4]).resize((44, 44), Image.LANCZOS)
        S.alpha_composite(pin, (int(cx - 22 + a * 0.6), int(cy - 0.4 * 410 / 2 - 4)))
    # ورقة لاصقة بطلب
    st = L("sticky").resize((150, 150), Image.LANCZOS)
    tint = Image.new("RGBA", st.size, (255, 236, 120, 255))
    from PIL import ImageChops
    st2 = ImageChops.multiply(st.convert("RGB"), tint.convert("RGB")).convert("RGBA")
    st2.putalpha(st.split()[3])
    dd = ImageDraw.Draw(st2)
    ar(dd, (136, 42), "المحلل المالي يسأل:", f(16, True), (60, 40, 20, 255))
    ar(dd, (136, 68), "«الحساب 8121»؟", f(18, True), (150, 30, 30, 255))
    paste_rot(S, st2, 1580, 400, 6, 1.0)
    # بطاقات الأفعال أسفل
    cards = [("icon_ask", "اسأل"), ("icon_send", "أرسل"), ("icon_say", "قل"), ("icon_audit", "تدقيق")]
    for k, (ic, lb) in enumerate(cards):
        c = L("card_vintage").resize((130, 172), Image.LANCZOS)
        i = L(ic).resize((84, 84), Image.LANCZOS)
        c.alpha_composite(i, (23, 30))
        dd = ImageDraw.Draw(c)
        dd.text((65, 140), "", font=f(10))
        ar(dd, (96, 150), lb, f(24, True), (70, 44, 26, 255), anchor="ra")
        paste_rot(S, c, 560 + k * 150, 770, (-3, 2, -1, 3)[k], 1.0)
    seal = L("seal_ready").resize((130, 130), Image.LANCZOS)
    S.alpha_composite(seal, (1330, 700))
    ar(ImageDraw.Draw(S), (1395 + 16, 752), "جاهز", f(24, True), (250, 220, 210, 255), anchor="ma")
    S.convert("RGB").save(os.path.join(os.environ.get("MOCK_OUT", "."), "mock_scene.png"))


if __name__ == "__main__":
    main()
