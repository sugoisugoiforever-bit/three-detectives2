# -*- coding: utf-8 -*-
"""مؤثرات صوتية مولَّدة رياضياً (WAV أحادي 22.05kHz) — لا ملفات خارجية."""
import os
import wave
import numpy as np
from scipy import signal
from common import OUT

SR = 22050


def t_(d):
    return np.arange(int(SR * d)) / SR


def env(n, a=0.005, d=0.2, curve=3.0):
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-curve * t / max(d, 1e-3))
    return e


def lp(x, hz, order=3):
    b, a = signal.butter(order, hz / (SR / 2), "low")
    return signal.lfilter(b, a, x)


def hp(x, hz, order=3):
    b, a = signal.butter(order, hz / (SR / 2), "high")
    return signal.lfilter(b, a, x)


def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), hi / (SR / 2)], "band")
    return signal.lfilter(b, a, x)


def norm(x, peak=0.8):
    m = np.max(np.abs(x)) + 1e-9
    return x / m * peak


def write(name, x):
    x = np.clip(x, -1, 1)
    # تلاشٍ سريع في الطرفين لتفادي الطقطقة
    n = len(x)
    f = min(int(0.004 * SR), n // 4)
    x[:f] *= np.linspace(0, 1, f)
    x[-f:] *= np.linspace(1, 0, f)
    path = os.path.join(OUT, name + ".wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())
    print("  %-14s %5.2fs %5.0f KB" % (name, n / SR, os.path.getsize(path) / 1024))


def tap():
    n = int(SR * 0.09)
    r = np.random.default_rng(1)
    x = bp(r.normal(0, 1, n), 800, 3200) * env(n, 0.001, 0.02, 5)
    x += np.sin(2 * np.pi * 190 * t_(0.09)) * env(n, 0.001, 0.035, 5) * 0.8
    write("sfx_tap", norm(x, 0.55))


def page():
    n = int(SR * 0.42)
    r = np.random.default_rng(2)
    nz = r.normal(0, 1, n)
    x = bp(nz, 1500, 7000)
    t = np.arange(n) / SR
    e = (np.sin(np.pi * np.clip(t / 0.42, 0, 1)) ** 1.5) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t + 1))
    write("sfx_page", norm(x * e, 0.5))


def coin():
    t = t_(0.7)
    x = np.zeros_like(t)
    for f, a, d in ((2640, 1.0, 0.22), (3960, 0.7, 0.16), (5310, 0.45, 0.10), (1320, 0.4, 0.3)):
        x += a * np.sin(2 * np.pi * f * t + 0.3) * env(len(t), 0.0006, d, 4)
    x += hp(np.random.default_rng(3).normal(0, 1, len(t)), 4000) * env(len(t), 0.0005, 0.02, 5) * 0.25
    write("sfx_coin", norm(x, 0.6))


def stamp():
    n = int(SR * 0.32)
    t = np.arange(n) / SR
    thump = np.sin(2 * np.pi * (95 - 40 * t) * t) * env(n, 0.001, 0.09, 4) * 1.0
    r = np.random.default_rng(4)
    nz = lp(r.normal(0, 1, n), 1800) * env(n, 0.0008, 0.03, 5) * 0.7
    write("sfx_stamp", norm(thump + nz, 0.75))


def seal():
    n = int(SR * 0.36)
    t = np.arange(n) / SR
    r = np.random.default_rng(5)
    squish = lp(r.normal(0, 1, n), 700) * env(n, 0.012, 0.12, 4) * 0.9
    low = np.sin(2 * np.pi * (130 - 60 * t) * t) * env(n, 0.003, 0.1, 5)
    write("sfx_seal", norm(squish + low, 0.7))


def tick():
    n = int(SR * 0.05)
    r = np.random.default_rng(6)
    x = hp(r.normal(0, 1, n), 1500) * env(n, 0.0005, 0.008, 6) + np.sin(2 * np.pi * 1300 * np.arange(n) / SR) * env(n, 0.0005, 0.012, 6) * 0.6
    write("sfx_tick", norm(x, 0.45))


def bell():
    t = t_(1.5)
    x = np.zeros_like(t)
    for k, (m, a, d) in enumerate(((1.0, 1.0, 0.9), (2.0, 0.55, 0.6), (2.76, 0.5, 0.5), (5.4, 0.25, 0.3), (8.9, 0.12, 0.18))):
        x += a * np.sin(2 * np.pi * 523.25 * m * t) * env(len(t), 0.002, d, 4)
    write("sfx_bell", norm(x, 0.6))


def chime(notes, name, dur=0.28, decay=0.5, lowpass=None):
    total = dur * (len(notes) - 1) + 1.0
    x = np.zeros(int(SR * total))
    for i, f in enumerate(notes):
        t = t_(1.0)
        s = (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 3 * f * t)) * env(len(t), 0.004, decay, 4)
        o = int(i * dur * SR)
        x[o:o + len(s)] += s
    if lowpass:
        x = lp(x, lowpass)
    write(name, norm(x, 0.65))


def request():
    n = int(SR * 0.25)
    t = np.arange(n) / SR
    pop = np.sin(2 * np.pi * (520 + 700 * t) * t) * env(n, 0.002, 0.06, 5)
    r = np.random.default_rng(7)
    rus = bp(r.normal(0, 1, n), 2000, 6000) * env(n, 0.01, 0.07, 4) * 0.35
    write("sfx_request", norm(pop + rus, 0.55))


def build():
    tap(); page(); coin(); stamp(); seal(); tick(); bell(); request()
    chime([523.25, 659.25, 783.99, 1046.5], "sfx_win", 0.20, 0.6)
    chime([392.0, 329.63, 261.63], "sfx_lose", 0.32, 0.5, lowpass=1800)


if __name__ == "__main__":
    build()
