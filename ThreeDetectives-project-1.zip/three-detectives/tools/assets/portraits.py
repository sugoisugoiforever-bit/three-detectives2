# -*- coding: utf-8 -*-
"""14 صورة شخصية (0-7 رجال، 8-13 نساء) بتظليل مجسّم مبسّط ثم معالجة صورة فوتوغرافية قديمة."""
import numpy as np
import cv2
from common import *

S = 560  # دقة العمل (تُصغَّر إلى 280)
cx = S / 2

SK = {  # ألوان البشرة
    "fair": (236, 190, 160), "light": (224, 172, 138), "olive": (198, 146, 104), "tan": (176, 120, 82), "dark": (122, 78, 52),
}
HC = {"black": (28, 22, 20), "dkbrown": (56, 38, 28), "brown": (98, 66, 42), "gray": (150, 148, 146), "white": (206, 204, 200), "blond": (176, 140, 84)}

#            skin     hair     hair-style  facial   glasses clothes(color)       extra
PARAMS = [
    dict(skin="light", hc="black", hs="short", fh="mustache", gl=False, cl=(38, 40, 52), shirt=(236, 236, 236), tie=(120, 30, 40), w=1.00, bg=(92, 112, 122)),
    dict(skin="olive", hc="gray", hs="bald", fh="beard", gl=True, cl=(84, 84, 90), shirt=(220, 214, 200), tie=None, w=1.10, bg=(118, 104, 92)),
    dict(skin="fair", hc="brown", hs="side", fh="none", gl=False, cl=(52, 78, 120), shirt=(236, 236, 240), tie=None, w=0.98, bg=(104, 122, 108)),
    dict(skin="dark", hc="black", hs="curly", fh="stubble", gl=False, cl=(150, 64, 52), shirt=None, tie=None, w=1.06, bg=(96, 88, 110)),
    dict(skin="light", hc="gray", hs="short", fh="none", gl=True, cl=(46, 50, 64), shirt=(238, 238, 238), tie=(34, 54, 110), w=1.02, bg=(126, 118, 100)),
    dict(skin="tan", hc="black", hs="buzz", fh="goatee", gl=False, cl=(74, 90, 70), shirt=(214, 210, 196), tie=None, w=1.04, bg=(112, 96, 88)),
    dict(skin="light", hc="dkbrown", hs="slick", fh="mustache", gl=False, cl=(66, 52, 44), shirt=(240, 236, 226), tie=(150, 110, 40), w=0.96, bg=(86, 104, 118)),
    dict(skin="tan", hc="black", hs="short", fh="beard", gl=False, cl=(40, 44, 50), shirt=None, tie=None, w=1.08, bg=(120, 110, 100)),
    dict(skin="fair", hc="dkbrown", hs="long", fh="none", gl=False, cl=(150, 70, 96), shirt=None, tie=None, w=0.92, bg=(110, 124, 120), female=True),
    dict(skin="light", hc="brown", hs="bob", fh="none", gl=True, cl=(60, 90, 110), shirt=(238, 238, 240), tie=None, w=0.94, bg=(122, 110, 104), female=True),
    dict(skin="olive", hc="black", hs="hijab", fh="none", gl=False, cl=(34, 52, 100), shirt=None, tie=None, w=0.93, bg=(112, 112, 96), female=True, scarf=(36, 56, 108)),
    dict(skin="fair", hc="blond", hs="bun", fh="none", gl=False, cl=(180, 150, 90), shirt=(240, 236, 228), tie=None, w=0.90, bg=(96, 108, 124), female=True),
    dict(skin="light", hc="black", hs="hijab", fh="none", gl=True, cl=(110, 36, 52), shirt=None, tie=None, w=0.95, bg=(122, 116, 100), female=True, scarf=(124, 40, 60)),
    dict(skin="olive", hc="black", hs="side", fh="none", gl=False, cl=(44, 48, 60), shirt=(232, 230, 226), tie=None, w=0.93, bg=(100, 118, 112), female=True),
]


def ell(y, x, ex, ey, rx, ry):
    return ((x - ex) / rx) ** 2 + ((y - ey) / ry) ** 2


def dome(y, x, ex, ey, rx, ry):
    """ارتفاع مجسّم إهليلجي في [0,1] وقناع ناعم."""
    q = ell(y, x, ex, ey, rx, ry)
    hgt = np.sqrt(np.clip(1 - q, 0, 1))
    m = np.clip((1 - np.sqrt(q)) * min(rx, ry) / 2.0 + 0.5, 0, 1)
    return hgt, m


def shade(hgt, k=1.0, amb=0.28):
    gy, gx = np.gradient(hgt)
    nx, ny = -gx * S * 0.05 * k, -gy * S * 0.05 * k
    n = np.sqrt(nx * nx + ny * ny + 1)
    L = np.array([-0.55, -0.6, 0.58])
    L /= np.linalg.norm(L)
    d = np.clip((nx * L[0] + ny * L[1] + L[2]) / n, 0, 1)
    return amb + (1 - amb) * d


def put(img, col, mask, a=1.0):
    img[:] = img * (1 - (mask * a)[..., None]) + col * (mask * a)[..., None]


def portrait(idx):
    P = PARAMS[idx]
    r = np.random.default_rng(900 + idx)
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    female = P.get("female", False)
    skin = np.array(SK[P["skin"]], np.float32)
    hair = np.array(HC[P["hc"]], np.float32)
    # خلفية استوديو: تدرج ولمعة
    bgc = np.array(P["bg"], np.float32)
    img = np.zeros((S, S, 3), np.float32)
    img[:] = bgc * (0.62 + 0.55 * np.exp(-(((x - S * 0.42) / (S * 0.6)) ** 2 + ((y - S * 0.35) / (S * 0.7)) ** 2)))[..., None]
    img *= (0.94 + 0.12 * fbm(S, S, idx + 3, 4, 3))[..., None]

    fw = 0.165 * S * P["w"]
    fh = 0.215 * S
    hy = 0.405 * S
    # --- كتفان وملابس
    sh_h, sh_m = dome(y, x, cx, S * 1.05, S * 0.50, S * 0.34)
    cloth = np.array(P["cl"], np.float32)
    ccol = cloth[None, None, :] * shade(sh_h * 0.6, 0.8, 0.45)[..., None]
    fold = fbm(S, S, idx + 11, 4, 6, 0.6)
    ccol *= (0.85 + 0.3 * fold)[..., None]
    put(img, ccol, sh_m)
    # --- رقبة
    neck_m = np.clip(1 - np.abs(x - cx) / (fw * 0.52), 0, 1) ** 0.4 * np.clip((y - hy) / (S * 0.12), 0, 1) * np.clip((S * 0.76 - y) / 6.0, 0, 1)
    neck_m = np.clip(neck_m * 3, 0, 1) * (y < S * 0.78)
    nshade = 0.52 + 0.4 * np.clip(1 - np.abs(x - cx) / (fw * 0.52), 0, 1)
    nshade *= 0.55 + 0.45 * np.clip((y - hy - fh * 0.8) / (S * 0.1), 0, 1) ** -0.0 * 1.0
    put(img, skin[None, None, :] * (nshade * 0.78)[..., None], neck_m * (1 - 0.0))
    # ظل الفك على الرقبة
    jaw_shadow = np.exp(-(((y - (hy + fh * 0.88)) / (S * 0.035)) ** 2)) * np.clip(1 - np.abs(x - cx) / (fw * 0.6), 0, 1)
    img *= (1 - 0.45 * jaw_shadow * neck_m)[..., None]
    # --- ياقة / قميص / ربطة عنق
    if P["shirt"]:
        collar = np.zeros((S, S), np.float32)
        vy = S * (0.90 if P["tie"] else 0.86)
        pts = np.array([[cx - fw * 0.66, hy + fh * 0.93], [cx + fw * 0.66, hy + fh * 0.93], [cx, vy]], np.int32)
        cv2.fillPoly(collar, [pts], 1.0, cv2.LINE_AA)
        collar = blur(collar, 1.1)
        sc = np.array(P["shirt"], np.float32)[None, None, :] * (0.70 + 0.30 * np.clip(1 - np.abs(x - cx) / (fw * 0.7), 0, 1))[..., None]
        put(img, sc, collar * (y > hy + fh * 0.88))
        # ياقة مطوية على الجانبين
        for sgn in (-1, 1):
            fl = np.zeros((S, S), np.float32)
            cv2.fillPoly(fl, [np.array([[cx + sgn * fw * 0.30, hy + fh * 0.93], [cx + sgn * fw * 0.78, hy + fh * 0.98], [cx + sgn * fw * 0.36, hy + fh * 1.32]], np.int32)], 1.0, cv2.LINE_AA)
            put(img, np.array(P["shirt"], np.float32) * 0.92, blur(fl, 1.0), 0.9)
        if P["tie"]:
            tie = np.zeros((S, S), np.float32)
            cv2.fillPoly(tie, [np.array([[cx - 14, S * 0.69], [cx + 14, S * 0.69], [cx + 22, S * 0.98], [cx, S * 1.0], [cx - 22, S * 0.98]], np.int32)], 1.0, cv2.LINE_AA)
            tie = blur(tie, 1.0)
            tcol = np.array(P["tie"], np.float32)[None, None, :] * (0.7 + 0.35 * np.clip(1 - np.abs(x - cx) / 22, 0, 1))[..., None]
            put(img, tcol, tie)
            knot = disc_mask(y, x, cx, S * 0.685, 15, 11)
            put(img, np.array(P["tie"], np.float32) * 0.8, knot)
        # طيّات السترة (hlapel) على الجانبين
        for sgn in (-1, 1):
            lap = np.zeros((S, S), np.float32)
            cv2.line(lap, (int(cx + sgn * fw * 0.66), int(hy + fh * 0.95)), (int(cx), int(S * (0.90 if P["tie"] else 0.86))), 1.0, 5, cv2.LINE_AA)
            img *= (1 - 0.35 * blur(lap, 2.0))[..., None]
    # --- وشاح / حجاب
    hijab = P["hs"] == "hijab"
    if hijab:
        sc = np.array(P["scarf"], np.float32)
        hh_, hm_ = dome(y, x, cx, hy - fh * 0.05, fw * 1.42, fh * 1.22)
        drape = np.zeros((S, S), np.float32)
        cv2.fillPoly(drape, [np.array([[cx - fw * 1.35, hy + fh * 0.2], [cx + fw * 1.35, hy + fh * 0.2], [cx + S * 0.34, S * 0.90], [cx - S * 0.34, S * 0.90]], np.int32)], 1.0, cv2.LINE_AA)
        drape = blur(drape, 2.0)
        fab = fbm(S, S, idx + 21, 4, 9, 0.6)
        scol = sc[None, None, :] * (shade(hh_ * 0.9, 0.7, 0.40) * (0.80 + 0.5 * fab))[..., None]
        dcol = sc[None, None, :] * (0.50 + 0.4 * fab)[..., None] * (0.7 + 0.3 * np.clip(1 - np.abs(x - cx) / (S * 0.3), 0, 1))[..., None]
        put(img, dcol, drape)
        put(img, scol, hm_)
    # --- شعر خلفي (للطويل/كاريه)
    hairtex = blur(r.random((S, S)).astype(np.float32), 0.8, 5.0)
    hairtex = (hairtex - hairtex.min()) / (hairtex.max() - hairtex.min() + 1e-9)

    def hair_col(mask_h):
        return hair[None, None, :] * (shade(mask_h, 1.0, 0.30) * (0.65 + 0.7 * hairtex))[..., None] + 26 * np.clip(shade(mask_h, 1.0, 0.0) - 0.6, 0, 1)[..., None]

    hs = P["hs"]
    if hs in ("long", "bob", "pony", "bun") or (female and hs not in ("hijab",)):
        ry = fh * (1.55 if hs == "long" else 1.30)
        hb_h, hb_m = dome(y, x, cx, hy + fh * (0.45 if hs == "long" else 0.12), fw * (1.22 if hs == "long" else 1.26), ry)
        put(img, hair_col(hb_h) * 0.85, hb_m * (y < S * (0.84 if hs == "long" else 0.62)))
    # --- الرأس: قبة علوية + فك سفلي
    h1, m1 = dome(y, x, cx, hy, fw, fh)
    h2, m2 = dome(y, x, cx, hy + fh * 0.30, fw * 0.86, fh * 0.80)
    hh = np.maximum(h1, h2 * 0.97)
    mm = np.maximum(m1, m2)
    dif = shade(hh, 1.35, 0.30)
    scol = skin[None, None, :] * (dif * 1.05)[..., None]
    # أذنان
    for sgn in (-1, 1):
        eh, em = dome(y, x, cx + sgn * fw * 0.98, hy + fh * 0.08, fw * 0.14, fh * 0.20)
        put(img, skin[None, None, :] * (shade(eh, 1.0, 0.35) * 0.9)[..., None], em * (0 if hijab else 1))
    put(img, scol, mm)
    face = mm
    # عينان وحاجبان وأنف وفم
    ey = hy - fh * 0.02
    ex = fw * 0.40
    for sgn in (-1, 1):
        soc = np.exp(-ell(y, x, cx + sgn * ex, ey, fw * 0.30, fh * 0.095))
        img *= (1 - 0.32 * soc * face)[..., None]
        eye = np.exp(-ell(y, x, cx + sgn * ex, ey, fw * 0.17, fh * 0.040) * 2.2)
        put(img, np.array([32, 22, 18], np.float32), eye * face, 0.88)
        hl = np.exp(-ell(y, x, cx + sgn * ex - 3, ey - 2, 3.5, 3.0))
        put(img, np.array([238, 236, 232], np.float32), hl * face, 0.8)
        brow = np.zeros((S, S), np.float32)
        by = int(ey - fh * 0.13)
        cv2.line(brow, (int(cx + sgn * ex - fw * 0.20), by + 2), (int(cx + sgn * ex + fw * 0.20), by - (2 if sgn > 0 else 3)), 1.0, 5 if not female else 3, cv2.LINE_AA)
        put(img, hair * 0.9, blur(brow, 1.4) * face, 0.9)
    nose_sh = np.exp(-ell(y, x, cx + fw * 0.09, hy + fh * 0.30, fw * 0.17, fh * 0.07))
    img *= (1 - 0.28 * nose_sh * face)[..., None]
    nose_hl = np.exp(-ell(y, x, cx - fw * 0.05, hy + fh * 0.10, fw * 0.07, fh * 0.20))
    img += (22 * nose_hl * face)[..., None]
    my = hy + fh * 0.52
    mouth = np.zeros((S, S), np.float32)
    cv2.ellipse(mouth, (int(cx), int(my)), (int(fw * 0.30), int(fh * 0.035)), 0, 8, 172, 1.0, 3, cv2.LINE_AA)
    img *= (1 - 0.5 * blur(mouth, 1.2) * face)[..., None]
    lip = np.exp(-ell(y, x, cx, my + fh * 0.03, fw * 0.24, fh * 0.035))
    put(img, np.array([150, 70, 66], np.float32), lip * face, 0.22 if not female else 0.4)
    # تجاعيد/ظلال الخدّين
    for sgn in (-1, 1):
        ch = np.exp(-ell(y, x, cx + sgn * fw * 0.62, hy + fh * 0.40, fw * 0.28, fh * 0.34))
        img *= (1 - 0.10 * ch * face * (1 if sgn > 0 else 0.4))[..., None]
    # شعر الوجه
    fhs = P["fh"]
    if fhs != "none":
        lowerm = np.clip((y - (hy + fh * 0.22)) / 6.0, 0, 1) * face
        if fhs in ("beard", "goatee", "stubble"):
            if fhs == "beard":
                upper = hy + fh * (0.27 + 0.21 * np.clip(1 - np.abs(x - cx) / fw, 0, 1) ** 1.1)
                bm = face * np.clip((y - upper) / 5.0, 0, 1) * (ell(y, x, cx, hy + fh * 0.40, fw * 1.02, fh * 0.80) < 1.0)
            elif fhs == "goatee":
                bm = lowerm * (ell(y, x, cx, hy + fh * 0.78, fw * 0.40, fh * 0.28) < 1.0)
            else:
                bm = lowerm * 0.34
            bm = blur(bm.astype(np.float32), 1.6)
            put(img, hair_col(hh) * (0.9 + 0.2 * hairtex[..., None]), bm * (1 - 0.0), 0.95 if fhs != "stubble" else 1.0)
            # فتحة الفم تبقى ظاهرة
            put(img, np.array([120, 58, 54], np.float32), np.exp(-ell(y, x, cx, my + fh * 0.015, fw * 0.17, fh * 0.028)), 0.55 if fhs in ("beard", "goatee") else 0.0)
        if fhs in ("mustache", "beard", "goatee"):
            mu = np.exp(-ell(y, x, cx, hy + fh * 0.42, fw * 0.36, fh * 0.055) * 1.7)
            put(img, hair_col(hh), mu * face, 0.95)
    # نظارات
    if P["gl"]:
        gl = np.zeros((S, S), np.float32)
        for sgn in (-1, 1):
            cv2.ellipse(gl, (int(cx + sgn * ex), int(ey)), (int(fw * 0.31), int(fh * 0.155)), 0, 0, 360, 1.0, 3, cv2.LINE_AA)
        cv2.line(gl, (int(cx - ex + fw * 0.30), int(ey - 2)), (int(cx + ex - fw * 0.30), int(ey - 2)), 1.0, 3, cv2.LINE_AA)
        for sgn in (-1, 1):
            cv2.line(gl, (int(cx + sgn * (ex + fw * 0.31)), int(ey - 2)), (int(cx + sgn * fw * 1.02), int(ey - 6)), 1.0, 2, cv2.LINE_AA)
        gl = blur(gl, 0.9)
        put(img, np.array([22, 20, 22], np.float32), gl, 0.92)
        glare = np.exp(-ell(y, x, cx - ex * 1.05 - 6, ey - 6, fw * 0.10, fh * 0.05))
        img += (30 * glare)[..., None]
    # شعر الرأس
    if not hijab and hs != "bald":
        capc = {"short": (0.07, 1.03, 0.62), "buzz": (0.05, 1.02, 0.50), "side": (0.10, 1.07, 0.66), "slick": (0.08, 1.04, 0.58),
                "curly": (0.10, 1.12, 0.64), "long": (0.07, 1.06, 0.56), "bob": (0.08, 1.07, 0.58), "bun": (0.08, 1.05, 0.58), "pony": (0.07, 1.04, 0.56)}[hs]
        up, wid, line = capc
        ch, cm = dome(y, x, cx, hy - fh * up, fw * wid, fh * 1.04)
        hairline = np.clip((hy - fh * (line - 0.28) - y + (np.abs(x - cx) / fw) ** 2 * fh * 0.22) / 5.0, 0, 1)
        side_part = 0.0
        if hs == "side":
            part = np.clip((x - (cx - fw * 0.35)) / 7.0, 0, 1)
            hairline = np.maximum(hairline, np.clip((hy - fh * 0.46 - y + (x - cx + fw * 0.2) * 0.35) / 5.0, 0, 1) * (x > cx - fw * 0.2))
        if hs in ("long", "bob") or (female and hs in ("pony", "bun")):
            # فرق في الوسط: الشعر يغطي الجبهة جزئياً
            hairline = np.clip((hy - fh * 0.34 - y + (np.abs(x - cx) / fw) ** 1.6 * fh * 0.55) / 5.0, 0, 1)
        hm = cm * hairline * (1 - 0.0)
        hh2 = np.maximum(ch, 0.0)
        put(img, hair_col(hh2 * 1.0 + 0.2 * hairtex), np.clip(hm, 0, 1))
        if hs == "curly":
            for _ in range(240):
                a = r.uniform(np.pi * 1.05, np.pi * 1.95)
                rr_ = r.uniform(0.85, 1.12)
                px = cx + np.cos(a) * fw * rr_ * 1.04
                py = hy + np.sin(a) * fh * rr_ * 1.0 - fh * 0.04
                rad = r.uniform(7, 13)
                cd, cmk = dome(y, x, px, py, rad, rad)
                put(img, hair * (0.5 + 0.7 * shade(cd, 1.0, 0.3))[..., None] * 1.0, cmk * (y < hy - fh * 0.1))
        if hs == "bun":
            bh, bm = dome(y, x, cx, hy - fh * 1.12, fw * 0.42, fw * 0.38)
            put(img, hair_col(bh), bm)
        if hs == "pony":
            pm = np.zeros((S, S), np.float32)
            cv2.ellipse(pm, (int(cx + fw * 1.25), int(hy + fh * 0.55)), (int(fw * 0.20), int(fh * 0.72)), 12, 0, 360, 1.0, -1, cv2.LINE_AA)
            put(img, hair_col(blur(pm, 6)), blur(pm, 1.2) * (y < S * 0.80) * 0.95)
    elif hs == "bald":
        sheen = np.exp(-ell(y, x, cx - fw * 0.28, hy - fh * 0.62, fw * 0.32, fh * 0.16))
        img += (36 * sheen * face)[..., None]
        ring = np.clip((ell(y, x, cx, hy, fw * 1.0, fh * 1.0) - 0.55) * 2, 0, 1) * (y < hy - fh * 0.2) * face * (0 if False else 1)
        put(img, hair * 0.55, ring * 0.35)
    # --- معالجة الصورة القديمة
    lum = img.mean(axis=2, keepdims=True)
    sep = lum * np.array([1.10, 0.90, 0.68], np.float32)[None, None, :]
    img = img * 0.28 + sep * 0.72
    img = np.clip(img, 0, 255)
    img = 255 * ((img / 255.0 - 0.5) * 1.12 + 0.52).clip(0, 1) ** 1.05
    img *= vignette(S, S, 2.0, 0.55)[..., None]
    img = cv2.GaussianBlur(img, (0, 0), 1.35)
    img += grain(S, S, 70 + idx, 7.5)
    # خدوش وغبار صغيرة
    sc = np.zeros((S, S), np.float32)
    for _ in range(9):
        x0, y0 = r.uniform(0, S), r.uniform(0, S)
        ang = r.uniform(0, np.pi)
        ln = r.uniform(10, 60)
        cv2.line(sc, (int(x0), int(y0)), (int(x0 + ln * np.cos(ang)), int(y0 + ln * np.sin(ang))), 1.0, 1, cv2.LINE_AA)
    img += (blur(sc, 0.7) * 30)[..., None]
    out = to_img(img)
    return out.resize((280, 280), Image.LANCZOS)


def disc_mask(y, x, ex, ey, rx, ry):
    return np.clip((1 - np.sqrt(ell(y, x, ex, ey, rx, ry))) * min(rx, ry) / 1.5 + 0.5, 0, 1)


def build():
    for i in range(14):
        save(portrait(i), "portrait_%02d" % i, quality=88)


if __name__ == "__main__":
    build()
