# -*- coding: utf-8 -*-
"""لوحة فلين بإطار من خشب البلوط الداكن."""
import numpy as np
import cv2
from common import *
from wood import plank

CORK = [(0.0, (118, 76, 44)), (0.35, (160, 112, 70)), (0.7, (192, 142, 92)), (1.0, (222, 176, 120))]
OAK = [(0.0, (36, 22, 13)), (0.4, (64, 40, 24)), (0.75, (92, 60, 36)), (1.0, (122, 82, 50))]


def cork_tex(h, w, seed):
    r = np.random.default_rng(seed)
    n = r.random((h, w)).astype(np.float32)
    chunks = blur(n, 2.2) - blur(n, 6.0)
    chunks = (chunks - chunks.min()) / (chunks.max() - chunks.min() + 1e-9)
    fine = blur(r.random((h, w)).astype(np.float32), 0.8)
    low = fbm(h, w, seed + 1, 4, 5, 0.55)
    holes = (r.random((h, w)) > 0.9935).astype(np.float32)
    holes = np.clip(blur(holes, 2.2) * 28, 0, 1)
    dark = (r.random((h, w)) > 0.985).astype(np.float32)
    dark = np.clip(blur(dark, 1.3) * 9, 0, 1)
    t = np.clip(0.30 + 0.38 * chunks + 0.12 * fine + 0.22 * low - 0.45 * holes - 0.18 * dark, 0, 1)
    col = cmap(t, CORK)
    height = chunks * 1.1 + fine * 0.3 - holes * 1.5
    diff, spec = light(height * 3.2, strength=1.7, spec=0.05, amb=0.58)
    return col * diff[..., None]


def frame_wood(h, w, seed):
    hz, _ = plank(h, w, seed, 1.0)
    vt, _ = plank(w, h, seed + 5, 1.0)
    vt = np.rot90(vt, 1).copy()
    return hz, vt


def corkboard(w=1000, h=760, B=40, pad=44, seed=41):
    cork = cork_tex(h, w, seed)
    hz, vt = frame_wood(h, w, seed + 2)
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    dl, dr, dt, db = x, w - 1 - x, y, h - 1 - y
    dmin = np.minimum(np.minimum(dl, dr), np.minimum(dt, db))
    vertical = np.minimum(dl, dr) < np.minimum(dt, db)
    frame = np.where(vertical[..., None], vt, hz)
    # الإطار: لون بلوط داكن
    lum = (frame.mean(axis=2) / 142.0)
    fcol = cmap(np.clip(lum * 0.9, 0, 1), OAK)
    inside = (dmin < B).astype(np.float32)
    # شطف (bevel) خارجي وداخلي
    bev = np.clip(dmin / 9.0, 0, 1) * np.clip((B - dmin) / 7.0, 0, 1)
    hmap = bev * 3.0 + lum * 0.4
    diff, spec = light(hmap, strength=2.2, spec=0.55, shin=20, amb=0.5)
    fcol = fcol * diff[..., None] + (spec * 255 * 0.5)[..., None]
    # ظل الإطار على الفلين (الضوء من أعلى اليسار)
    sh = np.zeros((h, w), np.float32)
    sh[B - 2:h - B + 2, B - 2:w - B + 2] = 1
    shm = 1 - blur(np.roll(np.roll(sh, 7, axis=0), 7, axis=1), 9)
    shm = np.clip(shm, 0, 1) * (1 - inside)
    img = cork * (1 - 0.6 * shm[..., None] * 0.9)[...] * (1 - inside[..., None]) + fcol * inside[..., None]
    # مسامير نحاسية في الزوايا
    for (cx, cy) in ((20, 20), (w - 21, 20), (20, h - 21), (w - 21, h - 21)):
        d = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
        m = np.clip(7 - d, 0, 1)
        shade = 0.6 + 0.6 * np.clip(1 - np.sqrt((x - cx + 2) ** 2 + (y - cy + 2) ** 2) / 8, 0, 1)
        nail = np.array([186, 142, 74], np.float32)[None, None, :] * shade[..., None]
        img = img * (1 - m[..., None]) + nail * m[..., None]
        ring = np.exp(-((d - 8.2) / 0.9) ** 2) * 0.55
        img *= (1 - ring[..., None])
    mask = rounded_mask(h, w, 12)
    H, W = h + pad * 2, w + pad * 2
    canvas = np.zeros((H, W, 3), np.float32)
    alpha = np.zeros((H, W), np.float32)
    canvas[pad:pad + h, pad:pad + w] = img
    alpha[pad:pad + h, pad:pad + w] = mask
    sh2 = drop_shadow(alpha, 8, 14, 14, 0.6)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    canvas *= (0.90 + 0.18 * np.exp(-(((xx - W * 0.35) / (W * 0.9)) ** 2 + ((yy - H * 0.2) / (H * 0.9)) ** 2)))[..., None]
    out_a = np.clip(alpha + sh2 * (1 - alpha), 0, 1)
    return to_img(canvas * alpha[..., None], out_a * 255), (pad, pad, w, h, B)


if __name__ == "__main__":
    im, meta = corkboard()
    print("  corkboard meta (pad, pad, w, h, border):", meta)
    save(im, "corkboard", quality=88)
