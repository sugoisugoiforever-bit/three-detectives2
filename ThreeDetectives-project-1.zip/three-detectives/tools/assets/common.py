# -*- coding: utf-8 -*-
"""أدوات مشتركة لتوليد الرسومات الواقعية بالتظليل الرقمي (بلا أي صور خارجية)."""
import os
import numpy as np
import cv2
from PIL import Image

OUT = os.environ.get("ASSET_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "out"))
os.makedirs(OUT, exist_ok=True)


def fbm(h, w, seed, octaves=5, base=6, persistence=0.55, aspect=1.0):
    """ضجيج كسوري متعدد الطبقات في [0,1]. aspect>1 يمدد الطبقات أفقياً."""
    r = np.random.default_rng(seed)
    out = np.zeros((h, w), np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        gh = max(2, int(base * 2 ** o))
        gw = max(2, int(base * 2 ** o * (w / h) / aspect))
        g = r.random((gh, gw)).astype(np.float32)
        out += amp * cv2.resize(g, (w, h), interpolation=cv2.INTER_CUBIC)
        tot += amp
        amp *= persistence
    out /= tot
    lo, hi = out.min(), out.max()
    return (out - lo) / (hi - lo + 1e-9)


def blur(a, sx, sy=None):
    sy = sx if sy is None else sy
    return cv2.GaussianBlur(a, (0, 0), sigmaX=max(sx, 0.01), sigmaY=max(sy, 0.01))


def cmap(t, stops):
    """t في [0,1] → RGB عبر نقاط لونية [(pos,(r,g,b)),...] وتعيد مصفوفة (...,3) float 0..255."""
    pos = [p for p, _ in stops]
    chans = [np.interp(t, pos, [c[i] for _, c in stops]) for i in range(3)]
    return np.stack(chans, axis=-1).astype(np.float32)


def normals_from_height(hmap, strength=1.0):
    gy, gx = np.gradient(hmap.astype(np.float32))
    nx, ny = -gx * strength, -gy * strength
    nz = np.ones_like(nx)
    n = np.sqrt(nx * nx + ny * ny + nz * nz)
    return nx / n, ny / n, nz / n


def light(hmap, strength=2.0, ldir=(-0.45, -0.55, 0.70), shin=24, spec=0.25, amb=0.55):
    """تظليل مشتت + لمعان مرآوي من خريطة ارتفاعات. يعيد (diffuse, specular)."""
    nx, ny, nz = normals_from_height(hmap, strength)
    L = np.array(ldir, np.float32)
    L /= np.linalg.norm(L)
    d = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
    H = L + np.array([0, 0, 1], np.float32)
    H /= np.linalg.norm(H)
    s = np.clip(nx * H[0] + ny * H[1] + nz * H[2], 0, 1) ** shin
    diffuse = amb + (1 - amb) * d / max(L[2], 0.01) * 0.8
    return diffuse, s * spec


def vignette(h, w, power=2.2, strength=0.55, cx=0.5, cy=0.5):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    dx = (x / w - cx) * 2
    dy = (y / h - cy) * 2
    r = np.sqrt(dx * dx + dy * dy) / 1.414
    return 1 - strength * np.clip(r, 0, 1) ** power


def to_img(a, alpha=None):
    a = np.clip(a, 0, 255).astype(np.uint8)
    if alpha is None:
        return Image.fromarray(a, "RGB")
    al = np.clip(alpha, 0, 255).astype(np.uint8)
    return Image.fromarray(np.dstack([a, al]), "RGBA")


def save(img, name, quality=90, lossless=False, scale=None):
    if scale:
        img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
    path = os.path.join(OUT, name + ".webp")
    img.save(path, "WEBP", quality=quality, lossless=lossless, method=6)
    kb = os.path.getsize(path) / 1024
    print("  %-22s %4dx%-4d %6.0f KB" % (name, img.width, img.height, kb))
    return path


def grain(h, w, seed, amount=6.0):
    r = np.random.default_rng(seed)
    g = r.normal(0, 1, (h, w)).astype(np.float32)
    return (g * amount)[..., None]


def drop_shadow(alpha, dx, dy, sigma, opacity):
    """يرسم ظل ساقط من قناة ألفا (0..1) ويعيده كقناة ألفا للظل."""
    h, w = alpha.shape
    M = np.float32([[1, 0, dx], [0, 1, dy]])
    sh = cv2.warpAffine(alpha, M, (w, h))
    return blur(sh, sigma) * opacity


def composite_rgba(base_rgb, over_rgb, over_a):
    a = over_a[..., None] if over_a.ndim == 2 else over_a
    return base_rgb * (1 - a) + over_rgb * a


def rounded_mask(h, w, r, inset=0):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    cx = np.clip(x, inset + r, w - 1 - inset - r)
    cy = np.clip(y, inset + r, h - 1 - inset - r)
    d = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    inside = (x >= inset) & (x <= w - 1 - inset) & (y >= inset) & (y <= h - 1 - inset)
    return np.clip(r + 0.5 - d, 0, 1) * inside
