# -*- coding: utf-8 -*-
"""أوراق قديمة واقعية: ألياف، بقع تقادم، طيّات، حواف غير منتظمة."""
import numpy as np
import cv2
from common import *


def rough_edge_alpha(h, w, seed, wobble=3.0, inset=5):
    """حافة ورقة غير منتظمة: الضجيج يؤثر على شريط الحافة فقط، والداخل معتم تماماً."""
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    dist = np.minimum(np.minimum(x, w - 1 - x), np.minimum(y, h - 1 - y))
    n = (fbm(h, w, seed + 7, 4, 60, 0.6) - 0.5) * 2
    n2 = np.random.default_rng(seed).random((h, w)).astype(np.float32) - 0.5
    d = dist - inset + n * wobble + n2 * 0.9
    return np.clip(d + 0.5, 0, 1)


def paper(w, h, seed, base=(238, 226, 196), aged=1.0, rules=None, margin=False, fold=True, rough=True):
    r = np.random.default_rng(seed)
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    # تبقّع لوني منخفض التردد
    mott = fbm(h, w, seed + 1, 4, 3, 0.55)
    mott2 = fbm(h, w, seed + 2, 5, 14, 0.55)
    col = np.zeros((h, w, 3), np.float32)
    col[:] = np.array(base, np.float32)
    col *= (0.955 + 0.075 * mott + 0.03 * mott2)[..., None]
    # ألياف: خطوط قصيرة عشوائية الاتجاه
    fibres = np.zeros((h, w), np.float32)
    for _ in range(int(w * h / 900)):
        x0, y0 = r.uniform(0, w), r.uniform(0, h)
        ang = r.uniform(0, np.pi)
        ln = r.uniform(5, 22)
        cv2.line(fibres, (int(x0), int(y0)), (int(x0 + ln * np.cos(ang)), int(y0 + ln * np.sin(ang))), float(r.uniform(0.3, 1)), 1, cv2.LINE_AA)
    fibres = blur(fibres, 0.5)
    col *= (1 - 0.045 * fibres)[..., None]
    # تقادم: اصفرار وغمق نحو الحواف
    ex = np.minimum(x, w - 1 - x) / w
    ey = np.minimum(y, h - 1 - y) / h
    edge = np.clip(1 - np.minimum(ex * 7, ey * 5.2), 0, 1) ** 1.6
    blot = fbm(h, w, seed + 3, 5, 4, 0.6)
    age = np.clip(edge * (0.55 + 0.9 * blot) * aged, 0, 1)
    col = col * (1 - age[..., None] * 0.32) + age[..., None] * np.array([150, 104, 52], np.float32) * 0.22
    # بقع تعتّق (foxing) وبقعة قهوة
    for _ in range(int(14 * aged)):
        cx, cy, rad = r.uniform(0, w), r.uniform(0, h), r.uniform(3, 14)
        m = np.exp(-(((x - cx) ** 2 + (y - cy) ** 2) / (rad * rad)))
        col *= (1 - 0.22 * m)[..., None] * 1 + (0.0)
        col += (m * 8)[..., None] * np.array([1.0, 0.45, 0.1])
    if aged > 0.2:
        cx, cy, rad = w * r.uniform(0.15, 0.85), h * r.uniform(0.1, 0.9), r.uniform(46, 70)
        ring = np.abs(np.sqrt((x - cx) ** 2 + (y - cy) ** 2) - rad)
        m = np.exp(-(ring / 2.4) ** 2) * 0.28 * (0.5 + 0.5 * mott2)
        inner = np.clip(1 - np.sqrt((x - cx) ** 2 + (y - cy) ** 2) / rad, 0, 1) * 0.06
        col *= (1 - (m + inner)[..., None] * np.array([0.5, 0.8, 1.2], np.float32))
    # سطور (ورقة مسطرة) وهامش
    if rules:
        gap, rc = rules
        for yy in range(int(gap * 2.2), h - 20, gap):
            line = np.exp(-(((y - yy) / 0.9) ** 2)) * 0.5
            col *= (1 - line[..., None] * (1 - np.array(rc, np.float32) / 255.0) * 0.9)
    if margin:
        mx = int(w * 0.13)
        m = np.exp(-(((x - mx) / 0.9) ** 2)) * 0.55
        col *= (1 - m[..., None] * (1 - np.array([200, 80, 80], np.float32) / 255.0))
    # طيّات أفقية ناعمة
    hmap = fibres * 0.3 + mott2 * 0.2
    if fold:
        for fy in (h * 0.333, h * 0.667):
            fy += r.uniform(-6, 6)
            g = np.exp(-(((y - fy) / 3.0) ** 2))
            hmap += g * 1.2 - np.exp(-(((y - fy - 5) / 6.0) ** 2)) * 0.6
    diff, spec = light(hmap * 2.2, strength=1.4, spec=0.0, amb=0.82)
    col *= diff[..., None]
    # إضاءة عامة ناعمة
    col *= (0.93 + 0.12 * np.exp(-(((x - w * 0.4) / (w * 0.9)) ** 2 + ((y - h * 0.25) / (h * 1.0)) ** 2)))[..., None]
    col += grain(h, w, seed + 9, 1.6)
    alpha = rough_edge_alpha(h, w, seed) * 255 if rough else np.full((h, w), 255, np.float32)
    return to_img(col, alpha)


def build():
    save(paper(760, 1040, 21, (240, 228, 198), 1.0), "paper_cream", quality=86)
    save(paper(760, 1040, 22, (236, 236, 226), 0.55), "paper_white", quality=86)
    save(paper(760, 1040, 23, (240, 224, 150), 0.8, rules=(34, (150, 170, 200)), margin=True, fold=False), "paper_legal", quality=86)


if __name__ == "__main__":
    build()
