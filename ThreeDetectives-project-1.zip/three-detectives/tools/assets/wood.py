# -*- coding: utf-8 -*-
"""سطح مكتب من خشب الجوز بألواح أفقية وتظليل وورنيش."""
import numpy as np
import cv2
from common import *

WALNUT = [(0.00, (30, 17, 10)), (0.30, (58, 34, 20)), (0.55, (84, 52, 31)), (0.80, (112, 72, 44)), (1.00, (142, 96, 60))]


def plank(h, w, seed, tone=1.0):
    r = np.random.default_rng(seed)
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    warp = fbm(h, w, seed + 1, 3, 2, 0.5, aspect=12.0)
    warp2 = fbm(h, w, seed + 2, 4, 3, 0.5, aspect=7.0)
    # حلقات النمو: خطوط شبه متوازية تتموج ببطء مع أقواس "كاتدرائية" عرضية
    rings = 0.5 + 0.5 * np.sin((y / h * r.uniform(11, 19) + warp * 2.1 + warp2 * 0.55) * 2 * np.pi)
    rings = rings ** 1.25
    # ألياف طولية دقيقة
    fib = r.random((h, w)).astype(np.float32)
    fib = blur(fib, 38, 0.7)
    fib = (fib - fib.min()) / (fib.max() - fib.min() + 1e-9)
    fib2 = blur(r.random((h, w)).astype(np.float32), 14, 0.5)
    fib2 = (fib2 - fib2.min()) / (fib2.max() - fib2.min() + 1e-9)
    # مسام داكنة قصيرة
    p = (r.random((h, w)) > 0.992).astype(np.float32)
    pores = np.clip(blur(p, 7, 0.6) * 9, 0, 1)
    t = 0.34 * rings + 0.30 * fib + 0.16 * fib2 + 0.20 * warp
    t = np.clip((t - 0.2) * 1.45, 0, 1) * tone
    col = cmap(np.clip(t, 0, 1), WALNUT)
    col *= (1 - 0.38 * pores[..., None])
    height = 0.55 * fib2 + 0.35 * fib - 0.6 * pores + 0.2 * rings
    return col, height


def desk(w=1600, h=900, seed=11):
    boards = 5
    bh = h // boards + 1
    col = np.zeros((h, w, 3), np.float32)
    hmap = np.zeros((h, w), np.float32)
    r = np.random.default_rng(seed)
    y = 0
    for i in range(boards):
        hh = min(bh + int(r.integers(-10, 12)), h - y)
        if hh <= 0:
            break
        c, hm = plank(hh, w, seed * 7 + i * 13, tone=r.uniform(0.86, 1.08))
        # لون اللوح يميل قليلاً حسب اللوح
        shift = np.array([r.uniform(-6, 8), r.uniform(-4, 5), r.uniform(-4, 4)], np.float32)
        col[y:y + hh] = c + shift
        hmap[y:y + hh] = hm
        # شق بين الألواح
        if y > 0:
            hmap[y - 1:y + 2] -= 1.6
            col[y - 2:y + 1] *= 0.42
            col[y + 1:y + 3] *= 1.14
        y += hh
    diff, spec = light(hmap * 3.0, strength=1.6, spec=0.35, shin=18, amb=0.62)
    img = col * diff[..., None]
    # ورنيش: بقعة ضوء كبيرة ناعمة من مصباح مكتب في الأعلى الأيسر + لمعان مرآوي واسع
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    lamp = np.exp(-(((xx - w * 0.30) / (w * 0.62)) ** 2 + ((yy - h * 0.18) / (h * 0.85)) ** 2))
    img *= (0.50 + 0.75 * lamp)[..., None]
    sheen = blur(fbm(h, w, seed + 91, 3, 2, 0.5), 60) * lamp
    img += (spec * 255 * 0.55)[..., None] * (0.35 + 0.65 * lamp[..., None])
    img += (sheen * 22)[..., None] * np.array([1.0, 0.85, 0.65])
    # خدوش رفيعة وبقع غبار
    sc = np.zeros((h, w), np.float32)
    for _ in range(70):
        x0, y0 = r.uniform(0, w), r.uniform(0, h)
        ang = r.uniform(-0.5, 0.5) + (np.pi if r.random() < 0.5 else 0)
        ln = r.uniform(30, 190)
        cv2.line(sc, (int(x0), int(y0)), (int(x0 + ln * np.cos(ang)), int(y0 + ln * np.sin(ang))), float(r.uniform(0.2, 0.9)), 1, cv2.LINE_AA)
    sc = blur(sc, 0.6)
    img += (sc * 38)[..., None] * (0.4 + 0.6 * lamp[..., None])
    dust = (r.random((h, w)) > 0.9993).astype(np.float32)
    img += (blur(dust, 1.2) * 400)[..., None] * 0.5
    # أثر كوب قهوة
    for (cx, cy, rad, a) in ((w * 0.12, h * 0.86, 62, 0.22), (w * 0.9, h * 0.1, 48, 0.14)):
        ring = np.abs(np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) - rad)
        m = np.exp(-(ring / 2.6) ** 2) * a * (0.6 + 0.4 * fbm(h, w, seed + 5, 3, 8))
        img *= (1 - m[..., None] * 0.9)
    img *= vignette(h, w, 2.0, 0.60)[..., None]
    img += grain(h, w, seed + 3, 2.2)
    return to_img(img)


if __name__ == "__main__":
    save(desk(), "desk_wood", quality=86)
