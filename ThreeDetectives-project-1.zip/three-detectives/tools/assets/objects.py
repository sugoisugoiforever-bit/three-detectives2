# -*- coding: utf-8 -*-
"""أدوات صغيرة: دبابيس، عملات نحاسية، ختم شمعي، ورقة لاصقة."""
import numpy as np
import cv2
from common import *

SS = 3  # تكبير فائق لنعومة الحواف


def disc(h, w, cx, cy, r, soft=1.2):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    return np.clip((r - np.sqrt((x - cx) ** 2 + (y - cy) ** 2)) / soft + 0.5, 0, 1)


def sphere_shade(h, w, cx, cy, r, base, spec=0.9, shin=40, amb=0.35):
    """تظليل قبة كروية: يعيد (rgb, mask)."""
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    dx, dy = (x - cx) / r, (y - cy) / r
    rr = dx * dx + dy * dy
    m = np.clip((1 - np.sqrt(rr)) * r / 1.2 + 0.5, 0, 1)
    nz = np.sqrt(np.clip(1 - rr, 0, 1))
    L = np.array([-0.5, -0.6, 0.62], np.float32)
    L /= np.linalg.norm(L)
    d = np.clip(dx * L[0] + dy * L[1] + nz * L[2], 0, 1)
    Hh = L + np.array([0, 0, 1], np.float32)
    Hh /= np.linalg.norm(Hh)
    s = np.clip(dx * Hh[0] + dy * Hh[1] + nz * Hh[2], 0, 1) ** shin
    col = np.array(base, np.float32)[None, None, :] * (amb + (1 - amb) * d)[..., None]
    col += (s * 255 * spec)[..., None]
    return col, m


def pin(color, size=112):
    S = size
    cx, cy = S * 0.46, S * 0.44
    alpha = np.zeros((S, S), np.float32)
    # ظل
    sh = disc(S, S, cx + 8, cy + 11, S * 0.30, 3.0)
    sh = blur(sh, 4.5) * 0.5
    img = np.zeros((S, S, 3), np.float32)
    # قاعدة مسطّحة داكنة ثم القبة
    base_col, bm = sphere_shade(S, S, cx, cy, S * 0.31, [c * 0.55 for c in color], spec=0.1, shin=8, amb=0.5)
    dome_col, dm = sphere_shade(S, S, cx - 1, cy - 2, S * 0.235, color, spec=1.0, shin=36, amb=0.32)
    img = base_col * bm[..., None]
    img = img * (1 - dm[..., None]) + dome_col * dm[..., None]
    a = np.clip(bm + sh * (1 - bm), 0, 1)
    return to_img(img, a * 255)


BRASS = [(0.0, (64, 42, 14)), (0.35, (140, 98, 36)), (0.65, (206, 158, 72)), (0.85, (244, 206, 118)), (1.0, (255, 240, 190))]


def star_poly(cx, cy, r1, r2, n=5, rot=-np.pi / 2):
    pts = []
    for i in range(n * 2):
        r = r1 if i % 2 == 0 else r2
        a = rot + i * np.pi / n
        pts.append([cx + r * np.cos(a), cy + r * np.sin(a)])
    return np.array(pts, np.float32)


def coin(size=176, filled=True, seed=3):
    S = size * SS
    cx = cy = S / 2
    R = S * 0.42
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    rr = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    if filled:
        h = np.zeros((S, S), np.float32)
        h += np.clip((R - rr) / 3.0, 0, 1) * 1.0
        ring = np.exp(-((rr - R * 0.92) / (R * 0.045)) ** 2)
        h += ring * 1.1
        # حافة مخرّشة
        ang = np.arctan2(y - cy, x - cx)
        reed = (0.5 + 0.5 * np.cos(ang * 64)) * np.exp(-((rr - R * 0.985) / (R * 0.03)) ** 2)
        h += reed * 0.5
        # نجمة بارزة
        st = np.zeros((S, S), np.float32)
        cv2.fillPoly(st, [(star_poly(cx, cy, R * 0.55, R * 0.23) * 1).astype(np.int32)], 1.0, cv2.LINE_AA)
        st = blur(st, SS * 0.8)
        h += st * 0.9
        inner = np.clip((R * 0.78 - rr) / 2.0, 0, 1) * 0.12
        h += inner
        h = blur(h, SS * 0.8)
        diff, spec = light(h * 14.0, strength=2.0, spec=1.0, shin=22, amb=0.35)
        t = np.clip(0.18 + 0.52 * diff + 1.4 * spec, 0, 1)
        col = cmap(t, BRASS)
        col *= (0.9 + 0.1 * fbm(S, S, seed, 3, 12))[..., None]
        m = np.clip((R - rr) / 1.5 + 0.5, 0, 1)
    else:
        # فتحة فارغة: تجويف داكن بحافة معدنية خافتة
        h = np.zeros((S, S), np.float32)
        h -= np.clip((R - rr) / 6.0, 0, 1) * 1.2
        h += np.exp(-((rr - R) / (R * 0.04)) ** 2) * 0.8
        h = blur(h, SS * 0.9)
        diff, spec = light(h * 10.0, strength=1.8, spec=0.5, shin=20, amb=0.5)
        base = np.array([30, 20, 14], np.float32)
        col = base[None, None, :] * (0.55 + 0.7 * diff)[..., None] + (spec * 255 * 0.28)[..., None] * np.array([1, 0.8, 0.5])
        m = np.clip((R * 1.04 - rr) / 1.5 + 0.5, 0, 1)
    sh = blur(np.roll(np.roll(m, 5 * SS, axis=0), 4 * SS, axis=1), 4 * SS) * (0.5 if filled else 0.0)
    a = np.clip(m + sh * (1 - m), 0, 1)
    img = to_img(col * m[..., None], a * 255)
    return img.resize((size, size), Image.LANCZOS)


def wax_seal(size=224, pressed=True, seed=5):
    S = size * SS
    cx = cy = S / 2
    r = np.random.default_rng(seed)
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    ang = np.arctan2(y - cy, x - cx)
    rr = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    lobes = sum(r.uniform(0.01, 0.04) * np.cos(ang * k + r.uniform(0, 6.28)) for k in (3, 5, 7, 11))
    R = S * 0.40 * (1 + lobes)
    body = np.clip((R - rr) / 2.0 + 0.5, 0, 1)
    h = np.clip((R - rr) / (S * 0.05), 0, 1) * 1.2
    ring = np.exp(-((rr - S * 0.27) / (S * 0.018)) ** 2)
    h += ring * (0.9 if pressed else 0.25)
    inner = np.clip((S * 0.255 - rr) / (S * 0.02), 0, 1)
    h -= inner * (0.55 if pressed else 0.05)
    emb = np.zeros((S, S), np.float32)
    if pressed:
        # عدسة مكبّرة بارزة في المنتصف
        cv2.circle(emb, (int(cx - S * 0.03), int(cy - S * 0.03)), int(S * 0.095), 1.0, int(S * 0.026), cv2.LINE_AA)
        cv2.line(emb, (int(cx + S * 0.045), int(cy + S * 0.045)), (int(cx + S * 0.12), int(cy + S * 0.12)), 1.0, int(S * 0.036), cv2.LINE_AA)
        # ثلاث نقاط (ثلاثة محققين)
        for k in (-1, 0, 1):
            cv2.circle(emb, (int(cx + k * S * 0.075), int(cy - S * 0.15)), int(S * 0.012), 1.0, -1, cv2.LINE_AA)
    emb = blur(emb, SS * 0.9)
    h += emb * 0.9
    wob = fbm(S, S, seed + 1, 4, 8, 0.5)
    h = blur(h + wob * 0.12, SS * 0.7)
    diff, spec = light(h * 16.0, strength=2.2, spec=1.0, shin=28, amb=0.32)
    base = np.array([158, 22, 28] if pressed else [132, 20, 26], np.float32)
    col = base[None, None, :] * (0.28 + 0.95 * diff)[..., None] + (spec * 255 * 0.7)[..., None]
    col *= (0.93 + 0.14 * wob)[..., None]
    sh = blur(np.roll(np.roll(body, 6 * SS, axis=0), 5 * SS, axis=1), 6 * SS) * 0.55
    a = np.clip(body + sh * (1 - body), 0, 1)
    img = to_img(col * body[..., None], a * 255)
    return img.resize((size, size), Image.LANCZOS)


def sticky(size=300, seed=7):
    S = size
    r = np.random.default_rng(seed)
    y, x = np.mgrid[0:S, 0:S].astype(np.float32)
    pad = 20
    inner = np.zeros((S, S), np.float32)
    inner[pad:S - pad, pad:S - pad] = 1
    # ركن سفلي أيمن مثني
    curl = np.clip((x + y - (2 * S - pad * 2 - 56)) / 6.0, 0, 1)
    m = np.clip(inner - curl * inner, 0, 1)
    base = np.array([250, 246, 232], np.float32)
    grad = 1.0 - 0.07 * (y / S)
    col = base[None, None, :] * grad[..., None]
    col *= (0.975 + 0.05 * fbm(S, S, seed, 4, 6))[..., None]
    # شريط لاصق بالأعلى أغمق وألمع
    top = np.exp(-(((y - pad - 12) / 11.0) ** 2)) * inner
    col *= (1 - 0.06 * top)[..., None]
    # ثنية الركن
    fold = np.clip((x + y - (2 * S - pad * 2 - 56)) / 6.0, 0, 1) * inner
    foldcol = np.array([232, 226, 206], np.float32)[None, None, :] * (0.88 + 0.12 * np.clip((x + y - (2 * S - pad * 2 - 56)) / 56.0, 0, 1))[..., None]
    col = col * (1 - fold[..., None]) + foldcol * fold[..., None]
    col += grain(S, S, seed, 1.5)
    sh = blur(np.roll(np.roll(m, 9, axis=0), 6, axis=1), 7) * 0.5
    a = np.clip(m + sh * (1 - m), 0, 1)
    return to_img(col * np.clip(m + fold * 0, 0, 1)[..., None], a * 255)


def build():
    for name, c in (("pin_red", (210, 34, 36)), ("pin_blue", (44, 96, 206)), ("pin_yellow", (236, 190, 44)), ("pin_green", (46, 150, 84))):
        save(pin(c), name, quality=92)
    save(coin(176, True), "coin", quality=92)
    save(coin(176, False), "coin_empty", quality=92)
    save(wax_seal(224, True), "seal_ready", quality=92)
    save(wax_seal(224, False), "seal_idle", quality=92)
    save(sticky(300), "sticky", quality=90)


if __name__ == "__main__":
    build()
