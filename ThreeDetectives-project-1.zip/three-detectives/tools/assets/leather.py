# -*- coding: utf-8 -*-
"""دفتر ملاحظات جلدي مفتوح: غلاف جلدي محبّب مخيّط وصفحتان مسطّرتان وشريط إشارة."""
import numpy as np
import cv2
from common import *
from paper import paper

LEATHER = [(0.0, (34, 19, 12)), (0.45, (64, 38, 24)), (0.8, (92, 58, 38)), (1.0, (122, 80, 52))]


def leather_tex(h, w, seed):
    r = np.random.default_rng(seed)
    n = r.random((h, w)).astype(np.float32)
    peb = blur(n, 1.5) - blur(n, 3.4)
    peb = (peb - peb.min()) / (peb.max() - peb.min() + 1e-9)
    low = fbm(h, w, seed + 1, 4, 4, 0.55)
    # تجاعيد طويلة رفيعة
    cr = np.zeros((h, w), np.float32)
    for _ in range(26):
        x0, y0 = r.uniform(0, w), r.uniform(0, h)
        pts = [(x0, y0)]
        ang = r.uniform(0, np.pi)
        for _k in range(12):
            ang += r.normal(0, 0.28)
            x0 += np.cos(ang) * 14
            y0 += np.sin(ang) * 14
            pts.append((x0, y0))
        cv2.polylines(cr, [np.array(pts, np.int32)], False, float(r.uniform(0.4, 1)), 1, cv2.LINE_AA)
    cr = blur(cr, 0.9)
    height = peb * 1.0 + low * 0.5 - cr * 1.4
    t = np.clip(0.30 + 0.34 * low + 0.30 * peb - 0.35 * cr, 0, 1)
    col = cmap(t, LEATHER)
    diff, spec = light(height * 3.0, strength=1.5, spec=0.5, shin=14, amb=0.55)
    out = col * diff[..., None] + (spec * 255 * 0.32)[..., None] * np.array([1, 0.9, 0.75])
    return out


def rr_points(x0, y0, x1, y1, r, step):
    pts = []
    def seg(ax, ay, bx, by):
        n = max(1, int(np.hypot(bx - ax, by - ay) / step))
        for i in range(n):
            pts.append((ax + (bx - ax) * i / n, ay + (by - ay) * i / n))
    def arc(cx, cy, a0):
        n = max(2, int(r * 1.57 / step))
        for i in range(n):
            a = a0 + (np.pi / 2) * i / n
            pts.append((cx + r * np.cos(a), cy + r * np.sin(a)))
    seg(x0 + r, y0, x1 - r, y0); arc(x1 - r, y0 + r, -np.pi / 2)
    seg(x1, y0 + r, x1, y1 - r); arc(x1 - r, y1 - r, 0)
    seg(x1 - r, y1, x0 + r, y1); arc(x0 + r, y1 - r, np.pi / 2)
    seg(x0, y1 - r, x0, y0 + r); arc(x0 + r, y0 + r, np.pi)
    return pts


def stitches(img, x0, y0, x1, y1, r, seed):
    pts = rr_points(x0, y0, x1, y1, r, 2.0)
    dash, gap = 7, 4
    shadow = np.zeros(img.shape[:2], np.float32)
    thread = np.zeros(img.shape[:2], np.float32)
    i = 0
    while i + dash < len(pts):
        a, b = pts[i], pts[i + dash]
        cv2.line(shadow, (int(a[0] + 1.5), int(a[1] + 1.8)), (int(b[0] + 1.5), int(b[1] + 1.8)), 1.0, 3, cv2.LINE_AA)
        cv2.line(thread, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])), 1.0, 2, cv2.LINE_AA)
        i += dash + gap
    shadow = blur(shadow, 1.0)
    img *= (1 - 0.55 * shadow)[..., None]
    tc = np.array([206, 178, 126], np.float32)
    img[:] = img * (1 - thread[..., None]) + tc * thread[..., None] * (0.82 + 0.18 * np.random.default_rng(seed).random(thread.shape)[..., None])


def notebook(w=1100, h=800, pad=44, seed=31):
    B = 40  # سُمك حدود الغلاف
    cov = leather_tex(h, w, seed)
    # حواف مشغولة: تفتيح خفيف عند الأطراف (بلى)
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    edge = np.minimum(np.minimum(x, w - 1 - x), np.minimum(y, h - 1 - y))
    wear = np.exp(-edge / 5.0) * 0.28
    cov *= (1 + wear[..., None] * np.array([0.9, 0.7, 0.5]))
    stitches(cov, 15, 15, w - 16, h - 16, 16, seed)
    # كتلة الصفحات
    pw = (w - 2 * B - 8) // 2
    ph = h - 2 * B
    left = paper(pw, ph, seed + 2, (241, 232, 208), 0.7, rules=(40, (150, 168, 190)), fold=False, rough=False)
    right = paper(pw, ph, seed + 3, (243, 234, 211), 0.7, rules=(40, (150, 168, 190)), fold=False, rough=False)
    L = np.asarray(left).astype(np.float32)[..., :3].copy()
    R = np.asarray(right).astype(np.float32)[..., :3].copy()
    gx = np.arange(pw, dtype=np.float32)
    gl = np.exp(-((pw - 1 - gx) / 46.0) ** 1.4)  # عتمة قرب المنتصف
    L *= (1 - 0.46 * gl)[None, :, None]
    R *= (1 - 0.46 * gl[::-1])[None, :, None]
    L *= (1 - 0.10 * np.exp(-(gx / 18.0)))[None, :, None]
    R *= (1 - 0.10 * np.exp(-((pw - 1 - gx) / 18.0)))[None, :, None]
    img = cov.copy()
    # ظل الصفحات على الغلاف
    block = np.zeros((h, w), np.float32)
    block[B - 6:h - B + 6, B - 6:w - B + 6] = 1
    img *= (1 - 0.5 * blur(block, 5))[..., None]
    img[B:B + ph, B:B + pw] = L
    img[B:B + ph, B + pw + 8:B + 2 * pw + 8] = R
    # سُمك الصفحات (خطوط متراصة) عند الأسفل والجانبين
    for k in range(1, 6):
        sh = 238 - k * 9
        img[B + ph + k - 1: B + ph + k, B:B + 2 * pw + 8] = np.array([sh, sh - 8, sh - 26], np.float32)
        img[B:B + ph, B - k:B - k + 1] = np.array([sh, sh - 8, sh - 26], np.float32)
        img[B:B + ph, B + 2 * pw + 8 + k - 1:B + 2 * pw + 8 + k] = np.array([sh, sh - 8, sh - 26], np.float32)
    # شريط إشارة أحمر داكن يخرج من المنتصف
    rb = np.zeros((h, w), np.float32)
    bx = w // 2 + 6
    pts = np.array([[bx - 9, h - B - 40], [bx + 9, h - B - 40], [bx + 11, h - 4], [bx, h - 14], [bx - 11, h - 4]], np.int32)
    cv2.fillPoly(rb, [pts], 1.0, cv2.LINE_AA)
    shade = 0.75 + 0.25 * np.cos((x - bx) / 9.0)
    ribbon = np.array([120, 24, 30], np.float32)[None, None, :] * shade[..., None]
    img = img * (1 - rb[..., None]) + ribbon * rb[..., None]
    # حواف الغلاف: تدوير الزوايا وألفا + ظل ساقط
    m = rounded_mask(h, w, 26)
    H, W = h + pad * 2, w + pad * 2
    canvas = np.zeros((H, W, 3), np.float32)
    alpha = np.zeros((H, W), np.float32)
    canvas[pad:pad + h, pad:pad + w] = img
    alpha[pad:pad + h, pad:pad + w] = m
    sh = drop_shadow(alpha, 8, 14, 14, 0.62)
    # إضاءة عامة
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    canvas *= (0.88 + 0.22 * np.exp(-(((xx - W * 0.3) / (W * 0.9)) ** 2 + ((yy - H * 0.2) / (H * 0.9)) ** 2)))[..., None]
    out_a = np.clip(alpha + sh * (1 - alpha), 0, 1)
    out_rgb = canvas * alpha[..., None]
    return to_img(out_rgb, out_a * 255), (pad, pad, w, h, B, pw, ph)


if __name__ == "__main__":
    im, meta = notebook()
    print("  notebook meta (pad, pad, w, h, border, pageW, pageH):", meta)
    save(im, "notebook", quality=88)
