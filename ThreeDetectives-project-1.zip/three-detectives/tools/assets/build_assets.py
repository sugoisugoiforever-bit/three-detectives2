# -*- coding: utf-8 -*-
"""يولّد كل الرسومات والأصوات ويضعها في موارد تطبيق أندرويد: python3 tools/assets/build_assets.py"""
import glob
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
RES = os.path.abspath(os.path.join(HERE, "..", "..", "app", "src", "main", "res"))

import common  # noqa: E402
import wood, paper, leather, cork, objects, objects2, portraits, launcher, sfx  # noqa: E402,F401

ADAPTIVE = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_bg"/>
    <foreground android:drawable="@drawable/ic_launcher_fg"/>
</adaptive-icon>
"""


def main():
    print("خشب المكتب"); common.save(wood.desk(), "desk_wood", quality=86)
    print("الأوراق"); paper.build()
    print("الدفتر الجلدي"); im, _ = leather.notebook(); common.save(im, "notebook", quality=88)
    print("لوحة الفلين"); im, _ = cork.corkboard(); common.save(im, "corkboard", quality=88)
    print("الأدوات الصغيرة"); objects.build()
    print("اللوحة والبطاقات والأيقونات"); objects2.build()
    print("الشخصيات"); portraits.build()
    print("الأصوات"); sfx.build()
    # نسخ إلى الموارد
    d_draw = os.path.join(RES, "drawable-nodpi")
    d_raw = os.path.join(RES, "raw")
    os.makedirs(d_draw, exist_ok=True)
    os.makedirs(d_raw, exist_ok=True)
    for f in glob.glob(os.path.join(common.OUT, "*.webp")):
        shutil.copy(f, d_draw)
    for f in glob.glob(os.path.join(common.OUT, "*.wav")):
        shutil.copy(f, d_raw)
    print("الأيقونة"); launcher.build(RES)
    ad = os.path.join(RES, "mipmap-anydpi-v26")
    os.makedirs(ad, exist_ok=True)
    for n in ("ic_launcher.xml", "ic_launcher_round.xml"):
        with open(os.path.join(ad, n), "w", encoding="utf-8") as fh:
            fh.write(ADAPTIVE)
    total = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(RES) for f in fs)
    print("حجم الموارد الكلي: %.1f MB" % (total / 1048576))


if __name__ == "__main__":
    main()
