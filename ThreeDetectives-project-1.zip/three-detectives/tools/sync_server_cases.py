#!/usr/bin/env python3
"""يولّد server/src/cases.data.ts من المكتبة المرجعية app/src/main/assets/cases.jsonl (الترتيب نفسه تماماً).

يُستعمل ملف TypeScript بدل JSON حتى لا يعتمد النشر على دعم أداة التجميع لاستيراد JSON.
"""
import json, pathlib, sys

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "app/src/main/assets/cases.jsonl"
dst = root / "server/src/cases.data.ts"
cases = [json.loads(l) for l in src.read_text(encoding="utf-8").splitlines() if l.strip()]
body = ",\n".join(json.dumps(c, ensure_ascii=False, separators=(",", ":")) for c in cases)
dst.write_text(
    "// ملف مولَّد — لا تعدّله يدوياً. أعد توليده بـ: python3 tools/sync_server_cases.py\n"
    "// المصدر: app/src/main/assets/cases.jsonl\n"
    "const data: any[] = [\n" + body + "\n];\nexport default data;\n",
    encoding="utf-8",
)
print(f"{len(cases)} قضية -> {dst.relative_to(root)} ({dst.stat().st_size} بايت)")
