# ثلاثة محققين، ملف واحد

لعبة أندرويد تعاونية: ثلاثة محققين، لكلٍّ ملفات سرية، ومهمتهم معاً حلّ القضية (من؟ كيف؟ لماذا؟) دون أي دردشة.
تلعب منفرداً مع محققَين آليَّين، أو مع صديقين عبر الإنترنت. التفاصيل في [`docs/GDD_v2.md`](docs/GDD_v2.md).

## الحصول على ملف APK

> لم يكن ممكناً بناء الـ APK داخل بيئة التطوير التي كُتب فيها المشروع (لا Android SDK ولا وصول لمستودعات Google/Maven).
> المشروع كامل وجاهز للبناء، وكل ما يمكن اختباره خارج أندرويد اختُبر (انظر «الاختبارات»). **أول بناء حقيقي هو أول مرة يُترجَم فيها كود الواجهة بمترجم Compose الفعلي**؛
> إن ظهر خطأ ترجمة فأرسل نصّه وسيُصلَح فوراً.

### الطريقة 1 — GitHub Actions (لا تحتاج تثبيت شيء)
1. ارفع هذا المجلد كاملاً إلى مستودع GitHub جديد.
2. تبويب **Actions ← Build APK ← Run workflow** (يعمل تلقائياً أيضاً عند أول رفع).
3. بعد دقائق نزّل الملف **ThreeDetectives-apk** من أسفل صفحة التشغيل، وافتح `ThreeDetectives.apk` على هاتفك (اسمح بالتثبيت من مصدر غير معروف).

### الطريقة 2 — Android Studio
افتح المجلد في Android Studio (Ladybug أو أحدث) واتركه يزامن Gradle، ثم **Build ← Build Bundle(s)/APK(s) ← Build APK(s)**.

### الطريقة 3 — سطر الأوامر
مع JDK 17 وAndroid SDK: `./build-apk.sh` ← الناتج `dist/ThreeDetectives.apk`.

التوقيع بمفتاح مرفق في `keystore/` ليُثبَّت الملف مباشرة. **للنشر في متجر** استبدله بمفتاحك الخاص في `app/build.gradle.kts`.

## اللعب الجماعي (اختياري)

اللعب الفردي يعمل بلا إنترنت. للعب مع الأصدقاء تحتاج خادماً (مجاني على Cloudflare):

```bash
cd server
npm install
npx wrangler login
npx wrangler deploy        # يطبع عنواناً مثل https://three-detectives.<حسابك>.workers.dev
```

أو من GitHub: أضف السرّين `CLOUDFLARE_API_TOKEN` و`CLOUDFLARE_ACCOUNT_ID` ثم شغّل **Actions ← Deploy server**.
في التطبيق: **الإعدادات ← عنوان الخادم** والصق العنوان، ثم «العب مع الأصدقاء ← أنشئ غرفة» وشارك الرمز.
البروتوكول في [`docs/PROTOCOL.md`](docs/PROTOCOL.md).

## الاختبارات

| ماذا | الأمر | يغطي |
|---|---|---|
| محرك القواعد والبوتات (Kotlin) | `./gradlew :engine:selfTest` | ~8800 فحص: القواعد، النجوم، البوتات، مكتبة القضايا (180) |
| الخادم (TypeScript) | `cd server && npm install && npm test` | تطابق حرفي مع Kotlin، الغرف، الانقطاع والعودة، الاستعادة بعد إعادة التشغيل، لعبة كاملة عبر WebSocket حقيقي |
| فحص أنواع الخادم | `cd server && npm run typecheck` | |

لإعادة توليد مرجع التطابق بعد تعديل قاعدة في المحرك: شغّل `game.SelfTestKt --parity` و`--chaos` وانسخ الناتج إلى `server/test/golden/`.

## هيكل المشروع

```
engine/   محرك القواعد والبوتات (Kotlin نقي) + اختباراته
app/      تطبيق أندرويد (Compose) — الواجهة في ui/ والجلسات في session/ والصوت في audio/
server/   Cloudflare Worker + Durable Objects (TypeScript) + اختباراته
tools/    مولّد القضايا ومدقّقها، ومولّد الأصول الفنية (صور وأصوات)
docs/     وثيقة التصميم v2 والبروتوكول
```

بعد تعديل المكتبة المرجعية `app/src/main/assets/cases.jsonl` شغّل `python3 tools/sync_server_cases.py` لتحديث نسخة الخادم.
