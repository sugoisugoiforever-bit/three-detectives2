// الإصدارات مثبّتة عمداً على تركيبة معروفة بثباتها معاً:
// AGP 8.7.3 + Kotlin 2.0.21 + Compose BOM 2024.10.01 + Gradle 8.10.2
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.jvm") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
