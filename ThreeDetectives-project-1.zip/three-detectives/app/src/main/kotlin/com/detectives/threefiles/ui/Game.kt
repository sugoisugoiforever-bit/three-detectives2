package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.coerceIn
import com.detectives.threefiles.audio.Sfx
import game.Action
import game.PReq
import game.PView
import game.ROLE_AR
import kotlinx.coroutines.delay

/** حالة الواجهة التي تبقى عند التنقل بين شاشة الجولات وشاشة الاتهام. */
class UiState {
    var seen by mutableStateOf(emptySet<String>())
    var marks by mutableStateOf(emptyMap<String, Int>())
    var readFeed by mutableStateOf(0)

    fun mark(person: String, m: Int) {
        marks = if (m == MARK_NONE) marks - person else marks + (person to m)
    }

    fun see(id: String) {
        if (id !in seen) seen = seen + id
    }
}

/** النافذة المفتوحة فوق المكتب (واحدة في كل مرة). */
sealed class Ov {
    class Doc(val id: String?, val onlyOwn: Boolean = false) : Ov()
    class Reply(val req: PReq) : Ov()
    class Suspect(val id: String) : Ov()
    object Audit : Ov()
    class Answer(val q: String) : Ov()
    class CitePick(val q: String, val slot: Int) : Ov()
    object Notebook : Ov()
    object Ask : Ov()
    object Say : Ov()
    object Ability : Ov()
    object Help : Ov()
}

fun roundLabel(v: PView): String =
    if (v.phase == "accuse") (if (v.window == 1) "نافذة الاتهام" else "الاتهام الأخير")
    else "الجولة " + v.round + " من 5"

/** شاشة الجولة: مكتب الوثائق، لوحة المشتبهين، الدفتر، وبطاقات الإجراءات. */
@Composable
fun GameScreen(
    v: PView,
    left: Long,
    ui: UiState,
    send: (Action) -> Unit,
    toast: (String) -> Unit,
    onMenu: () -> Unit,
    startOv: Ov? = null,
    startSplash: Boolean = true,
) {
    val s = LocalS.current
    var ov by remember { mutableStateOf<Ov?>(startOv) }
    var splash by remember { mutableStateOf(startSplash) }
    LaunchedEffect(v.round) {
        splash = true
        delay(1700)
        splash = false
    }
    val unseen = v.docs.filter { it.id !in ui.seen }.map { it.id }.toSet()
    val hot = v.requests.filter { !it.mine }.flatMap { it.matches }.toSet()
    val unread = v.feed.count { it.id > ui.readFeed }
    val block = moveBlock(v)
    Box(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val leftW = (maxWidth * 0.2f).coerceIn(s(120), s(170))
            val rightW = (maxWidth * 0.3f).coerceIn(s(190), s(250))
            Column(Modifier.fillMaxSize().padding(horizontal = s(10), vertical = s(4))) {
                TopBar(v, roundLabel(v), left, onMenu, { ov = Ov.Help })
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(6))) {
                    Column(Modifier.width(leftW).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(s(5))) {
                        TeamPanel(v)
                        NotebookPeek(v, unread, { ov = Ov.Notebook }, Modifier.weight(1f).fillMaxWidth())
                    }
                    DeskGrid(v, unseen, hot, { id -> ov = Ov.Doc(id) }, Modifier.weight(1f).fillMaxHeight())
                    CorkBoard(
                        v, ui.marks,
                        onPerson = { id -> ov = Ov.Suspect(id) },
                        onRequest = { r ->
                            if (r.matches.isEmpty()) toast("ليس عندك ما يناسب طلب " + ROLE_AR[r.from]) else ov = Ov.Reply(r)
                        },
                        modifier = Modifier.width(rightW).fillMaxHeight(),
                    )
                }
                BottomBar(
                    v, leftW, block != null,
                    onAsk = { ov = Ov.Ask },
                    onSend = { ov = Ov.Doc(null, true) },
                    onSay = { ov = Ov.Say },
                    onAbility = { ov = Ov.Ability },
                    onReady = {
                        Sfx.seal()
                        send(Action.Ready(!v.players[v.seat].ready))
                    },
                )
            }
        }
        GameOverlays(v, ov, ui, send, toast, { ov = null }, { ov = it })
        if (splash) RoundSplash(v.round)
    }
}

@Composable
fun RoundSplash(round: Int) {
    val s = LocalS.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(Modifier.background(Color(0xB0000000), androidx.compose.foundation.shape.RoundedCornerShape(s(10))).padding(horizontal = s(34), vertical = s(14))) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                ArText("الجولة $round من 5", 24, Brass, FontWeight.Bold, TextAlign.Center, font = Serif, shadow = true)
                ArText(
                    when (round) {
                        1 -> "اقرؤوا وثائقكم ثم تبادلوا ما يفيد"
                        5 -> "الجولة الأخيرة قبل الاتهام النهائي"
                        else -> "وثائق جديدة وصلت إلى مكاتبكم"
                    },
                    11, Cream, FontWeight.Normal, TextAlign.Center,
                )
            }
        }
    }
}

/** يفتح النافذة المطلوبة ويربط أزرارها بحركات اللعبة. */
@Composable
fun GameOverlays(
    v: PView,
    ov: Ov?,
    ui: UiState,
    send: (Action) -> Unit,
    toast: (String) -> Unit,
    close: () -> Unit,
    open: (Ov) -> Unit,
) {
    val unseen = v.docs.filter { it.id !in ui.seen }.map { it.id }.toSet()
    val shareReason = moveBlock(v) ?: if (v.credits < 1) "نفدت القطع النحاسية" else null
    val doShare = { id: String, to: Int ->
        if (shareReason != null) {
            toast(shareReason)
        } else {
            send(Action.Share(id, to))
            close()
        }
    }
    val doAsk = { topic: String ->
        send(Action.Request(topic))
        close()
    }
    when (ov) {
        null -> {}
        is Ov.Doc -> {
            val all = v.docs.reversed()
            val list = if (ov.onlyOwn) all.filter { it.from < 0 } else all
            DocBrowser(v, list, ov.id ?: list.firstOrNull()?.id, unseen, null, doShare, doAsk, { ui.see(it) }, close)
        }
        is Ov.Reply -> {
            val docs = ov.req.matches.mapNotNull { id -> v.docs.firstOrNull { it.id == id } }
            val pick = Pick(
                "أرسل إلى " + ROLE_AR[ov.req.from],
                "هذه الوثيقة تناسب طلبه. الإرسال يكلّف قطعة نحاسية ويستهلك حركتك.",
            ) { d -> doShare(d.id, ov.req.from) }
            DocBrowser(v, docs, docs.firstOrNull()?.id, unseen, pick, doShare, doAsk, { ui.see(it) }, close)
        }
        is Ov.Audit -> {
            val docs = v.docs.reversed().filter { it.audit == null }
            val pick = Pick("دقّق هذه الوثيقة", "ستعرف وحدك إن كانت حاسمة أم تشويشاً. القدرة تُستعمل مرة واحدة.") { d ->
                send(Action.Ability(d.id))
                close()
            }
            DocBrowser(v, docs, docs.firstOrNull()?.id, unseen, pick, doShare, doAsk, { ui.see(it) }, close)
        }
        is Ov.Answer -> AnswerSheet(v, ov.q, { opt -> send(Action.Answer(ov.q, opt)); close() }, close)
        is Ov.CitePick -> {
            val other = v.draft.cites[ov.q]?.getOrNull(1 - ov.slot)
            val otherOwner = v.docs.firstOrNull { it.id == other }?.owner ?: v.cited.firstOrNull { it.id == other }?.owner
            val docs = v.docs.reversed().filter { otherOwner == null || it.owner != otherOwner }
            val pick = Pick("استشهد بهذه الوثيقة", "اختر الدليل الذي يثبت إجابتكم. يجب أن يكون الدليلان من لاعبَين مختلفين.") { d ->
                send(Action.Cite(ov.q, ov.slot, d.id))
                close()
            }
            DocBrowser(v, docs, docs.firstOrNull()?.id, unseen, pick, doShare, doAsk, { ui.see(it) }, close)
        }
        is Ov.Suspect -> SuspectSheet(v, ov.id, ui, doAsk, { id -> open(Ov.Doc(id)) }, close)
        is Ov.Notebook -> NotebookSheet(v, ui, close)
        is Ov.Ask -> AskSheet(v, doAsk, close)
        is Ov.Say -> SaySheet(v, { a -> send(a); close() }, close)
        is Ov.Ability -> AbilitySheet(v, { send(Action.Ability(null)); close() }, { open(Ov.Audit) }, close)
        is Ov.Help -> HelpSheet(close)
    }
}
