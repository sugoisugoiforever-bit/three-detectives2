package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.coerceIn
import com.detectives.threefiles.R
import game.Action
import game.Opt
import game.PView
import game.QUESTION_AR
import game.ROLE_AR

private val SoftBrass = Color(0xCCEBD9A8)

private fun docTitle(v: PView, id: String): String =
    v.docs.firstOrNull { it.id == id }?.title ?: v.cited.firstOrNull { it.id == id }?.title ?: "وثيقة"

private fun docOwner(v: PView, id: String): Int =
    v.docs.firstOrNull { it.id == id }?.owner ?: v.cited.firstOrNull { it.id == id }?.owner ?: -1

/** سبب عدم اكتمال الاتهام (يطابق فحص المحرك)، أو null إن كان مكتملاً. */
fun draftHint(v: PView): String? {
    for (q in v.info.questions) {
        val name = QUESTION_AR[q.id] ?: q.id
        val ct = v.draft.cites[q.id] ?: listOf(null, null)
        val a = ct.getOrNull(0)
        val b = ct.getOrNull(1)
        if (v.draft.answers[q.id] == null) return "اختاروا إجابة لسؤال «$name»"
        if (a == null || b == null) return "أرفقوا وثيقتين لسؤال «$name»"
        if (a == b) return "الوثيقتان في «$name» متطابقتان"
        if (docOwner(v, a) == docOwner(v, b)) return "وثائق «$name» يجب أن تكون من لاعبَين مختلفين"
    }
    return null
}

/** خانة دليل: وثيقة مستشهَد بها أو مكان فارغ للصق وثيقة. */
@Composable
fun EvidenceSlot(title: String?, owner: Int, onClick: () -> Unit, onClear: () -> Unit) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(5))
    Row(Modifier.fillMaxWidth().height(s(40)), horizontalArrangement = Arrangement.spacedBy(s(4)), verticalAlignment = Alignment.CenterVertically) {
        if (title != null) {
            Press(onClear, Modifier.size(s(18))) {
                Box(Modifier.matchParentSize().background(Color(0x66000000), CircleShape))
                ArText("×", 12, Brass, FontWeight.Bold, TextAlign.Center, Modifier.align(Alignment.Center))
            }
        }
        Press(onClick, Modifier.weight(1f).fillMaxHeight()) {
            Box(
                Modifier.matchParentSize().clip(shape)
                    .background(if (title != null) Color(0xFFEFE3C2) else Color(0x22EBD9A8))
                    .border(s(1), if (title != null) Color(0xFF8A6B3A) else Color(0x66EBD9A8), shape),
            )
            Column(
                Modifier.matchParentSize().padding(horizontal = s(7), vertical = s(3)),
                verticalArrangement = Arrangement.Center,
            ) {
                if (title != null) {
                    ArText(title, 9.4f, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2, font = Serif)
                    ArText("من: " + (ROLE_AR.getOrNull(owner) ?: "؟"), 7.6f, InkSoft, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
                } else {
                    ArText("اضغط لإرفاق وثيقة", 9, SoftBrass, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

/** بطاقة سؤال: الإجابة المختارة ووثيقتا الإثبات. */
@Composable
fun QuestionCard(v: PView, qi: Int, onAnswer: () -> Unit, onSlot: (Int) -> Unit, onClear: (Int) -> Unit, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val q = v.info.questions[qi]
    val sel = v.draft.answers[q.id]
    val opt = if (sel == null) null else q.options.getOrNull(sel)
    val person = if (opt?.person == null) null else v.info.persons.firstOrNull { it.id == opt.person }
    val ct = v.draft.cites[q.id] ?: listOf(null, null)
    val a = ct.getOrNull(0)
    val b = ct.getOrNull(1)
    val problem: String? = when {
        opt == null -> "لم تُحدَّد إجابة"
        a == null || b == null -> "يلزم دليلان"
        a == b -> "الوثيقتان متطابقتان"
        docOwner(v, a) == docOwner(v, b) -> "الدليلان من لاعب واحد"
        else -> null
    }
    val slipShape = RoundedCornerShape(s(5))
    LeatherPanel(modifier) {
        Column(Modifier.fillMaxSize().padding(s(8)), verticalArrangement = Arrangement.spacedBy(s(5))) {
            ArText(q.prompt, 12.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
            Press(onAnswer, Modifier.fillMaxWidth().height(s(60))) {
                Pic(R.drawable.paper_cream, Modifier.matchParentSize().clip(slipShape), ContentScale.Crop)
                Box(Modifier.matchParentSize().border(s(1), Color(0xFF8A6B3A), slipShape))
                Row(
                    Modifier.matchParentSize().padding(horizontal = s(7)),
                    horizontalArrangement = Arrangement.spacedBy(s(6), Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        if (opt != null) {
                            val sub = opt.sub
                            ArText(opt.label, 10.6f, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 3, font = Serif)
                            if (sub != null) ArText(sub, 8, InkSoft, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
                        } else {
                            ArText("اضغط لاختيار الإجابة", 10.4f, InkSoft, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
                        }
                    }
                    if (person != null) {
                        Pic(Pics.portrait(person.portrait), Modifier.size(s(40)).clip(RoundedCornerShape(s(4))), ContentScale.Crop)
                    }
                }
            }
            ArText("الدليلان (من لاعبَين مختلفين)", 8.8f, SoftBrass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
            EvidenceSlot(a?.let { docTitle(v, it) }, if (a == null) -1 else docOwner(v, a), { onSlot(0) }, { onClear(0) })
            EvidenceSlot(b?.let { docTitle(v, it) }, if (b == null) -1 else docOwner(v, b), { onSlot(1) }, { onClear(1) })
            Box(Modifier.weight(1f))
            ArText(
                if (problem == null) "✓ مكتمل" else problem,
                9, if (problem == null) Color(0xFF9BD08F) else Color(0xFFE8A598), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(),
            )
        }
    }
}

/** قائمة الخيارات السبعة لسؤال. */
@Composable
fun AnswerSheet(v: PView, qid: String, onPick: (Int?) -> Unit, onClose: () -> Unit) {
    val s = LocalS.current
    val q = v.info.questions.firstOrNull { it.id == qid } ?: return
    val sel = v.draft.answers[qid]
    Sheet(q.prompt, onClose, 430) {
        for ((i, o) in q.options.withIndex()) {
            AnswerRow(o, i == sel, v) { onPick(i) }
        }
        if (sel != null) {
            BrassButton("مسح الإجابة", { onPick(null) }, Modifier.fillMaxWidth(), size = 10.5f, height = 28)
        }
        Box(Modifier.height(s(2)))
    }
}

@Composable
private fun AnswerRow(o: Opt, on: Boolean, v: PView, onClick: () -> Unit) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(7))
    val person = if (o.person == null) null else v.info.persons.firstOrNull { it.id == o.person }
    val sub = o.sub
    Press(onClick, Modifier.fillMaxWidth().height(s(34))) {
        Box(
            Modifier.matchParentSize().clip(shape)
                .background(if (on) Color(0xFFE9CF86) else Color(0x22EBD9A8))
                .border(s(1), if (on) Color(0xFF6E5214) else Color(0x55EBD9A8), shape),
        )
        Row(
            Modifier.matchParentSize().padding(horizontal = s(8)),
            horizontalArrangement = Arrangement.spacedBy(s(8), Alignment.End),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                ArText(o.label, 10.4f, if (on) Ink else Cream, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2)
                if (sub != null) ArText(sub, 8, if (on) InkSoft else SoftBrass, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
            }
            if (person != null) Pic(Pics.portrait(person.portrait), Modifier.size(s(26)).clip(RoundedCornerShape(s(4))), ContentScale.Crop)
        }
    }
}

/** شاشة الاتهام: ثلاث بطاقات أسئلة، وموافقات الفريق، وزر الموافقة. */
@Composable
fun AccuseScreen(
    v: PView,
    left: Long,
    ui: UiState,
    send: (Action) -> Unit,
    toast: (String) -> Unit,
    onMenu: () -> Unit,
    startOv: Ov? = null,
) {
    val s = LocalS.current
    var ov by remember { mutableStateOf<Ov?>(startOv) }
    val me = v.seat
    val approved = v.draft.approvals.getOrNull(me) == true
    val count = v.draft.approvals.count { it }
    val hint = draftHint(v)
    Box(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val leftW = (maxWidth * 0.2f).coerceIn(s(120), s(170))
            Column(Modifier.fillMaxSize().padding(horizontal = s(10), vertical = s(4))) {
                TopBar(v, roundLabel(v), left, onMenu, { ov = Ov.Help })
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(8))) {
                    Column(Modifier.width(leftW).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(s(5))) {
                        TeamPanel(v, approvals = v.draft.approvals)
                        BrassButton("وثائقي", { ov = Ov.Doc(null) }, Modifier.fillMaxWidth(), size = 10.5f, height = 28, icon = R.drawable.icon_send)
                        BrassButton("الدفتر", { ov = Ov.Notebook }, Modifier.fillMaxWidth(), size = 10.5f, height = 28, icon = R.drawable.icon_notes)
                    }
                    // «من» عند اليمين ثم «كيف» ثم «لماذا»
                    for (qi in listOf(2, 1, 0)) {
                        val q = v.info.questions[qi]
                        QuestionCard(
                            v, qi,
                            onAnswer = { ov = Ov.Answer(q.id) },
                            onSlot = { slot ->
                                val other = v.draft.cites[q.id]?.getOrNull(1 - slot)
                                val otherOwner = v.docs.firstOrNull { it.id == other }?.owner ?: v.cited.firstOrNull { it.id == other }?.owner
                                if (v.docs.none { otherOwner == null || it.owner != otherOwner }) {
                                    toast("ليس عندك وثيقة من لاعب مختلف عن دليلك الآخر. اطلب من زميلك أن يستشهد بها.")
                                } else {
                                    ov = Ov.CitePick(q.id, slot)
                                }
                            },
                            onClear = { slot -> send(Action.Cite(q.id, slot, null)) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().height(s(58)), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(s(10))) {
                    WaxButton(
                        text = if (approved) "سحب موافقتي" else "أوافق على الاتهام",
                        onClick = {
                            if (!approved && hint != null) toast(hint) else send(Action.Approve(!approved))
                        },
                        modifier = Modifier.width(s(150)),
                        enabled = approved || hint == null,
                        size = 12.5f,
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(2))) {
                        ArText(
                            hint ?: ("الاتهام مكتمل • الموافقات $count من ${v.draft.required}"),
                            11, if (hint == null) Color(0xFF9BD08F) else Color(0xFFE8A598), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2,
                        )
                        ArText(
                            if (v.window == 1) "يلزم إجماع الثلاثة. إن انتهى الوقت دون اتهام تبدأ جولة أخيرة."
                            else "النافذة الأخيرة: تكفي موافقة اثنين. إن انتهى الوقت دون اتهام تنتهي القضية بالفشل.",
                            9, SoftBrass, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2,
                        )
                    }
                }
            }
        }
        GameOverlays(v, ov, ui, send, toast, { ov = null }, { ov = it })
    }
}
