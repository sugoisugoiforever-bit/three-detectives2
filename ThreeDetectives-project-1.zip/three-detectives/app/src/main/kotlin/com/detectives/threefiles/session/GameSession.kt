package com.detectives.threefiles.session

import game.Action
import game.PView
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/** لقطة من حالة اللعبة مع وقت استلامها (لحساب المؤقت التنازلي محلياً). frozen = مؤقت متوقف. */
class Snap(val v: PView, val at: Long, val frozen: Boolean = false)

class LobbySeat(val seat: Int, val name: String, val bot: Boolean, val connected: Boolean)

class Lobby(
    val code: String,
    val mySeat: Int,
    val host: Boolean,
    val theme: String,
    val difficulty: Int,
    val started: Boolean,
    val seats: List<LobbySeat>,
)

/** واجهة موحّدة بين الواجهة والمحرك: محلية (فردي) أو عبر الشبكة. */
interface GameSession {
    val snap: StateFlow<Snap?>
    val lobby: StateFlow<Lobby?>
    /** رسائل عابرة للمستخدم (أخطاء الحركات وغيرها). */
    val messages: SharedFlow<String>
    /** ok | connecting | lost | closed */
    val connection: StateFlow<String>
    val online: Boolean
    /** سبب الإغلاق النهائي (رفض الخادم أو إغلاق الغرفة) حين تكون connection == "closed". */
    val failure: String? get() = null
    fun send(a: Action)
    fun pause(on: Boolean)
    fun close()

    // أوامر الردهة (أونلاين فقط؛ في الفردي لا تفعل شيئاً)
    fun config(theme: String, difficulty: Int) {}
    fun chooseSeat(seat: Int) {}
    fun start() {}
    fun again() {}
}
