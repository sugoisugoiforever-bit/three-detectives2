package com.detectives.threefiles.data

import android.content.Context
import java.util.UUID

/** إعدادات اللاعب وسجلّه (SharedPreferences بلا اعتماديات إضافية). */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("detectives", Context.MODE_PRIVATE)

    var name: String
        get() = sp.getString("name", "") ?: ""
        set(v) { sp.edit().putString("name", v.trim().take(18)).apply() }

    var serverUrl: String
        get() = sp.getString("server", "") ?: ""
        set(v) { sp.edit().putString("server", v.trim()).apply() }

    var sound: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) { sp.edit().putBoolean("sound", v).apply() }

    /** 0 سهل، 1 عادي، 2 صعب */
    var difficulty: Int
        get() = sp.getInt("difficulty", 1)
        set(v) { sp.edit().putInt("difficulty", v).apply() }

    /** "" عشوائي، وإلا رمز السمة */
    var theme: String
        get() = sp.getString("theme", "") ?: ""
        set(v) { sp.edit().putString("theme", v).apply() }

    var role: Int
        get() = sp.getInt("role", 0)
        set(v) { sp.edit().putInt("role", v).apply() }

    var tutorialSeen: Boolean
        get() = sp.getBoolean("tutorial", false)
        set(v) { sp.edit().putBoolean("tutorial", v).apply() }

    /** معرّف مجهول ثابت يتيح العودة إلى مقعدك بعد انقطاع الاتصال. */
    val playerId: String
        get() {
            var id = sp.getString("pid", null)
            if (id == null) {
                id = UUID.randomUUID().toString().replace("-", "").take(16)
                sp.edit().putString("pid", id).apply()
            }
            return id
        }

    val played: Int get() = sp.getInt("played", 0)
    val wins: Int get() = sp.getInt("wins", 0)
    val stars: Int get() = sp.getInt("stars", 0)
    val perfect: Int get() = sp.getInt("perfect", 0)

    fun record(stars: Int) {
        sp.edit()
            .putInt("played", played + 1)
            .putInt("wins", wins + if (stars >= 1) 1 else 0)
            .putInt("stars", this.stars + stars)
            .putInt("perfect", perfect + if (stars == 3) 1 else 0)
            .apply()
    }
}
