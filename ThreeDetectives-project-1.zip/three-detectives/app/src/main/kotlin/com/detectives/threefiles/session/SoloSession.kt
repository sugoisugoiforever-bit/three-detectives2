package com.detectives.threefiles.session

import android.os.SystemClock
import game.Action
import game.Game
import game.PView
import game.view
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** لعب فردي: لاعب بشري واحد وبوتان على نفس المحرك، بساعة افتراضية تتوقف عند الإيقاف المؤقت. */
class SoloSession(private val game: Game, private val seat: Int) : GameSession {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _snap = MutableStateFlow<Snap?>(null)
    private val _msgs = MutableSharedFlow<String>(extraBufferCapacity = 16)
    private val _lobby = MutableStateFlow<Lobby?>(null)
    private val _conn = MutableStateFlow("ok")

    override val snap: StateFlow<Snap?> = _snap
    override val lobby: StateFlow<Lobby?> = _lobby
    override val messages: SharedFlow<String> = _msgs
    override val connection: StateFlow<String> = _conn
    override val online: Boolean = false

    private var clock = 0L
    private var last = SystemClock.elapsedRealtime()
    private var paused = false

    init {
        publish(force = true)
        scope.launch {
            while (isActive) {
                delay(250)
                step()
            }
        }
    }

    private fun step() {
        val t = SystemClock.elapsedRealtime()
        if (!paused) {
            clock += t - last
            game.tick(clock)
        }
        last = t
        publish()
    }

    private var lastKey: PView? = null

    /** ننشر فقط عند تغيّر شيء ظاهر (المؤقت تحسبه الواجهة محلياً) لتخفيف إعادة التركيب. */
    private fun publish(force: Boolean = false) {
        val v = game.view(seat, clock)
        val key = v.copy(endsInMs = 0L)
        if (force || key != lastKey) {
            lastKey = key
            _snap.value = Snap(v, SystemClock.elapsedRealtime(), paused)
        }
    }

    override fun send(a: Action) {
        val err = game.handle(seat, a, clock)
        if (err != null) _msgs.tryEmit(err)
        publish()
    }

    override fun pause(on: Boolean) {
        if (on == paused) return
        paused = on
        last = SystemClock.elapsedRealtime()
        publish(force = true)
    }

    override fun close() {
        scope.cancel()
    }
}
