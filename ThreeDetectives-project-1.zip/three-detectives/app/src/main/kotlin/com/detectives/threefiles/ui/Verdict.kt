package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.detectives.threefiles.audio.Sfx
import game.PView
import game.QUESTION_AR
import game.ROLE_AR

fun verdictTitle(stars: Int): String = when (stars) {
    3 -> "قضية محكمة"
    2 -> "قضية مغلقة"
    1 -> "إغلاق بثغرة"
    else -> "فشل التحقيق"
}

private fun verdictNote(stars: Int, window: Int): String = when (stars) {
    3 -> "ثلاث إجابات صحيحة وكلها بأدلة حاسمة من النافذة الأولى. تحقيق مثالي!"
    2 -> {
        if (window == 2) "ثلاث إجابات صحيحة في النافذة الأخيرة. للنجمة الثالثة اتهموا من النافذة الأولى."
        else "ثلاث إجابات صحيحة، لكن بعض أدلتكم لم تكن الأقوى. للنجمة الثالثة استشهدوا بالدليلين الحاسمين."
    }
    1 -> "إجابتان صحيحتان فقط. الثالثة بقيت لغزاً."
    else -> "أقل من إجابتين صحيحتين. راجعوا الوثائق في المرة القادمة."
}

@Composable
private fun ResultRow(v: PView, qi: Int) {
    val s = LocalS.current
    val r = v.result ?: return
    val q = v.info.questions[qi]
    val sol = r.solution.getOrNull(qi)
    val ok = r.correct.getOrNull(qi) == true
    val given = v.draft.answers[q.id]?.let { q.options.getOrNull(it)?.label }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(8), Alignment.End), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(1))) {
            ArText(QUESTION_AR[q.id] ?: q.prompt, 9.6f, Color(0xFF8E1A12), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
            ArText(sol?.label ?: "", 13, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
            if (!ok) {
                ArText("إجابتكم: " + (given ?: "بلا إجابة"), 9.8f, Color(0xFF8E1A12), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
            }
            if (sol != null) {
                ArText(
                    "الدليل: " + sol.proof.joinToString(" + ") { "«" + it.title + "» (" + ROLE_AR[it.owner] + ")" },
                    9.2f, InkSoft, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif,
                )
            }
        }
        Box(
            Modifier.size(s(24)).background(if (ok) Good else Color(0xFFB3261E), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            ArText(if (ok) "✓" else "✗", 14, Color.White, FontWeight.Bold, TextAlign.Center)
        }
    }
}

/** شاشة الحكم: ختم النتيجة، النجوم، وكشف الحل مع وثائق الإثبات. */
@Composable
fun VerdictScreen(v: PView, online: Boolean, onAgain: () -> Unit, onMenu: () -> Unit) {
    val s = LocalS.current
    val r = v.result ?: return
    LaunchedEffect(r.stars) {
        Sfx.stamp()
        if (r.win) Sfx.win() else Sfx.lose()
    }
    val stampColor = if (r.win) Color(0xDD2F6B2B) else Color(0xDDB3261E)
    Row(Modifier.fillMaxSize().padding(horizontal = s(14), vertical = s(10)), horizontalArrangement = Arrangement.spacedBy(s(14))) {
        Column(
            Modifier.width(s(230)).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(s(10), Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ArText("الحكم النهائي", 14, Brass, FontWeight.Bold, TextAlign.Center, font = Serif, shadow = true)
            Stars(r.stars, 40)
            Box(
                Modifier.rotate(-6f)
                    .background(Color(0xF2F3E9D0), RoundedCornerShape(s(6)))
                    .border(s(3), stampColor, RoundedCornerShape(s(6)))
                    .padding(horizontal = s(12), vertical = s(5)),
            ) {
                ArText(verdictTitle(r.stars), 22, stampColor, FontWeight.Bold, TextAlign.Center, font = Serif)
            }
            ArText(verdictNote(r.stars, r.window), 10, Cream, FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth())
            WaxButton(if (online) "جولة جديدة بنفس الفريق" else "قضية جديدة", onAgain, Modifier.fillMaxWidth(), size = 12)
            BrassButton("القائمة الرئيسية", onMenu, Modifier.fillMaxWidth(), size = 11)
        }
        PaperPanel(Modifier.weight(1f).fillMaxHeight()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = s(18), vertical = s(12)),
                verticalArrangement = Arrangement.spacedBy(s(11)),
            ) {
                ArText(v.info.title, 15, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                ArText("هكذا انحلّت القضية", 10, InkSoft, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                for (qi in 0 until v.info.questions.size) ResultRow(v, qi)
                ArText(
                    "القطع النحاسية المستعملة: " + (v.creditsMax - v.credits) + " من " + v.creditsMax +
                        " • " + (if (r.window == 1) "اتهام من النافذة الأولى" else "اتهام من النافذة الأخيرة"),
                    9.4f, Color(0xFF6A4A33), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif,
                )
            }
        }
    }
}
