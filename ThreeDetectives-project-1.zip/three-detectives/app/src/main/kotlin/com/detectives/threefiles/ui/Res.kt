package com.detectives.threefiles.ui

import androidx.compose.ui.graphics.Color
import com.detectives.threefiles.R

/** ربط معرّفات القضية بالموارد المرسومة. */
object Pics {
    private val portraits = intArrayOf(
        R.drawable.portrait_00, R.drawable.portrait_01, R.drawable.portrait_02, R.drawable.portrait_03,
        R.drawable.portrait_04, R.drawable.portrait_05, R.drawable.portrait_06, R.drawable.portrait_07,
        R.drawable.portrait_08, R.drawable.portrait_09, R.drawable.portrait_10, R.drawable.portrait_11,
        R.drawable.portrait_12, R.drawable.portrait_13,
    )

    fun portrait(i: Int): Int = portraits[((i % portraits.size) + portraits.size) % portraits.size]

    private val pins = intArrayOf(R.drawable.pin_red, R.drawable.pin_blue, R.drawable.pin_yellow, R.drawable.pin_green)

    fun pin(i: Int): Int = pins[((i % pins.size) + pins.size) % pins.size]

    fun paper(kind: String): Int = when (kind) {
        "witness", "calls" -> R.drawable.paper_legal
        "bank", "report", "access" -> R.drawable.paper_white
        else -> R.drawable.paper_cream
    }

    /** أيقونة القدرة الخاصة لكل دور. */
    fun ability(seat: Int): Int = when (seat) {
        0 -> R.drawable.icon_audit
        1 -> R.drawable.icon_raid
        else -> R.drawable.icon_intercept
    }

    /** لون شريط نوع الوثيقة. */
    fun kindColor(kind: String): Color = when (kind) {
        "bank" -> Color(0xFF3E7D3A)
        "invoice" -> Color(0xFFC77D1E)
        "report" -> Color(0xFF2F5F9E)
        "witness" -> Color(0xFF7B4B94)
        "calls" -> Color(0xFF1F8A8A)
        "chat" -> Color(0xFFB5456B)
        "access" -> Color(0xFF55606B)
        else -> Color(0xFF7A5230)
    }
}

val ROLE_DESC = listOf(
    "يقرأ الحسابات والفواتير. قدرته «تدقيق»: يفحص وثيقة ليعرف هل هي حاسمة أم تشويش.",
    "يعاين المواقع ويستجوب الشهود. قدرته «مداهمة»: يجلب وثيقة الجولة القادمة فوراً.",
    "يحلّل المكالمات والرسائل. قدرته «اعتراض»: يكشف عنوان أول وثيقة تُرسَل بين زميليه.",
)

val ABILITY_DESC = listOf(
    "افحص وثيقة واحدة تراها لتعرف إن كانت حاسمة للحل أم تشويشاً. النتيجة تظهر لك وحدك.",
    "اجلب أول وثيقة من الجولة القادمة لتصل إلى صاحبها الآن.",
    "يكشف لك عنوان ونوع أول وثيقة يرسلها زميلاك أحدهما إلى الآخر.",
)

val THEME_AR = mapOf(
    "" to "عشوائية",
    "museum" to "متحف",
    "techco" to "شركة تقنية",
    "warehouse" to "مستودع",
)

val DIFF_AR = listOf("سهل", "عادي", "صعب")
