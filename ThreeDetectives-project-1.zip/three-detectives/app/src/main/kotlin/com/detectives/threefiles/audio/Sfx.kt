package com.detectives.threefiles.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.detectives.threefiles.R

/** مؤثرات صوتية قصيرة عبر SoundPool. */
object Sfx {
    private var pool: SoundPool? = null
    private val ids = HashMap<Int, Int>()
    var enabled = true

    private val all = intArrayOf(
        R.raw.sfx_tap, R.raw.sfx_page, R.raw.sfx_coin, R.raw.sfx_stamp, R.raw.sfx_seal,
        R.raw.sfx_tick, R.raw.sfx_bell, R.raw.sfx_request, R.raw.sfx_win, R.raw.sfx_lose,
    )

    fun init(ctx: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(5).setAudioAttributes(attrs).build()
        for (r in all) ids[r] = p.load(ctx.applicationContext, r, 1)
        pool = p
    }

    private fun play(res: Int, vol: Float) {
        if (!enabled) return
        val id = ids[res] ?: return
        pool?.play(id, vol, vol, 1, 0, 1f)
    }

    fun tap() = play(R.raw.sfx_tap, 0.55f)
    fun page() = play(R.raw.sfx_page, 0.7f)
    fun coin() = play(R.raw.sfx_coin, 0.7f)
    fun stamp() = play(R.raw.sfx_stamp, 0.85f)
    fun seal() = play(R.raw.sfx_seal, 0.8f)
    fun tick() = play(R.raw.sfx_tick, 0.5f)
    fun bell() = play(R.raw.sfx_bell, 0.7f)
    fun request() = play(R.raw.sfx_request, 0.8f)
    fun win() = play(R.raw.sfx_win, 0.8f)
    fun lose() = play(R.raw.sfx_lose, 0.8f)
}
