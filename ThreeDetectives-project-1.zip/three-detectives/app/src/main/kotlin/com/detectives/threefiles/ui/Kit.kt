package com.detectives.threefiles.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.detectives.threefiles.R
import com.detectives.threefiles.audio.Sfx

// ───────────── الألوان ─────────────
val Ink = Color(0xFF2A1E15)
val InkSoft = Color(0xFF5E4838)
val Brass = Color(0xFFEBD9A8)
val BrassDark = Color(0xFFB8943F)
val Wax = Color(0xFFB3261E)
val WaxDark = Color(0xFF7E1913)
val Leather = Color(0xFF3A2619)
val LeatherDark = Color(0xFF22150D)
val Good = Color(0xFF3E7D3A)
val Mark = Color(0x99FFD54F)
val Cream = Color(0xFFF3E9D0)

// ───────────── المقياس ─────────────

/** وحدة الواجهة: 1 = 1/360 من ارتفاع الشاشة. الواجهة كلها تُحسب بهذه الوحدة لتتطابق على كل الأجهزة. */
class S(val k: Float) {
    operator fun invoke(n: Number): Dp = (n.toFloat() * k).dp
    fun sp(n: Number): TextUnit = (n.toFloat() * k).sp
}

val LocalS = staticCompositionLocalOf { S(1f) }

// ───────────── الصور ─────────────

@Composable
fun Pic(
    id: Int,
    modifier: Modifier = Modifier,
    scale: ContentScale = ContentScale.FillBounds,
    tint: Color? = null,
    alpha: Float = 1f,
    blend: BlendMode = BlendMode.SrcIn,
) {
    Image(
        painter = painterResource(id),
        contentDescription = null,
        modifier = modifier,
        contentScale = scale,
        alpha = alpha,
        colorFilter = if (tint != null) ColorFilter.tint(tint, blend) else null,
    )
}

// ───────────── النص ─────────────

val Serif: FontFamily = FontFamily.Serif
val Hand: FontFamily = FontFamily.Cursive

@Composable
fun ArText(
    text: String,
    size: Number = 11,
    color: Color = Ink,
    weight: FontWeight = FontWeight.Normal,
    align: TextAlign = TextAlign.Right,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    font: FontFamily = FontFamily.Default,
    shadow: Boolean = false,
    ltr: Boolean = false,
) {
    val s = LocalS.current
    BasicText(
        text = text,
        modifier = modifier,
        style = arStyle(s, size, color, weight, align, font, shadow, ltr),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun ArRich(
    text: AnnotatedString,
    size: Number = 11,
    color: Color = Ink,
    weight: FontWeight = FontWeight.Normal,
    align: TextAlign = TextAlign.Right,
    modifier: Modifier = Modifier,
    font: FontFamily = FontFamily.Default,
) {
    val s = LocalS.current
    BasicText(
        text = text,
        modifier = modifier,
        style = arStyle(s, size, color, weight, align, font, false, false),
    )
}

private fun arStyle(
    s: S, size: Number, color: Color, weight: FontWeight, align: TextAlign, font: FontFamily, shadow: Boolean, ltr: Boolean,
): TextStyle = TextStyle(
    color = color,
    fontSize = s.sp(size),
    fontWeight = weight,
    fontFamily = font,
    textAlign = align,
    textDirection = if (ltr) TextDirection.Ltr else TextDirection.Rtl,
    lineHeight = s.sp(size.toFloat() * 1.38f),
    shadow = if (shadow) Shadow(Color(0xCC000000), Offset(0f, 2f), 4f) else null,
)

// ───────────── التفاعل ─────────────

/** ضغطة ببروز خفيف بدل الموجة (ripple) لأن المظهر مادّي لا رقمي. */
@Composable
fun Press(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    sound: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(targetValue = if (pressed && enabled) 0.93f else 1f, animationSpec = tween(90), label = "press")
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = sc
                scaleY = sc
            }
            .clickable(interactionSource = src, indication = null, enabled = enabled) {
                if (sound) Sfx.tap()
                onClick()
            },
        content = content,
    )
}

/** يبتلع النقرات كي لا تصل إلى الطبقة التي تحته (لإغلاق النوافذ بالنقر خارجها). */
fun Modifier.swallowTaps(): Modifier = this.pointerInput(Unit) { detectTapGestures(onTap = { }) }

// ───────────── الأزرار ─────────────

@Composable
fun BrassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    size: Number = 12,
    icon: Int? = null,
    height: Number = 32,
) {
    val s = LocalS.current
    Press(onClick, modifier.height(s(height)).alpha(if (enabled) 1f else 0.5f), enabled) {
        BrassFace(Modifier.matchParentSize())
        Row(
            Modifier.align(Alignment.Center).padding(horizontal = s(8)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(s(6)),
        ) {
            if (icon != null) Pic(icon, Modifier.size(s(height.toFloat() * 0.6f)))
            ArText(text, size, Ink, FontWeight.Bold, TextAlign.Center)
        }
    }
}

/** وجه نحاسي مصقول (تدرّج + حافة + لمعة علوية) يملأ الحيّز الممنوح له. */
@Composable
fun BrassFace(modifier: Modifier = Modifier, radius: Number = 7) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(radius))
    Box(
        modifier
            .shadow(s(3), shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFF8E8A6), Color(0xFFE3C46D), Color(0xFFB98F34))))
            .border(s(1), Color(0xFF6E5214), shape),
    ) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(horizontal = s(6), vertical = s(2))
                .fillMaxWidth()
                .height(s(1))
                .background(Color(0x77FFFFFF)),
        )
    }
}

/** لوحة نحاسية تلتفّ حول محتواها (لافتات صغيرة ورسائل عابرة). */
@Composable
fun BrassPlate(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier) {
        BrassFace(Modifier.matchParentSize())
        content()
    }
}

/** زر أحمر بلون شمع الختم للإجراءات الحاسمة. */
@Composable
fun WaxButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    size: Number = 12,
    height: Number = 34,
) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(9))
    Press(onClick, modifier.height(s(height)).alpha(if (enabled) 1f else 0.5f), enabled) {
        Box(
            Modifier
                .matchParentSize()
                .shadow(s(4), shape)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFFD8463B), Color(0xFF8E1A12))))
                .border(s(1.2f), Color(0xFF4F0D08), shape),
        )
        Box(Modifier.align(Alignment.Center).padding(horizontal = s(16))) {
            ArText(text, size, Cream, FontWeight.Bold, TextAlign.Center, shadow = true)
        }
    }
}

/** شريحة اختيار (مختارة = نحاسية، وإلا جلدية داكنة). */
@Composable
fun Chip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Number = 11,
    enabled: Boolean = true,
) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(7))
    Press(onClick, modifier.alpha(if (enabled) 1f else 0.45f), enabled) {
        Box(
            Modifier
                .matchParentSize()
                .clip(shape)
                .background(
                    if (selected) Brush.verticalGradient(listOf(Color(0xFFF1D98A), Color(0xFFC49A3E)))
                    else Brush.verticalGradient(listOf(Color(0xFF4A3223), Color(0xFF2C1C12))),
                )
                .border(s(1), if (selected) Color(0xFF6E5214) else BrassDark.copy(alpha = 0.55f), shape),
        )
        Box(Modifier.align(Alignment.Center).padding(horizontal = s(10), vertical = s(5))) {
            ArText(text, size, if (selected) Ink else Brass, FontWeight.Bold, TextAlign.Center)
        }
    }
}

// ───────────── الألواح ─────────────

/** لوح جلدي داكن بإطار نحاسي (للنوافذ والقوائم). */
@Composable
fun LeatherPanel(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(9))
    Box(
        modifier
            .shadow(s(12), shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Leather, LeatherDark)))
            .border(s(1.6f), BrassDark, shape),
        content = content,
    )
}

/** ورقة كريمية (للنوافذ التي تحاكي ورقة على المكتب). */
@Composable
fun PaperPanel(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(5))
    Box(
        modifier
            .shadow(s(10), shape)
            .clip(shape)
            .border(s(1), Color(0x66000000), shape),
    ) {
        Pic(R.drawable.paper_cream, Modifier.matchParentSize(), ContentScale.Crop)
        content()
    }
}

/** طبقة معتمة تغطي الشاشة ومحتوى في وسطها؛ النقر خارج المحتوى يغلقه إن مُرِّر onDismiss. */
@Composable
fun Scrim(onDismiss: (() -> Unit)?, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xB8000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onDismiss?.invoke() }) },
        contentAlignment = Alignment.Center,
        content = content,
    )
}

// ───────────── عناصر صغيرة ─────────────

@Composable
fun Stars(n: Int, size: Number, modifier: Modifier = Modifier) {
    val s = LocalS.current
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(s(3))) {
        for (i in 0 until 3) Pic(if (i < n) R.drawable.star_gold else R.drawable.star_empty, Modifier.size(s(size)), alpha = if (i < n) 1f else 0.55f)
    }
}

@Composable
fun Coins(have: Int, max: Int, size: Number, modifier: Modifier = Modifier) {
    val s = LocalS.current
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(s(2))) {
        for (i in 0 until max) Pic(if (i < have) R.drawable.coin else R.drawable.coin_empty, Modifier.size(s(size)))
    }
}

/** رسالة عابرة تظهر أعلى الشاشة. */
@Composable
fun ToastBar(text: String, visible: Boolean, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val a by animateFloatAsState(targetValue = if (visible) 1f else 0f, animationSpec = tween(180), label = "toast")
    if (a > 0.01f) {
        BrassPlate(modifier.graphicsLayer { alpha = a }) {
            Box(Modifier.padding(horizontal = s(18), vertical = s(7))) {
                ArText(text, 11.5f, Ink, FontWeight.Bold, TextAlign.Center, maxLines = 2)
            }
        }
    }
}

/** زر إغلاق صغير. */
@Composable
fun CloseButton(onClick: () -> Unit, modifier: Modifier = Modifier, text: String = "إغلاق") {
    BrassButton(text, onClick, modifier, size = 10, height = 24)
}

/** نافذة جلدية بعنوان وزر إغلاق، يتمدّد محتواها عمودياً مع تمرير عند الحاجة. */
@Composable
fun Sheet(
    title: String,
    onClose: () -> Unit,
    width: Number,
    content: @Composable ColumnScope.() -> Unit,
) {
    val s = LocalS.current
    Scrim(onDismiss = onClose) {
        LeatherPanel(Modifier.width(s(width)).heightIn(max = s(338)).swallowTaps()) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(s(12)),
                verticalArrangement = Arrangement.spacedBy(s(8)),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    CloseButton(onClose)
                    ArText(title, 15, Brass, FontWeight.Bold, TextAlign.Right, font = Serif)
                }
                content()
            }
        }
    }
}

/** عدّاد الوقت بصيغة 03:25 */
fun clock(ms: Long): String {
    val t = (ms.coerceAtLeast(0L) + 999L) / 1000L
    val m = t / 60
    val sec = t % 60
    return (if (m < 10) "0$m" else "$m") + ":" + (if (sec < 10) "0$sec" else "$sec")
}

// ───────────── حقول الإدخال ─────────────

/** حقل نص داكن بإطار نحاسي. ltr=true للعناوين والرموز اللاتينية. */
@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    ltr: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text,
    caps: KeyboardCapitalization = KeyboardCapitalization.None,
    size: Number = 12,
    height: Number = 34,
    enabled: Boolean = true,
) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(7))
    Box(
        modifier
            .height(s(height))
            .clip(shape)
            .background(Color(0x66000000))
            .border(s(1.2f), BrassDark.copy(alpha = 0.8f), shape)
            .padding(horizontal = s(10)),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            enabled = enabled,
            singleLine = true,
            textStyle = TextStyle(
                color = Cream,
                fontSize = s.sp(size),
                fontWeight = FontWeight.Bold,
                textAlign = if (ltr) TextAlign.Left else TextAlign.Right,
                textDirection = if (ltr) TextDirection.Ltr else TextDirection.Rtl,
            ),
            cursorBrush = SolidColor(Brass),
            keyboardOptions = KeyboardOptions(capitalization = caps, keyboardType = keyboard, imeAction = ImeAction.Done),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (ltr) Alignment.CenterStart else Alignment.CenterEnd) {
                    if (value.isEmpty()) {
                        ArText(hint, size, Color(0x88EBD9A8), FontWeight.Normal, if (ltr) TextAlign.Left else TextAlign.Right, Modifier.fillMaxWidth())
                    }
                    inner()
                }
            },
        )
    }
}

/** مفتاح تشغيل/إيقاف بمظهر نحاسي. */
@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(11))
    Press({ onChange(!on) }, modifier.size(s(44), s(22))) {
        Box(
            Modifier.matchParentSize().clip(shape)
                .background(if (on) Brush.verticalGradient(listOf(Color(0xFF6FA55F), Color(0xFF3E7D3A))) else Brush.verticalGradient(listOf(Color(0xFF5A4A40), Color(0xFF2C1C12))))
                .border(s(1), BrassDark, shape),
        )
        Box(
            Modifier.align(if (on) Alignment.CenterEnd else Alignment.CenterStart).padding(horizontal = s(2)).size(s(17)),
        ) {
            BrassFace(Modifier.matchParentSize(), 9)
        }
    }
}
