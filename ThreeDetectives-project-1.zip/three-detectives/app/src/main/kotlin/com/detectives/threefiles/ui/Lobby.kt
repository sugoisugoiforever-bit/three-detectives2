package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import com.detectives.threefiles.R
import com.detectives.threefiles.session.Lobby
import com.detectives.threefiles.session.LobbySeat
import game.ABILITY_AR
import game.ROLE_AR

/** لافتة نحاسية داكنة تحمل رمز الغرفة بأحرف كبيرة. */
@Composable
fun CodePlaque(code: String, modifier: Modifier = Modifier) {
    val s = LocalS.current
    Box(modifier.size(s(236), s(62))) {
        Pic(R.drawable.plaque, Modifier.matchParentSize())
        Column(Modifier.matchParentSize().padding(vertical = s(9)), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            ArText("رمز الغرفة", 7.6f, Color(0xCCEBD9A8), FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth())
            ArText(code.toCharArray().joinToString("  "), 19, Cream, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif, ltr = true)
        }
    }
}

/** بطاقة مقعد: الدور والقدرة والجالس عليه، وزر الجلوس إن كان متاحاً. */
@Composable
fun SeatCard(seat: Int, occupant: LobbySeat?, mine: Boolean, onSit: () -> Unit, w: Dp) {
    val s = LocalS.current
    val h = w * (412f / 312f)
    val human = occupant != null && !occupant.bot
    val canSit = !mine && !(human && occupant != null && occupant.connected)
    Box(Modifier.size(w, h)) {
        Pic(R.drawable.card_vintage, Modifier.matchParentSize())
        Column(
            Modifier.matchParentSize().padding(horizontal = w * 0.14f, vertical = h * 0.095f),
            verticalArrangement = Arrangement.spacedBy(s(2)),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Pic(Pics.ability(seat), Modifier.size(s(24)))
            ArText(ROLE_AR[seat], 10.5f, Ink, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
            ArText("قدرته: " + ABILITY_AR[seat], 7.8f, Color(0xFF8E1A12), FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
            Box(Modifier.height(s(2)))
            val label = when {
                mine -> "أنت"
                occupant == null -> "مقعد فارغ"
                occupant.bot -> "محقق آلي"
                !occupant.connected -> occupant.name + " (منقطع)"
                else -> occupant.name
            }
            Box(
                Modifier.fillMaxWidth().background(if (mine) Color(0x33B3261E) else Color(0x22000000), RoundedCornerShape(s(4))).padding(vertical = s(3), horizontal = s(2)),
                contentAlignment = Alignment.Center,
            ) {
                ArText(label, 9, if (mine) Wax else Ink, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), maxLines = 1)
            }
            if (canSit) {
                BrassButton("اجلس هنا", onSit, Modifier.fillMaxWidth(), size = 8.8f, height = 22)
            }
        }
    }
}

@Composable
fun SeatRow(lobby: Lobby, onSeat: (Int) -> Unit, w: Dp) {
    val s = LocalS.current
    Row(horizontalArrangement = Arrangement.spacedBy(s(7))) {
        for (i in 2 downTo 0) {
            SeatCard(i, lobby.seats.firstOrNull { it.seat == i }, lobby.mySeat == i, { onSeat(i) }, w)
        }
    }
}

@Composable
fun LobbyScreen(
    lobby: Lobby?,
    connection: String,
    onSeat: (Int) -> Unit,
    onConfig: (String, Int) -> Unit,
    onStart: () -> Unit,
    onShare: () -> Unit,
    onLeave: () -> Unit,
) {
    val s = LocalS.current
    Frame("غرفة التحقيق", onLeave, backText = "غادر الغرفة") {
        if (lobby == null) {
            Box(Modifier.fillMaxWidth().height(s(120)), contentAlignment = Alignment.Center) {
                ArText(
                    if (connection == "closed" || connection == "lost") "انقطع الاتصال بالغرفة." else "جارٍ الدخول إلى الغرفة…",
                    13, Brass, FontWeight.Bold, TextAlign.Center,
                )
            }
            return@Frame
        }
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val wide = maxWidth >= s(560)
            val cardW: Dp = if (wide) s(100) else minOf(s(100), (maxWidth - s(14)) / 3)
            val side: @Composable (Modifier) -> Unit = { m ->
                Column(m, verticalArrangement = Arrangement.spacedBy(s(6))) {
                    SectionLabel("القضية")
                    ChipRows(THEME_ITEMS, lobby.theme, 4, { if (lobby.host) onConfig(it, lobby.difficulty) }, 10)
                    SectionLabel("الصعوبة")
                    ChipRows(DIFF_AR.mapIndexed { i, t -> i.toString() to t }, lobby.difficulty.toString(), 3, { if (lobby.host) onConfig(lobby.theme, it.toInt()) }, 10.5f)
                    if (!lobby.host) Note("المضيف وحده يغيّر القضية والصعوبة ويبدأ التحقيق.")
                    Box(Modifier.height(s(2)))
                    if (lobby.host) {
                        WaxButton("ابدأ التحقيق", onStart, Modifier.fillMaxWidth(), size = 13.5f, height = 38)
                        Note("المقاعد الفارغة يشغلها محققون آليون حتى لو لم ينضم أحد.")
                    } else {
                        BrassButton("بانتظار المضيف…", { }, Modifier.fillMaxWidth(), enabled = false, size = 11.5f, height = 34)
                    }
                    if (connection != "ok") Note(if (connection == "connecting") "جارٍ الاتصال…" else "انقطع الاتصال، تجري إعادة المحاولة…", warn = true)
                }
            }
            val seats: @Composable () -> Unit = {
                Column(verticalArrangement = Arrangement.spacedBy(s(7)), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(horizontalArrangement = Arrangement.spacedBy(s(8)), verticalAlignment = Alignment.CenterVertically) {
                        BrassButton("شارك الرمز", onShare, Modifier.size(s(84), s(28)), size = 10, height = 28)
                        CodePlaque(lobby.code)
                    }
                    SeatRow(lobby, onSeat, cardW)
                }
            }
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(16), Alignment.End)) {
                    side(Modifier.weight(1f))
                    seats()
                }
            } else {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(s(10)), horizontalAlignment = Alignment.CenterHorizontally) {
                    seats()
                    side(Modifier.fillMaxWidth())
                }
            }
        }
    }
}
