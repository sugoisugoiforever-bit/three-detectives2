package com.detectives.threefiles.session

import android.os.SystemClock
import game.Action
import game.Json
import game.asMap
import game.int
import game.list
import game.obj
import game.pviewFromJson
import game.str
import game.toJson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener

/**
 * لعب جماعي عبر WebSocket مع خادم Cloudflare. الخادم هو الحَكَم: العميل يرسل الحركات فقط
 * ويستقبل "عرض اللاعب" الكامل بعد كل تغيير. عند انقطاع الاتصال تتم إعادة المحاولة تلقائياً.
 */
class OnlineSession(
    private val base: String,
    private val code: String,
    private val pid: String,
    private val name: String,
) : GameSession {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _snap = MutableStateFlow<Snap?>(null)
    private val _lobby = MutableStateFlow<Lobby?>(null)
    private val _msgs = MutableSharedFlow<String>(extraBufferCapacity = 16)
    private val _conn = MutableStateFlow("connecting")

    override val snap: StateFlow<Snap?> = _snap
    override val lobby: StateFlow<Lobby?> = _lobby
    override val messages: SharedFlow<String> = _msgs
    override val connection: StateFlow<String> = _conn
    override val online: Boolean = true

    @Volatile
    private var failMsg: String? = null
    override val failure: String? get() = failMsg

    private val lock = Any()
    private var socket: WebSocket? = null
    private var gen = 0
    private var finished = false
    private var attempt = 0
    private var retry: Job? = null

    init {
        open()
    }

    private fun open() {
        var g = 0
        synchronized(lock) {
            if (finished) return
            gen += 1
            g = gen
            socket?.cancel()
            socket = null
        }
        val url = try {
            base.toHttpUrl().newBuilder()
                .addPathSegment("ws")
                .addPathSegment(code)
                .addQueryParameter("pid", pid)
                .addQueryParameter("name", name)
                .build()
        } catch (e: Exception) {
            fail("عنوان الخادم غير صالح")
            return
        }
        val ws = Net.client.newWebSocket(Request.Builder().url(url).build(), Listener(g))
        synchronized(lock) {
            if (gen == g && !finished) socket = ws else ws.cancel()
        }
    }

    private inner class Listener(val g: Int) : WebSocketListener() {
        private fun stale(): Boolean = synchronized(lock) { g != gen || finished }

        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (stale()) return
            attempt = 0
            _conn.value = "ok"
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (stale()) return
            handle(text)
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (stale()) return
            dropped()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (stale()) return
            val c = response?.code ?: 0
            if (c in 400..499) {
                fail(
                    when (c) {
                        404 -> "الغرفة غير موجودة. تأكّد من الرمز."
                        409 -> "الغرفة ممتلئة أو أن اللعبة بدأت بالفعل."
                        else -> "رفض الخادم الاتصال ($c)."
                    },
                )
            } else {
                dropped()
            }
        }
    }

    /** انقطاع مؤقت: نعيد المحاولة بتباعد متزايد (1، 2، 4، 8 ثوانٍ). */
    private fun dropped() {
        _conn.value = "lost"
        val wait = minOf(8000L, 1000L shl minOf(attempt, 3))
        attempt += 1
        synchronized(lock) {
            if (finished) return
            retry?.cancel()
            retry = scope.launch {
                delay(wait)
                open()
            }
        }
    }

    /** إغلاق نهائي (رفض الخادم أو إغلاق الغرفة). */
    private fun fail(msg: String) {
        failMsg = msg
        synchronized(lock) {
            finished = true
            socket?.cancel()
            socket = null
            retry?.cancel()
        }
        _msgs.tryEmit(msg)
        _conn.value = "closed"
    }

    private fun handle(text: String) {
        val m = try {
            Json.parse(text).asMap()
        } catch (e: Exception) {
            return
        }
        try {
            when (m["t"]) {
                "lobby" -> {
                    val started = (m["started"] as Boolean?) ?: false
                    _lobby.value = Lobby(
                        code = m.str("code"),
                        mySeat = m.int("seat"),
                        host = (m["host"] as Boolean?) ?: false,
                        theme = (m["theme"] as String?) ?: "",
                        difficulty = m.int("difficulty"),
                        started = started,
                        seats = m.list("seats").map { s ->
                            val sm = s.asMap()
                            LobbySeat(
                                sm.int("seat"), (sm["name"] as String?) ?: "",
                                (sm["bot"] as Boolean?) ?: true, (sm["connected"] as Boolean?) ?: false,
                            )
                        },
                    )
                    if (!started) _snap.value = null
                }
                "view" -> _snap.value = Snap(pviewFromJson(m.obj("v")), SystemClock.elapsedRealtime())
                "err" -> _msgs.tryEmit(m.str("m"))
                "closed" -> fail(m.str("m"))
            }
        } catch (e: Exception) {
            // رسالة معطوبة: نتجاهلها وننتظر التالية
        }
    }

    private fun out(m: Map<String, Any?>): Boolean {
        val s = synchronized(lock) { socket } ?: return false
        return s.send(Json.stringify(m))
    }

    override fun send(a: Action) {
        if (!out(linkedMapOf("t" to "act", "a" to a.toJson()))) _msgs.tryEmit("لا يوجد اتصال بالخادم حالياً")
    }

    override fun config(theme: String, difficulty: Int) {
        out(linkedMapOf("t" to "cfg", "theme" to theme, "difficulty" to difficulty))
    }

    override fun chooseSeat(seat: Int) {
        out(linkedMapOf("t" to "seat", "seat" to seat))
    }

    override fun start() {
        out(linkedMapOf("t" to "start"))
    }

    override fun again() {
        out(linkedMapOf("t" to "again"))
    }

    /** عند عودة التطبيق إلى الواجهة والاتصال مقطوع نعيد المحاولة فوراً. */
    override fun pause(on: Boolean) {
        if (!on && _conn.value == "lost") {
            scope.launch { open() }
        }
    }

    override fun close() {
        var s: WebSocket? = null
        synchronized(lock) {
            finished = true
            s = socket
            socket = null
            retry?.cancel()
        }
        s?.send("""{"t":"leave"}""")
        s?.close(1000, null)
        scope.cancel()
    }
}
