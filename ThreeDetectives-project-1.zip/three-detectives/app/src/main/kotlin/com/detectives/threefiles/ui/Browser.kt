package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import game.KIND_AR
import game.PDoc
import game.PView
import game.ROLE_AR

/** وضع الاختيار: يُظهر زراً واحداً يعيد الوثيقة المختارة (استشهاد، تدقيق، رد على طلب). */
class Pick(val button: String, val hint: String, val onPick: (PDoc) -> Unit)

/** سبب تعذّر الإرسال أو السؤال الآن، أو null إن كان ممكناً. */
fun moveBlock(v: PView): String? {
    val me = v.players[v.seat]
    return when {
        v.phase != "round" -> "التواصل متاح أثناء الجولات فقط"
        me.moveUsed -> "استهلكتَ حركتك في هذه الجولة"
        else -> null
    }
}

/** متصفّح الوثائق: قائمة، ورقة كاملة، ولوحة إجراءات (إرسال/سؤال/اختيار). */
@Composable
fun DocBrowser(
    v: PView,
    docs: List<PDoc>,
    startId: String?,
    unseen: Set<String>,
    pick: Pick?,
    onSend: (String, Int) -> Unit,
    onAsk: (String) -> Unit,
    onSeen: (String) -> Unit,
    onClose: () -> Unit,
) {
    val s = LocalS.current
    var sel by remember { mutableStateOf(startId ?: docs.firstOrNull()?.id) }
    val doc = docs.firstOrNull { it.id == sel } ?: docs.firstOrNull()
    LaunchedEffect(doc?.id) {
        if (doc != null) onSeen(doc.id)
    }
    Scrim(onDismiss = onClose) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = s(6), vertical = s(7))) {
            val ph = minOf(maxHeight, s(348))
            val pw = minOf(maxWidth, s(680))
            LeatherPanel(Modifier.align(Alignment.Center).size(pw, ph).swallowTaps()) {
                Row(
                    Modifier.fillMaxSize().padding(s(8)),
                    horizontalArrangement = Arrangement.spacedBy(s(8)),
                ) {
                    DocList(docs, doc?.id, unseen, { sel = it }, Modifier.width(s(98)).fillMaxHeight())
                    if (doc != null) {
                        val labels = doc.topics.mapNotNull { id -> v.topics.firstOrNull { it.id == id }?.label }
                        DocPaper(
                            doc, labels,
                            Modifier.fillMaxHeight().aspectRatio(0.73f, matchHeightConstraintsFirst = true),
                        )
                        DocActions(v, doc, pick, onSend, onAsk, onClose, Modifier.weight(1f).fillMaxHeight())
                    } else {
                        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            ArText("لا توجد وثائق", 13, Brass, FontWeight.Bold, TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DocList(
    docs: List<PDoc>,
    sel: String?,
    unseen: Set<String>,
    onSel: (String) -> Unit,
    modifier: Modifier,
) {
    val s = LocalS.current
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(s(4))) {
        for (d in docs) {
            val on = d.id == sel
            val shape = RoundedCornerShape(s(5))
            Press(
                onClick = { onSel(d.id) },
                modifier = Modifier.fillMaxWidth().height(s(42)),
            ) {
                Box(
                    Modifier
                        .matchParentSize()
                        .clip(shape)
                        .background(if (on) Color(0x40EBD9A8) else Color(0x14FFFFFF))
                        .border(s(if (on) 1.5f else 0.7f), if (on) Brass else Color(0x33EBD9A8), shape),
                )
                Box(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .width(s(3.5f))
                        .fillMaxHeight(0.74f)
                        .background(Pics.kindColor(d.kind), RoundedCornerShape(s(2))),
                )
                Column(
                    Modifier.matchParentSize().padding(start = s(5), end = s(9), top = s(3), bottom = s(3)),
                    verticalArrangement = Arrangement.Center,
                ) {
                    ArText(d.title, 9, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2)
                    ArText(
                        "ج${d.round} • " + (if (d.from < 0) "وثيقتك" else ROLE_AR[d.from]),
                        7.8f, Color(0xB3EBD9A8), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1,
                    )
                }
                if (d.id in unseen) {
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(s(3))
                            .size(s(7))
                            .background(Wax, androidx.compose.foundation.shape.CircleShape),
                    )
                }
            }
        }
    }
}

@Composable
private fun DocActions(
    v: PView,
    doc: PDoc,
    pick: Pick?,
    onSend: (String, Int) -> Unit,
    onAsk: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier,
) {
    val s = LocalS.current
    val me = v.seat
    var askTopic by remember(doc.id) { mutableStateOf<String?>(null) }
    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(s(6)),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CloseButton(onClose)
            ArText(if (pick != null) "اختيار وثيقة" else "الوثيقة", 10.5f, Color(0xB3EBD9A8), FontWeight.Bold)
        }
        ArText(doc.title, 13.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
        ArText(
            (KIND_AR[doc.kind] ?: doc.kind) + " • الجولة " + doc.round,
            10, Color(0xCCEBD9A8), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(),
        )
        ArText(
            if (doc.from < 0) "وثيقتك الأصلية" else "وصلتك من " + ROLE_AR[doc.from],
            10.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(),
        )
        if (doc.from < 0) {
            val others = doc.copies.filter { it != me }
            ArText(
                if (others.isEmpty()) "لم تُشارَك بعد" else "نسخ عند: " + others.joinToString("، ") { ROLE_AR[it] },
                9.5f, Color(0xCCEBD9A8), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(),
            )
        }
        if (doc.audit != null) {
            val good = doc.audit == "decisive"
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(if (good) Color(0x553E7D3A) else Color(0x55777777), RoundedCornerShape(s(6)))
                    .padding(horizontal = s(8), vertical = s(5)),
            ) {
                ArText(
                    if (good) "نتيجة التدقيق: وثيقة حاسمة للحل" else "نتيجة التدقيق: تشويش لا يفيد الحل",
                    10, Cream, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(),
                )
            }
        }
        if (pick != null) {
            ArText(pick.hint, 10, Color(0xCCEBD9A8), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
            WaxButton(pick.button, { pick.onPick(doc) }, Modifier.fillMaxWidth(), size = 12.5f)
        } else if (v.phase == "round") {
            val block = moveBlock(v)
            if (doc.from < 0) {
                ArText("إرسال نسخة إلى زميل (قطعة واحدة)", 10.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
                val reason = block ?: if (v.credits < 1) "نفدت القطع النحاسية" else null
                for (t in 0..2) {
                    if (t == me) continue
                    val has = t in doc.copies
                    BrassButton(
                        text = if (has) ROLE_AR[t] + ": لديه نسخة" else "أرسل إلى " + ROLE_AR[t],
                        onClick = { onSend(doc.id, t) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = reason == null && !has,
                        size = 10.5f,
                        height = 28,
                    )
                }
                if (reason != null) {
                    ArText(reason, 9, Color(0xFFE8A598), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
                }
            }
            val topics = doc.topics.mapNotNull { id -> v.topics.firstOrNull { it.id == id } }
            if (topics.isNotEmpty()) {
                ArText("اسأل الفريق عن موضوع في هذه الوثيقة (مجاني)", 10.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(4), Alignment.End)) {
                    for (t in topics.take(3)) {
                        Chip(t.label, askTopic == t.id, { askTopic = if (askTopic == t.id) null else t.id }, size = 9.5f)
                    }
                }
                if (topics.size > 3) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(4), Alignment.End)) {
                        for (t in topics.drop(3).take(3)) {
                            Chip(t.label, askTopic == t.id, { askTopic = if (askTopic == t.id) null else t.id }, size = 9.5f)
                        }
                    }
                }
                val chosen = askTopic
                if (chosen != null) {
                    BrassButton(
                        text = "اسأل عن «" + (topics.firstOrNull { it.id == chosen }?.label ?: "") + "»",
                        onClick = { onAsk(chosen) },
                        modifier = Modifier.fillMaxWidth().widthIn(min = s(60)),
                        enabled = block == null,
                        size = 10.5f,
                        height = 28,
                    )
                    if (block != null) ArText(block, 9, Color(0xFFE8A598), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
                }
            }
        }
    }
}
