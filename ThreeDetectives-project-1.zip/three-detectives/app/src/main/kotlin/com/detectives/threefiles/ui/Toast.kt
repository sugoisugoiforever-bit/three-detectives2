package com.detectives.threefiles.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.detectives.threefiles.audio.Sfx
import game.Notice
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import java.util.concurrent.atomic.AtomicInteger

/** طابور رسائل عابرة: تُعرض واحدة تلو الأخرى، وإن تراكمت قصّرنا مدّة العرض. */
class Toaster {
    private val ch = Channel<String>(8, BufferOverflow.DROP_OLDEST)
    private val pending = AtomicInteger(0)
    var text by mutableStateOf("")
        private set
    var visible by mutableStateOf(false)
        private set

    fun show(msg: String) {
        if (msg.isBlank()) return
        pending.incrementAndGet()
        ch.trySend(msg)
    }

    suspend fun run() {
        for (m in ch) {
            val backlog = pending.decrementAndGet()
            text = m
            visible = true
            delay(if (backlog > 0) 1500L else 2500L)
            visible = false
            delay(220L)
        }
    }
}

const val SND_NONE = 0
const val SND_PAGE = 1
const val SND_REQUEST = 2
const val SND_COIN = 3
const val SND_BELL = 4

fun playCue(sound: Int) {
    when (sound) {
        SND_PAGE -> Sfx.page()
        SND_REQUEST -> Sfx.request()
        SND_COIN -> Sfx.coin()
        SND_BELL -> Sfx.bell()
    }
}

class Cue(val text: String, val sound: Int, val rank: Int)

/** يحوّل المستجدات الجديدة إلى رسالة أو رسالتين مهمتين فقط (الأعلى أهمية أولاً). */
fun cuesFor(fresh: List<Notice>, me: Int): List<Cue> {
    val out = ArrayList<Cue>()
    val docs = fresh.filter { it.kind == "doc" }
    if (docs.size >= 2) out.add(Cue("وصلتك " + docs.size + " وثائق جديدة", SND_PAGE, 2))
    else if (docs.size == 1) out.add(Cue(docs[0].text, SND_PAGE, 2))
    for (n in fresh) {
        val mine = n.from == me
        when (n.kind) {
            "request" ->
                if (mine) out.add(Cue("أُرسل سؤالك إلى زميليك", SND_NONE, 3))
                else out.add(Cue(n.text, SND_REQUEST, 6))
            "share" -> out.add(Cue(n.text, if (mine) SND_COIN else SND_PAGE, if (mine) 3 else 5))
            "intercept" -> out.add(Cue(n.text, SND_PAGE, 5))
            "template" -> out.add(Cue(n.text, if (mine) SND_NONE else SND_PAGE, if (mine) 3 else 5))
            "ability" -> out.add(Cue(n.text, SND_BELL, if (mine) 7 else 4))
            "accuse" -> out.add(Cue(n.text, SND_BELL, 4))
        }
    }
    return out.sortedByDescending { it.rank }.take(2)
}
