package com.detectives.threefiles.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.detectives.threefiles.R
import game.Person

class Stats(val played: Int, val wins: Int, val stars: Int, val perfect: Int)

/** إطار شاشة ثانوية: عنوان وزر رجوع فوق لوح جلدي يحمل المحتوى. */
@Composable
fun Frame(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    backText: String = "رجوع",
    content: @Composable ColumnScope.() -> Unit,
) {
    val s = LocalS.current
    Column(modifier.fillMaxSize().padding(horizontal = s(16), vertical = s(10)), verticalArrangement = Arrangement.spacedBy(s(8))) {
        Row(Modifier.fillMaxWidth().height(s(32)), horizontalArrangement = Arrangement.spacedBy(s(12), Alignment.End), verticalAlignment = Alignment.CenterVertically) {
            ArText(title, 20, Brass, FontWeight.Bold, TextAlign.Right, font = Serif, shadow = true)
            BrassButton(backText, onBack, Modifier.width(s(90)), size = 11, height = 28)
        }
        LeatherPanel(Modifier.weight(1f).fillMaxWidth()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s(14)),
                verticalArrangement = Arrangement.spacedBy(s(9)),
                content = content,
            )
        }
    }
}

private val FakePeople = listOf(
    Person("a", "فادي الحداد", "فادي", "m", "محاسب", 1),
    Person("b", "هبة النجار", "هبة", "f", "أمينة المعرض", 5),
    Person("c", "طارق السيد", "طارق", "m", "حارس ليلي", 9),
)

/** ملف قضية على المكتب بصور مثبّتة وختم شمع: غلاف القائمة الرئيسية. */
@Composable
fun CaseFileArt(modifier: Modifier = Modifier) {
    val s = LocalS.current
    Box(modifier) {
        Box(Modifier.align(Alignment.Center).size(s(224), s(306)).rotate(-3f)) {
            Box(Modifier.matchParentSize().shadow(s(9), RoundedCornerShape(s(2))))
            Pic(R.drawable.paper_cream, Modifier.matchParentSize())
            Column(
                Modifier.matchParentSize().padding(horizontal = s(20), vertical = s(24)),
                verticalArrangement = Arrangement.spacedBy(s(5)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                StampBox("سرّي للغاية")
                Box(Modifier.height(s(8)))
                ArText("ثلاثة محققين", 25, Ink, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
                Box(Modifier.fillMaxWidth().height(s(1.4f)).background(Color(0x882A1E15)))
                ArText("ملف واحد", 27, Color(0xFF8E1A12), FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
                Box(Modifier.height(s(6)))
                ArText("لعبة استنتاج تعاونية لثلاثة لاعبين", 10, InkSoft, FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
                repeat(4) { Box(Modifier.padding(top = s(7)).fillMaxWidth().height(s(1)).background(Color(0x442A1E15))) }
            }
            Pic(R.drawable.paperclip, Modifier.align(Alignment.TopCenter).offset(s(48), s(-14)).size(s(17), s(39)))
        }
        Polaroid(FakePeople[0], 0, MARK_NONE, s(70), { }, Modifier.align(Alignment.Center).offset(s(124), s(-86)))
        Polaroid(FakePeople[1], 1, MARK_SUSPECT, s(70), { }, Modifier.align(Alignment.Center).offset(s(134), s(52)))
        Polaroid(FakePeople[2], 2, MARK_NONE, s(70), { }, Modifier.align(Alignment.Center).offset(s(-130), s(-26)))
        Pic(R.drawable.seal_ready, Modifier.align(Alignment.Center).offset(s(-84), s(124)).size(s(62)))
    }
}

@Composable
fun StatPill(label: String, value: Int) {
    val s = LocalS.current
    Row(
        Modifier.background(Color(0x66000000), RoundedCornerShape(s(7))).padding(horizontal = s(9), vertical = s(4)),
        horizontalArrangement = Arrangement.spacedBy(s(5)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ArText(value.toString(), 12, Brass, FontWeight.Bold, TextAlign.Center)
        ArText(label, 8.6f, Color(0xCCEBD9A8), FontWeight.Normal, TextAlign.Right)
    }
}

@Composable
fun MenuScreen(stats: Stats, onSolo: () -> Unit, onOnline: () -> Unit, onHelp: () -> Unit, onSettings: () -> Unit) {
    val s = LocalS.current
    Row(Modifier.fillMaxSize().padding(horizontal = s(18), vertical = s(10)), horizontalArrangement = Arrangement.spacedBy(s(10))) {
        CaseFileArt(Modifier.weight(1f).fillMaxHeight())
        Column(
            Modifier.width(s(250)).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(s(11), Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ArText("افتحوا الملف", 22, Brass, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif, shadow = true)
            WaxButton("العب منفرداً", onSolo, Modifier.fillMaxWidth(), size = 14, height = 42)
            ArText("معك محققان آليان يشاركانك الملف", 9, Color(0xB3EBD9A8), FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth())
            BrassButton("العب مع أصدقائك", onOnline, Modifier.fillMaxWidth(), size = 13, height = 40, icon = R.drawable.icon_people)
            BrassButton("كيف تُلعب؟", onHelp, Modifier.fillMaxWidth(), size = 12, height = 34, icon = R.drawable.icon_notes)
            BrassButton("الإعدادات", onSettings, Modifier.fillMaxWidth(), size = 12, height = 34)
            if (stats.played > 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(s(5))) {
                    StatPill("نجوم", stats.stars)
                    StatPill("فوز", stats.wins)
                    StatPill("قضايا", stats.played)
                }
            }
        }
    }
}

// ───────────── الشرح المصوّر ─────────────

private class Page(val icon: Int, val title: String, val body: String)

private val PAGES = listOf(
    Page(R.drawable.icon_people, "ثلاثة محققين، ملف واحد", "أنتم ثلاثة محققين في قضية واحدة، ولكل منكم وثائق لا يراها زميلاه. الحل موزَّع بينكم: من الفاعل؟ كيف نُفِّذت الجريمة؟ ولماذا؟ ولا توجد محادثة حرّة، فكل تواصل عبر أدوات اللعبة."),
    Page(R.drawable.icon_notes, "المكتب والوثائق", "اضغط أي وثيقة على المكتب لتقرأها. الكلمات المظلَّلة بالأصفر مواضيع (أشخاص، أماكن، أوقات، أرقام) يمكنك أن تسأل زملاءك عنها. تصلك وثائق جديدة في كل جولة."),
    Page(R.drawable.icon_send, "حركة واحدة في الجولة", "«اسأل» مجاني: يخبر زميليك بما تبحث عنه. «أرسل» ينسخ إحدى وثائقك إلى زميل مقابل قطعة نحاسية. «قل» يرسل رسالة جاهزة مثل «أشك في فلان» مقابل قطعة. القطع ميزانية مشتركة محدودة، فاختاروا بحكمة."),
    Page(R.drawable.icon_raid, "اللوحة والقدرات", "على لوحة الفلين صور المشتبهين السبعة؛ اضغط صورة لتعلّمها «مشتبه» أو «مستبعد» (علاماتك خاصة بك). ولكل دور قدرة تُستعمل مرة واحدة: تدقيق وثيقة، أو مداهمة تجلب وثيقة مبكراً، أو اعتراض يكشف ما يتبادله زميلاك."),
    Page(R.drawable.icon_accuse, "الاتهام والنجوم", "بعد الجولة الرابعة تُفتح نافذة الاتهام: اختاروا إجابة لكل سؤال، واستشهدوا بوثيقتين من صاحبين مختلفين، ويوافق الثلاثة. ثلاث نجوم لمن أصاب الأسئلة الثلاثة بأدلة حاسمة من نافذة الاتهام الأولى."),
)

@Composable
fun TutorialScreen(onDone: () -> Unit, startPage: Int = 0) {
    val s = LocalS.current
    var page by remember { mutableStateOf(startPage) }
    val p = PAGES[page]
    Box(Modifier.fillMaxSize().padding(horizontal = s(40), vertical = s(18)), contentAlignment = Alignment.Center) {
        LeatherPanel(Modifier.fillMaxWidth().fillMaxHeight()) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = s(26), vertical = s(16)),
                verticalArrangement = Arrangement.spacedBy(s(9)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(s(10), Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Pic(p.icon, Modifier.size(s(62)), tint = Brass)
                    ArText(p.title, 21, Brass, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
                    ArText(p.body, 13, Cream, FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(s(6))) {
                    for (i in PAGES.indices.reversed()) {
                        Box(Modifier.size(s(8)).background(if (i == page) Brass else Color(0x55EBD9A8), androidx.compose.foundation.shape.CircleShape))
                    }
                }
                // الاتجاه عربي: «التالي» يسار، و«السابق» و«تخطّي» يمين
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    if (page < PAGES.size - 1) {
                        WaxButton("التالي", { page += 1 }, Modifier.width(s(120)), size = 12.5f, height = 34)
                    } else {
                        WaxButton("ابدأ التحقيق", onDone, Modifier.width(s(140)), size = 12.5f, height = 34)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(s(8))) {
                        if (page < PAGES.size - 1) BrassButton("تخطّي", onDone, Modifier.width(s(90)), size = 11, height = 30)
                        if (page > 0) BrassButton("السابق", { page -= 1 }, Modifier.width(s(100)), size = 11.5f, height = 32)
                    }
                }
            }
        }
    }
}

// ───────────── الإعدادات ─────────────

@Composable
fun SettingsScreen(
    name: String,
    sound: Boolean,
    server: String,
    onName: (String) -> Unit,
    onSound: (Boolean) -> Unit,
    onServer: (String) -> Unit,
    onTutorial: () -> Unit,
    onBack: () -> Unit,
) {
    val s = LocalS.current
    Frame("الإعدادات", onBack) {
        ArText("اسمك في اللعبة", 10.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
        Field(name, onName, "اكتب اسمك", Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Toggle(sound, onSound)
            ArText("المؤثرات الصوتية", 11.5f, Cream, FontWeight.Bold, TextAlign.Right)
        }
        ArText("عنوان خادم اللعب الجماعي", 10.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
        Field(server, onServer, "https://your-server.workers.dev", Modifier.fillMaxWidth(), ltr = true, keyboard = androidx.compose.ui.text.input.KeyboardType.Uri, size = 11)
        ArText("يُنشأ الخادم بنشر مجلد server على Cloudflare Workers (راجع ملف README). اللعب المنفرد لا يحتاجه.", 9, Color(0xB3EBD9A8), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
        Box(Modifier.height(s(2)))
        BrassButton("أعِد عرض الشرح", onTutorial, Modifier.fillMaxWidth(), size = 11.5f, height = 32)
        ArText("ثلاثة محققين، ملف واحد • الإصدار 1.0.0", 8.6f, Color(0x99EBD9A8), FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth())
    }
}
