package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import com.detectives.threefiles.R
import game.ABILITY_AR
import game.ROLE_AR

private val DIFF_NOTE = listOf(
    "8 قطع نحاسية، وزميلاك الآليان بارعان في اختيار الوثائق.",
    "7 قطع نحاسية، وزميلاك الآليان بمستوى جيد.",
    "6 قطع نحاسية، وزميلاك الآليان يخطئان أحياناً كالبشر.",
)

val THEME_ITEMS: List<Pair<String, String>> = THEME_AR.map { it.key to it.value }

// ───────────── بطاقة الدور ─────────────

/** بطاقة ورقية قديمة تعرض الدور واسم قدرته؛ المختارة تحمل ختماً وحافة حمراء. */
@Composable
fun RoleCard(seat: Int, selected: Boolean, onClick: () -> Unit, w: Dp, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val h = w * (412f / 312f)
    val shape = RoundedCornerShape(s(5))
    Press(onClick, modifier.size(w, h).alpha(if (selected) 1f else 0.8f)) {
        Pic(R.drawable.card_vintage, Modifier.matchParentSize())
        if (selected) {
            Box(Modifier.matchParentSize().padding(horizontal = w * 0.095f, vertical = h * 0.07f).border(s(2), Wax, shape))
        }
        Column(
            Modifier.matchParentSize().padding(horizontal = w * 0.14f, vertical = h * 0.12f),
            verticalArrangement = Arrangement.spacedBy(s(4), Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Pic(Pics.ability(seat), Modifier.size(w * 0.36f))
            ArText(ROLE_AR[seat], 11.5f, Ink, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
            ArText("قدرته: " + ABILITY_AR[seat], 9, Color(0xFF8E1A12), FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
        }
        if (selected) {
            Pic(R.drawable.seal_ready, Modifier.align(Alignment.TopStart).padding(start = w * 0.03f, top = h * 0.015f).size(s(28)))
        }
    }
}

/** شرح الدور المختار والقدرة الخاصة به بخط مقروء. */
@Composable
fun RoleInfo(seat: Int, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(7))
    Column(
        modifier.fillMaxWidth().background(Color(0x55000000), shape).border(s(1), BrassDark.copy(alpha = 0.5f), shape).padding(s(9)),
        verticalArrangement = Arrangement.spacedBy(s(3)),
    ) {
        ArText(ROLE_AR[seat], 11.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
        ArText(ROLE_DESC[seat], 9.4f, Cream, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
        ArText("قدرته الخاصة: " + ABILITY_AR[seat] + " (مرة واحدة)", 9.6f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
        ArText(ABILITY_DESC[seat], 9.2f, Cream, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
    }
}

/** ثلاث بطاقات أدوار في صف، الأول عند اليمين. */
@Composable
fun RoleRow(role: Int, onRole: (Int) -> Unit, w: Dp) {
    val s = LocalS.current
    Row(horizontalArrangement = Arrangement.spacedBy(s(7))) {
        for (i in 2 downTo 0) RoleCard(i, role == i, { onRole(i) }, w)
    }
}

// ───────────── إعداد اللعب المنفرد ─────────────

@Composable
fun SoloSetupScreen(
    name: String,
    role: Int,
    theme: String,
    difficulty: Int,
    onName: (String) -> Unit,
    onRole: (Int) -> Unit,
    onTheme: (String) -> Unit,
    onDifficulty: (Int) -> Unit,
    onStart: () -> Unit,
    onBack: () -> Unit,
) {
    val s = LocalS.current
    Frame("تحقيق جديد", onBack) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val wide = maxWidth >= s(480)
            val rolesW: Dp = if (wide) minOf(s(386), maxWidth * 0.52f) else maxWidth
            val cardW: Dp = ((rolesW - s(14)) / 3).coerceIn(s(80), s(110))
            val perRow = if (maxWidth - (cardW * 3 + s(14)) - s(18) >= s(300) || !wide) 4 else 2
            val settings: @Composable (Modifier) -> Unit = { m ->
                Column(m, verticalArrangement = Arrangement.spacedBy(s(6))) {
                    SectionLabel("اسمك")
                    Field(name, onName, "اكتب اسمك", Modifier.fillMaxWidth())
                    SectionLabel("الصعوبة")
                    ChipRows(DIFF_AR.mapIndexed { i, t -> i.toString() to t }, difficulty.toString(), 3, { onDifficulty(it.toInt()) }, 11)
                    Note(DIFF_NOTE[difficulty.coerceIn(0, 2)])
                    SectionLabel("القضية")
                    ChipRows(THEME_ITEMS, theme, perRow, onTheme, 10.5f)
                    Box(Modifier.size(s(2)))
                    WaxButton("ابدأ التحقيق", onStart, Modifier.fillMaxWidth(), size = 14, height = 40)
                }
            }
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(18), Alignment.End)) {
                    settings(Modifier.weight(1f))
                    Column(Modifier.width(cardW * 3 + s(14)), verticalArrangement = Arrangement.spacedBy(s(6)), horizontalAlignment = Alignment.End) {
                        SectionLabel("اختر دورك")
                        RoleRow(role, onRole, cardW)
                        RoleInfo(role)
                    }
                }
            } else {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(s(8))) {
                    SectionLabel("اختر دورك")
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { RoleRow(role, onRole, cardW) }
                    RoleInfo(role)
                    settings(Modifier.fillMaxWidth())
                }
            }
        }
    }
}

// ───────────── اللعب مع الأصدقاء ─────────────

@Composable
fun OnlineSetupScreen(
    name: String,
    server: String,
    code: String,
    busy: Boolean,
    error: String?,
    onName: (String) -> Unit,
    onServer: (String) -> Unit,
    onCode: (String) -> Unit,
    onCreate: () -> Unit,
    onJoin: () -> Unit,
    onBack: () -> Unit,
) {
    val s = LocalS.current
    Frame("اللعب مع الأصدقاء", onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(12), Alignment.End)) {
            Column(Modifier.weight(1.5f), verticalArrangement = Arrangement.spacedBy(s(4))) {
                SectionLabel("عنوان الخادم")
                Field(server, onServer, "https://your-server.workers.dev", Modifier.fillMaxWidth(), ltr = true, size = 11, enabled = !busy)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(4))) {
                SectionLabel("اسمك")
                Field(name, onName, "اكتب اسمك", Modifier.fillMaxWidth(), enabled = !busy)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(12), Alignment.End)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(6))) {
                SectionLabel("غرفة جديدة")
                Note("أنشئ غرفة ثم شاركها رمزها مع صديقيك. المقاعد الفارغة يشغلها محققون آليون.")
                WaxButton("أنشئ غرفة", onCreate, Modifier.fillMaxWidth(), enabled = !busy, size = 13, height = 38)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(6))) {
                SectionLabel("لديّ رمز غرفة")
                Note("اكتب الرمز المكوّن من خمسة أحرف الذي أرسله لك صديقك.")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(6), Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    BrassButton("انضم", onJoin, Modifier.width(s(84)), enabled = !busy && code.length == 5, size = 12.5f, height = 38)
                    Field(code, onCode, "XXXXX", Modifier.weight(1f), ltr = true, caps = KeyboardCapitalization.Characters, size = 15, height = 38, enabled = !busy)
                }
            }
        }
        if (busy) Note("جارٍ الاتصال بالخادم…")
        if (error != null) Note(error, warn = true)
    }
}
