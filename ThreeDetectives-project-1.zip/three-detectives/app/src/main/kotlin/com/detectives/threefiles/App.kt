package com.detectives.threefiles

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.detectives.threefiles.audio.Sfx
import com.detectives.threefiles.data.Prefs
import com.detectives.threefiles.session.GameSession
import com.detectives.threefiles.session.Net
import com.detectives.threefiles.session.OnlineSession
import com.detectives.threefiles.session.SoloSession
import com.detectives.threefiles.ui.Stats
import com.detectives.threefiles.ui.Toaster
import com.detectives.threefiles.ui.UiState
import game.CaseLibrary
import game.Config
import game.Game
import game.ROLE_AR
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

sealed class Screen {
    object Menu : Screen()
    object SoloSetup : Screen()
    object OnlineSetup : Screen()
    object Settings : Screen()
    object Tutorial : Screen()

    /** جلسة نشطة: فردية، أو جماعية (ردهة ثم لعب). */
    object Play : Screen()
}

/** حالة التطبيق كله: الشاشة الحالية، الإعدادات، والجلسة النشطة. يعيش مع العملية لا مع النشاط. */
class AppModel private constructor(ctx: Context) {
    private val app = ctx.applicationContext
    val prefs = Prefs(app)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val library: CaseLibrary by lazy {
        app.assets.open("cases.jsonl").bufferedReader(Charsets.UTF_8).use { r ->
            CaseLibrary(r.readLines().filter { it.isNotBlank() })
        }
    }

    var screen by mutableStateOf<Screen>(if (prefs.tutorialSeen) Screen.Menu else Screen.Tutorial)
        private set
    var session by mutableStateOf<GameSession?>(null)
        private set
    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var name by mutableStateOf(prefs.name)
        private set
    var server by mutableStateOf(prefs.serverUrl)
        private set
    var sound by mutableStateOf(prefs.sound)
        private set
    var role by mutableStateOf(prefs.role.coerceIn(0, 2))
        private set
    var theme by mutableStateOf(prefs.theme)
        private set
    var difficulty by mutableStateOf(prefs.difficulty.coerceIn(0, 2))
        private set
    var code by mutableStateOf("")
        private set
    var stats by mutableStateOf(readStats())
        private set

    var ui by mutableStateOf(UiState())
        private set
    var toaster by mutableStateOf(Toaster())
        private set
    var menuOpen by mutableStateOf(false)
        private set

    private var recorded = false
    private var activityPaused = false

    init {
        Sfx.enabled = sound
    }

    private fun readStats() = Stats(prefs.played, prefs.wins, prefs.stars, prefs.perfect)

    // ───────── التنقل ─────────

    fun go(to: Screen) {
        error = null
        screen = to
    }

    fun back() {
        when (screen) {
            Screen.Menu, Screen.Play -> {}
            else -> go(Screen.Menu)
        }
    }

    fun finishTutorial() {
        prefs.tutorialSeen = true
        go(Screen.Menu)
    }

    // ───────── الإعدادات ─────────

    fun updateName(v: String) { name = v.take(18); prefs.name = name }
    fun updateServer(v: String) { server = v.trim(); prefs.serverUrl = server }
    fun updateSound(on: Boolean) { sound = on; prefs.sound = on; Sfx.enabled = on }
    fun updateRole(v: Int) { role = v; prefs.role = v }
    fun updateTheme(v: String) { theme = v; prefs.theme = v }
    fun updateDifficulty(v: Int) { difficulty = v; prefs.difficulty = v }
    fun updateCode(v: String) { code = Net.cleanCode(v); error = null }

    // ───────── الجلسات ─────────

    private fun attach(s: GameSession) {
        session?.close()
        ui = UiState()
        toaster = Toaster()
        recorded = false
        menuOpen = false
        session = s
        screen = Screen.Play
        syncPause()
    }

    fun startSolo() {
        val seat = role
        val seed = System.nanoTime() xor (System.currentTimeMillis() shl 13)
        val c = library.pick(theme.ifEmpty { null }, seed and Long.MAX_VALUE)
        val cfg = when (difficulty) {
            0 -> Config.easy()
            2 -> Config.hard()
            else -> Config.normal()
        }
        val g = Game(c, cfg, (seed ushr 7).toInt(), 0L, setOf(seat))
        g.setSeat(seat, name.trim().ifEmpty { ROLE_AR[seat] }, false)
        attach(SoloSession(g, seat))
    }

    fun createRoom() {
        val base = Net.httpBase(server)
        if (busy) return
        if (base == null) { error = "اكتب عنوان خادم اللعب أولاً"; return }
        busy = true
        error = null
        scope.launch {
            val r = Net.createRoom(base)
            busy = false
            val c = r.getOrNull()
            if (c != null) openRoom(base, c) else error = r.exceptionOrNull()?.message ?: "تعذّر إنشاء الغرفة"
        }
    }

    fun joinRoom() {
        val base = Net.httpBase(server)
        if (busy) return
        if (base == null) { error = "اكتب عنوان خادم اللعب أولاً"; return }
        if (code.length != Net.CODE_LEN) { error = "رمز الغرفة مكوّن من 5 أحرف"; return }
        openRoom(base, code)
    }

    private fun openRoom(base: String, room: String) {
        error = null
        attach(OnlineSession(base, room, prefs.playerId, name.trim().ifEmpty { "محقق" }))
    }

    fun leave() {
        session?.close()
        session = null
        menuOpen = false
        busy = false
        screen = Screen.Menu
    }

    /** فشل الدخول إلى غرفة (رمز خاطئ، غرفة ممتلئة…): نعود إلى شاشة الانضمام مع السبب. */
    fun abort(msg: String) {
        session?.close()
        session = null
        menuOpen = false
        error = msg
        screen = Screen.OnlineSetup
    }

    fun again() {
        val s = session ?: return
        if (s.online) {
            ui = UiState()
            recorded = false
            s.again()
        } else {
            startSolo()
        }
    }

    fun recordResult(stars: Int) {
        if (recorded) return
        recorded = true
        prefs.record(stars)
        stats = readStats()
    }

    // ───────── الإيقاف المؤقت ─────────

    fun setMenu(open: Boolean) {
        menuOpen = open
        syncPause()
    }

    fun onActivityPause(paused: Boolean) {
        activityPaused = paused
        syncPause()
    }

    private fun syncPause() {
        val s = session ?: return
        s.pause(activityPaused || (menuOpen && !s.online))
    }

    companion object {
        @Volatile
        private var inst: AppModel? = null

        fun get(ctx: Context): AppModel =
            inst ?: synchronized(this) { inst ?: AppModel(ctx.applicationContext).also { inst = it } }
    }
}
