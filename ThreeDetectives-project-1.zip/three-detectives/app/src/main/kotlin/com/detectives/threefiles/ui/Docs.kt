package com.detectives.threefiles.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import game.Line
import game.PDoc
import game.ROLE_AR

val StampRed = Color(0xCCB3261E)
private val Rule = Color(0x552A1E15)

/** يلوّن في النص كل ذِكر لموضوع يمكن السؤال عنه (اسم، مكان، وقت، رمز). */
fun markUp(text: String, labels: List<String>): AnnotatedString {
    if (labels.isEmpty() || text.isEmpty()) return AnnotatedString(text)
    val hit = BooleanArray(text.length)
    for (l in labels) {
        if (l.isEmpty()) continue
        var i = text.indexOf(l)
        while (i >= 0) {
            for (k in i until i + l.length) hit[k] = true
            i = text.indexOf(l, i + l.length)
        }
    }
    return buildAnnotatedString {
        var k = 0
        while (k < text.length) {
            var e = k
            while (e < text.length && hit[e] == hit[k]) e++
            val part = text.substring(k, e)
            if (hit[k]) {
                withStyle(SpanStyle(background = Mark, fontWeight = FontWeight.Bold)) { append(part) }
            } else {
                append(part)
            }
            k = e
        }
    }
}

@Composable
fun StampBox(text: String) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(3))
    Box(Modifier.rotate(-8f).border(s(1.4f), StampRed, shape).padding(horizontal = s(6), vertical = s(2))) {
        ArText(text, 9.5f, StampRed, FontWeight.Bold, TextAlign.Center)
    }
}

/** ورقة وثيقة كاملة المحتوى. الأحجام مضبوطة لعرض ≈ 230 وحدة. */
@Composable
fun DocPaper(doc: PDoc, labels: List<String>, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val scroll = rememberScrollState()
    Box(modifier.shadow(s(6), RoundedCornerShape(s(2)))) {
        Pic(Pics.paper(doc.kind), Modifier.matchParentSize())
        Column(
            Modifier
                .matchParentSize()
                .verticalScroll(scroll)
                .padding(start = s(17), end = s(17), top = s(14), bottom = s(14)),
            verticalArrangement = Arrangement.spacedBy(s(5)),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                StampBox(doc.stamp)
                ArText("رقم ${doc.serial}", 8.5f, InkSoft)
            }
            ArText(doc.title, 13, Ink, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
            Box(Modifier.fillMaxWidth().height(s(1)).background(Rule))
            DocLines(doc.lines, labels)
        }
    }
}

@Composable
private fun DocLines(lines: List<Line>, labels: List<String>) {
    val s = LocalS.current
    var i = 0
    val speakers = ArrayList<String>()
    for (l in lines) {
        val w = l.who
        if (l.t == "msg" && w != null && w !in speakers) speakers.add(w)
    }
    while (i < lines.size) {
        val ln = lines[i]
        when (ln.t) {
            "kv" -> {
                val text = buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = InkSoft)) { append((ln.k ?: "") + ": ") }
                    append(markUp(ln.v ?: "", labels))
                }
                ArRich(text, 10.5f, Ink, modifier = Modifier.fillMaxWidth(), font = Serif)
                i++
            }
            "p" -> {
                ArRich(markUp(ln.v ?: "", labels), 10.5f, Ink, modifier = Modifier.fillMaxWidth(), font = Serif)
                i++
            }
            "hrow", "row" -> {
                var j = i
                while (j < lines.size && (lines[j].t == "hrow" || lines[j].t == "row")) j++
                Table(lines.subList(i, j), labels)
                i = j
            }
            "msg" -> {
                val right = speakers.indexOf(ln.who ?: "") % 2 == 0
                Bubble(ln, right, labels)
                i++
            }
            else -> i++
        }
    }
    Box(Modifier.height(s(2)))
}

/** الأرقام والتواريخ تُحاط بعلامة اتجاه (LRM) كي تبقى إشارة الطرح يسار الرقم وسط نص عربي. */
private val NumCell = Regex("^[-+\\u2212]\\d[\\d.,]*$")

private fun fixNum(cell: String): String = if (NumCell.matches(cell)) "\u200E" + cell else cell

@Composable
private fun Table(rows: List<Line>, labels: List<String>) {
    val s = LocalS.current
    val cols = rows.maxOf { it.c?.size ?: 0 }
    if (cols == 0) return
    val maxLen = IntArray(cols) { c -> rows.maxOf { r -> (r.c?.getOrNull(c)?.length ?: 0) } }
    Column(Modifier.fillMaxWidth().border(s(0.8f), Rule)) {
        for ((ri, r) in rows.withIndex()) {
            val head = r.t == "hrow"
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(if (head) Color(0x222A1E15) else if (ri % 2 == 0) Color(0x0F2A1E15) else Color(0x00000000))
                    .padding(horizontal = s(3), vertical = s(2.5f)),
                horizontalArrangement = Arrangement.spacedBy(s(4)),
            ) {
                // العمود الأول عند اليمين في القراءة العربية
                for (c in (0 until cols).reversed()) {
                    val cell = r.c?.getOrNull(c) ?: ""
                    // الأعمدة القصيرة (أوقات، مبالغ، تواريخ) بعرض ثابت كي لا تنكسر، والطويلة تتقاسم الباقي
                    val colMod = if (maxLen[c] <= 10) {
                        Modifier.width(s(maxOf(maxLen[c], 4) * 5.7f + 2f))
                    } else {
                        Modifier.weight(maxLen[c].coerceIn(10, 40).toFloat())
                    }
                    Box(colMod) {
                        ArRich(
                            if (head) AnnotatedString(cell) else markUp(fixNum(cell), labels),
                            9.2f, Ink, if (head) FontWeight.Bold else FontWeight.Normal,
                            align = TextAlign.Right, modifier = Modifier.fillMaxWidth(), font = Serif,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Bubble(ln: Line, right: Boolean, labels: List<String>) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(7))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (right) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier
                .fillMaxWidth(0.86f)
                .clip(shape)
                .background(if (right) Color(0xFFD9E7C9) else Color(0xFFE7DFC9))
                .border(s(0.8f), Rule, shape)
                .padding(horizontal = s(6), vertical = s(4)),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ArText(ln.time ?: "", 8f, InkSoft)
                ArText(ln.who ?: "", 8.8f, Ink, FontWeight.Bold)
            }
            ArRich(markUp(ln.v ?: "", labels), 10f, Ink, modifier = Modifier.fillMaxWidth(), font = Serif)
        }
    }
}

/** بطاقة مصغّرة للوثيقة على المكتب. */
@Composable
fun DocThumb(
    doc: PDoc,
    w: Dp,
    isNew: Boolean,
    hot: Boolean,
    me: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalS.current
    val h = w * 1.34f
    val rot = ((doc.id.hashCode() and 7) - 3.5f) * 0.9f
    val src = remember { MutableInteractionSource() }
    Box(
        modifier
            .size(w, h)
            .rotate(rot)
            .clickable(interactionSource = src, indication = null) { onClick() },
    ) {
        Box(Modifier.matchParentSize().shadow(s(5), RoundedCornerShape(s(1.5f))))
        Pic(Pics.paper(doc.kind), Modifier.matchParentSize())
        Box(Modifier.fillMaxWidth().height(s(4)).background(Pics.kindColor(doc.kind).copy(alpha = 0.85f)))
        Column(Modifier.matchParentSize().padding(start = s(5), end = s(5), top = s(9), bottom = s(4))) {
            ArText(doc.title, 9.2f, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 3, font = Serif)
            Box(Modifier.height(s(3)))
            repeat(3) {
                Box(Modifier.padding(vertical = s(2.2f)).fillMaxWidth().height(s(1)).background(Rule))
            }
            Box(Modifier.align(Alignment.End).padding(vertical = s(2.2f)).fillMaxWidth(0.55f).height(s(1)).background(Rule))
            Box(Modifier.weight(1f))
            if (doc.from >= 0) {
                ArText("من: " + ROLE_AR[doc.from], 7.6f, InkSoft, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
            } else {
                ArText("وثيقتك", 7.6f, InkSoft, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
            }
        }
        // دبوس تصنيف المدقّق
        if (doc.audit != null) {
            val good = doc.audit == "decisive"
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(s(-3), s(-3))
                    .size(s(15))
                    .background(if (good) Good else Color(0xFF6B6B6B), CircleShape)
                    .border(s(1), Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                ArText(if (good) "✓" else "×", 10, Color.White, FontWeight.Bold, TextAlign.Center)
            }
        }
        if (isNew) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(s(4), s(-3))
                    .rotate(8f)
                    .background(Wax, RoundedCornerShape(s(3)))
                    .padding(horizontal = s(4), vertical = s(1)),
            ) {
                ArText("جديد", 8, Cream, FontWeight.Bold, TextAlign.Center)
            }
        }
        if (hot) HotGlow()
    }
}

/** إطار أصفر نابض يلفت النظر إلى وثيقة طلبها زميل. */
@Composable
private fun BoxScope.HotGlow() {
    val s = LocalS.current
    val pulse by rememberInfiniteTransition(label = "hot").animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(650), repeatMode = RepeatMode.Reverse),
        label = "hotA",
    )
    Box(
        Modifier
            .matchParentSize()
            .graphicsLayer { alpha = pulse }
            .border(s(2.2f), Color(0xFFFFC53D), RoundedCornerShape(s(2))),
    )
    Box(
        Modifier
            .align(Alignment.BottomStart)
            .offset(s(-2), s(3))
            .background(Color(0xFFFFC53D), RoundedCornerShape(s(3)))
            .padding(horizontal = s(4), vertical = s(1)),
    ) {
        ArText("مطلوبة", 8, Ink, FontWeight.Bold, TextAlign.Center)
    }
}
