package com.detectives.threefiles.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.detectives.threefiles.R
import game.PView

// ───────────── اللوحة النحاسية العلوية ─────────────

/** القطع النحاسية (يسار)، المؤقت (وسط)، ورقم الجولة (يمين) داخل المنطقة المرئية من اللوحة. */
@Composable
fun Plaque(label: String, left: Long, credits: Int, creditsMax: Int, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val danger = left in 1..10_000
    val warn = left in 10_001..30_000
    val timerColor = if (danger) Color(0xFFFF6B5A) else if (warn) Color(0xFFFFC96B) else Cream
    Box(modifier.size(s(262), s(59))) {
        Pic(R.drawable.plaque, Modifier.matchParentSize())
        Box(Modifier.align(Alignment.Center).size(s(232), s(34))) {
            Coins(credits, creditsMax, 8.5f, Modifier.align(Alignment.CenterStart))
            ArText(clock(left), 22, timerColor, FontWeight.Bold, TextAlign.Center, Modifier.align(Alignment.Center), shadow = true)
            ArText(label, 10, Brass, FontWeight.Bold, TextAlign.Right, Modifier.align(Alignment.CenterEnd), maxLines = 2)
        }
    }
}

/** زر نحاسي دائري صغير للقائمة والمساعدة. */
@Composable
fun RoundBtn(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val s = LocalS.current
    Press(onClick, modifier.size(s(28))) {
        BrassFace(Modifier.matchParentSize(), 14)
        Box(Modifier.align(Alignment.Center), content = content)
    }
}

@Composable
fun MenuGlyph() {
    val s = LocalS.current
    Column(verticalArrangement = Arrangement.spacedBy(s(2.6f))) {
        repeat(3) { Box(Modifier.size(s(13), s(2)).background(Ink, RoundedCornerShape(s(1)))) }
    }
}

/** الشريط العلوي: أزرار القائمة والمساعدة، اللوحة النحاسية، ولافتة القضية. */
@Composable
fun TopBar(
    v: PView,
    label: String,
    left: Long,
    onMenu: () -> Unit,
    onHelp: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalS.current
    Row(modifier.fillMaxWidth().height(s(58)), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(s(8))) {
            RoundBtn(onMenu) { MenuGlyph() }
            RoundBtn(onHelp) { ArText("؟", 15, Ink, FontWeight.Bold, TextAlign.Center) }
        }
        Plaque(label, left, v.credits, v.creditsMax)
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
            CaseTitle(v.info.title, v.info.org)
        }
    }
}

@Composable
fun CaseTitle(title: String, org: String) {
    val s = LocalS.current
    BrassPlate(Modifier.widthIn(max = s(178))) {
        Column(Modifier.padding(horizontal = s(9), vertical = s(5))) {
            ArText("ملف القضية", 7.8f, InkSoft, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
            ArText(title, 9.6f, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2)
            ArText(org, 7.8f, InkSoft, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
        }
    }
}

// ───────────── الشريط السفلي ─────────────

/** بطاقة إجراء عتيقة: أيقونة حبرية وتسمية، مع شارة عدّاد اختيارية. */
@Composable
fun ActionCard(
    icon: Int,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badge: Int = 0,
    dim: Boolean = false,
) {
    val s = LocalS.current
    Press(onClick, modifier.size(s(47), s(62))) {
        Pic(R.drawable.card_vintage, Modifier.matchParentSize(), alpha = if (dim) 0.62f else 1f)
        Pic(icon, Modifier.align(Alignment.TopCenter).padding(top = s(10)).size(s(26)), alpha = if (dim) 0.45f else 1f)
        ArText(
            label, 8.6f, if (dim) InkSoft else Ink, FontWeight.Bold, TextAlign.Center,
            Modifier.align(Alignment.BottomCenter).padding(bottom = s(9)).width(s(38)), maxLines = 1,
        )
        if (badge > 0) {
            Box(
                Modifier.align(Alignment.TopEnd).offset(s(2), s(0)).size(s(15)).background(Wax, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                ArText(if (badge > 9) "9+" else badge.toString(), 8, Cream, FontWeight.Bold, TextAlign.Center)
            }
        }
    }
}

/** ختم الشمع الأحمر: ضغطة واحدة تعلن أنك جاهز لإنهاء الجولة، وضغطة ثانية تلغي ذلك. */
@Composable
fun ReadySeal(ready: Boolean, waitingFor: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val s = LocalS.current
    Press(onClick, modifier.size(s(66), s(62)), sound = false) {
        Pic(
            if (ready) R.drawable.seal_ready else R.drawable.seal_idle,
            Modifier.align(Alignment.TopCenter).size(s(46)),
        )
        if (!ready) {
            ArText("جاهز", 11, Cream, FontWeight.Bold, TextAlign.Center, Modifier.align(Alignment.TopCenter).padding(top = s(15)), shadow = true)
        }
        ArText(
            if (ready) (if (waitingFor > 0) "بانتظار $waitingFor" else "جاهز!") else "أنهِ الجولة",
            8.4f, Brass, FontWeight.Bold, TextAlign.Center,
            Modifier.align(Alignment.BottomCenter).padding(bottom = s(3)), maxLines = 1, shadow = true,
        )
    }
}

/** الشريط السفلي: ختم الجاهزية (يسار) ثم بطاقات الإجراءات الأربع. */
@Composable
fun BottomBar(
    v: PView,
    leftWidth: androidx.compose.ui.unit.Dp,
    blocked: Boolean,
    onAsk: () -> Unit,
    onSend: () -> Unit,
    onSay: () -> Unit,
    onAbility: () -> Unit,
    onReady: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalS.current
    val me = v.players[v.seat]
    val waiting = v.players.count { !it.ready && it.connected }
    Row(modifier.fillMaxWidth().height(s(64)), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(leftWidth).fillMaxHeight(), contentAlignment = Alignment.Center) {
            ReadySeal(me.ready, waiting, onReady)
        }
        Row(
            Modifier.weight(1f).fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(s(14), Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ActionCard(Pics.ability(v.seat), if (me.abilityUsed) "استُخدمت" else game.ABILITY_AR[v.seat], onAbility, dim = me.abilityUsed)
            ActionCard(R.drawable.icon_say, "قل", onSay, dim = blocked)
            ActionCard(R.drawable.icon_send, "أرسل", onSend, dim = blocked)
            ActionCard(R.drawable.icon_ask, "اسأل", onAsk, dim = blocked)
        }
    }
}
