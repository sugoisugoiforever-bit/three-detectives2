package com.detectives.threefiles.session

import game.Json
import game.asMap
import game.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/** أدوات الشبكة المشتركة: عنوان الخادم، إنشاء غرفة، فحص الاتصال. */
object Net {
    const val CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    const val CODE_LEN = 5

    /** عميل الاتصال الدائم: بلا مهلة قراءة، مع نبضات ping لاكتشاف الانقطاع. */
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }

    /** عميل الطلبات القصيرة (إنشاء غرفة / فحص). */
    private val http: OkHttpClient by lazy {
        client.newBuilder()
            .readTimeout(12, TimeUnit.SECONDS)
            .pingInterval(0, TimeUnit.MILLISECONDS)
            .build()
    }

    /** يحوّل ما كتبه اللاعب إلى عنوان http(s) صالح بلا مسار، أو null إن كان غير صالح. */
    fun httpBase(raw: String): String? {
        val t = raw.trim().trimEnd('/')
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        val full = when {
            t.startsWith("wss://") -> "https://" + t.substring(6)
            t.startsWith("ws://") -> "http://" + t.substring(5)
            t.startsWith("https://") || t.startsWith("http://") -> t
            else -> "https://$t"
        }
        val scheme = full.substringBefore("://")
        val host = full.substringAfter("://").substringBefore('/')
        if (host.isEmpty() || !host.any { it.isLetterOrDigit() }) return null
        return "$scheme://$host"
    }

    fun cleanCode(raw: String): String =
        raw.uppercase().filter { it in CODE_ALPHABET }.take(CODE_LEN)

    fun describe(e: Throwable): String = when (e) {
        is UnknownHostException -> "تعذّر العثور على الخادم. تحقّق من العنوان ومن الإنترنت."
        is SocketTimeoutException -> "انتهت مهلة الاتصال بالخادم."
        is IOException -> "تعذّر الاتصال بالخادم."
        else -> e.message ?: "حدث خطأ غير متوقع."
    }

    /** ينشئ غرفة جديدة على الخادم ويعيد رمزها. */
    suspend fun createRoom(rawBase: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val base = httpBase(rawBase) ?: return@withContext Result.failure(IllegalStateException("عنوان الخادم غير صالح"))
            val req = Request.Builder()
                .url("$base/api/create")
                .post("{}".toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { r ->
                val body = r.body?.string() ?: ""
                if (!r.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("رفض الخادم الطلب (${r.code})"))
                }
                Result.success(Json.parse(body).asMap().str("code"))
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException(describe(e)))
        }
    }

    /** يفحص أن العنوان يشير إلى خادم اللعبة. */
    suspend fun ping(rawBase: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val base = httpBase(rawBase) ?: return@withContext false
            val req = Request.Builder().url("$base/api/ping").get().build()
            http.newCall(req).execute().use { r -> r.isSuccessful && (r.body?.string() ?: "").contains("detectives") }
        } catch (e: Exception) {
            false
        }
    }
}
