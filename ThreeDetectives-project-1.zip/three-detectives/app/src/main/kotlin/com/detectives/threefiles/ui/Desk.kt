package com.detectives.threefiles.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.detectives.threefiles.R
import game.Notice
import game.PPlayer
import game.PView
import game.ROLE_AR

// ───────────── لوحة الفريق ─────────────

@Composable
fun StatusPill(p: PPlayer, approved: Boolean? = null) {
    val s = LocalS.current
    val txt: String
    val bg: Color
    if (approved != null) {
        if (!approved) return
        txt = "وافق"
        bg = Good
    } else if (!p.connected) {
        txt = "منقطع"
        bg = Color(0xFF6B6B6B)
    } else if (p.ready) {
        txt = "جاهز"
        bg = Good
    } else if (p.moveUsed) {
        txt = "تحرّك"
        bg = Color(0xFF9A6A1C)
    } else {
        return
    }
    Box(Modifier.background(bg, RoundedCornerShape(s(4))).padding(horizontal = s(4), vertical = s(1))) {
        ArText(txt, 7.4f, Cream, FontWeight.Bold, TextAlign.Center)
    }
}

/** شريحة لاعب نحاسية: القدرة والحالة يساراً، والاسم والدور يميناً. */
@Composable
fun PlayerChip(p: PPlayer, mine: Boolean, modifier: Modifier = Modifier, approved: Boolean? = null) {
    val s = LocalS.current
    val shape = RoundedCornerShape(s(7))
    val role = ROLE_AR[p.seat]
    val main = if (p.name == role) role else p.name
    val sub = when {
        mine -> if (p.name == role) "أنت" else "أنت • $role"
        p.name == role -> if (p.bot) "محقق آلي" else "لاعب"
        else -> role + (if (p.bot) " • آلي" else "")
    }
    Box(modifier.fillMaxWidth().height(s(33))) {
        BrassFace(Modifier.matchParentSize(), 7)
        if (mine) Box(Modifier.matchParentSize().border(s(2), Wax, shape))
        Row(
            Modifier.matchParentSize().padding(horizontal = s(6)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(s(4)),
        ) {
            Pic(Pics.ability(p.seat), Modifier.size(s(14)), alpha = if (p.abilityUsed) 0.28f else 0.9f)
            StatusPill(p, approved)
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                ArText(main, 9.4f, Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
                ArText(sub, 7.6f, InkSoft, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
            }
        }
    }
}

@Composable
fun TeamPanel(v: PView, modifier: Modifier = Modifier, approvals: List<Boolean>? = null) {
    val s = LocalS.current
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(s(5))) {
        for (p in v.players) PlayerChip(p, p.seat == v.seat, approved = approvals?.getOrNull(p.seat))
    }
}

// ───────────── الدفتر المصغّر ─────────────

private val NbInk = Color(0xFF3B2A1C)

/** نص آخر المستجدات المختصر للدفتر. */
fun peekLines(feed: List<Notice>, n: Int): List<String> = feed.takeLast(n).map { it.text }

/** دفتر مفتوح بصفحتين: ملف القضية يميناً وآخر المستجدات يساراً؛ النقر يفتح الدفتر الكامل. */
@Composable
fun NotebookPeek(v: PView, unread: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val s = LocalS.current
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val aspect = 1188f / 888f
        val bw = minOf(maxWidth, maxHeight * aspect)
        val bh = bw / aspect
        Press(onClick, Modifier.size(bw, bh)) {
            Pic(R.drawable.notebook, Modifier.matchParentSize())
            // الصفحة اليسرى: آخر المستجدات
            Column(
                Modifier.padding(start = bw * 0.085f, top = bh * 0.13f).size(bw * 0.39f, bh * 0.74f),
                verticalArrangement = Arrangement.spacedBy(s(2)),
            ) {
                ArText("آخر المستجدات", 7, NbInk, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                for (t in peekLines(v.feed, 4)) {
                    ArText(t, 6.3f, NbInk, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 3, font = Serif)
                }
            }
            // الصفحة اليمنى: ملف القضية
            Column(
                Modifier.padding(start = bw * 0.53f, top = bh * 0.13f).size(bw * 0.39f, bh * 0.74f),
                verticalArrangement = Arrangement.spacedBy(s(2)),
            ) {
                ArText("ملف القضية", 7, NbInk, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                ArText(v.info.title, 7.4f, NbInk, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 3, font = Serif)
                ArText(v.info.date, 6.4f, NbInk, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1, font = Serif)
                ArText("اضغط لقراءة الملف والمستجدات", 6.2f, Color(0xFF7A3A2A), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 2, font = Serif)
            }
            if (unread > 0) {
                Box(
                    Modifier.align(Alignment.TopStart).padding(start = s(2), top = s(1)).size(s(16))
                        .background(Wax, androidx.compose.foundation.shape.CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    ArText(if (unread > 9) "9+" else unread.toString(), 8.4f, Cream, FontWeight.Bold, TextAlign.Center)
                }
            }
        }
    }
}

// ───────────── سطح المكتب: الوثائق ─────────────

/** شبكة الوثائق على المكتب، الأحدث أولاً (من اليمين). */
@Composable
fun DeskGrid(
    v: PView,
    unseen: Set<String>,
    hot: Set<String>,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalS.current
    BoxWithConstraints(modifier) {
        val gap = s(7)
        val pad = s(8)
        val cols = maxOf(3, ((maxWidth - pad * 2) / s(66)).toInt())
        val w = (maxWidth - pad * 2 - gap * (cols - 1)) / cols
        val docs = v.docs.reversed()
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = pad, vertical = s(8)),
            verticalArrangement = Arrangement.spacedBy(s(9)),
        ) {
            for (row in docs.chunked(cols)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap, Alignment.End)) {
                    for (d in row.reversed()) {
                        DocThumb(d, w, d.id in unseen, d.id in hot, v.seat, { onOpen(d.id) })
                    }
                }
            }
            if (docs.isEmpty()) {
                ArText("لا وثائق على مكتبك بعد", 11, Brass, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth())
            }
        }
    }
}
