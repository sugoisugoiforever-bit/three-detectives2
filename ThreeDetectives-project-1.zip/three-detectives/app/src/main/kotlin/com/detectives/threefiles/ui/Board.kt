package com.detectives.threefiles.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import com.detectives.threefiles.R
import game.PReq
import game.PView
import game.Person
import game.ROLE_AR

/** علامات اللاعب الخاصة على المشتبهين: 1 = مشتبه، 2 = مستبعد (محلية لا يراها الزملاء). */
const val MARK_NONE = 0
const val MARK_SUSPECT = 1
const val MARK_CLEARED = 2

/** الطلبات الظاهرة على اللوحة: طلبات الزملاء التي عندي ما يناسبها، أو طلبات الجولة الحالية. */
fun visibleRequests(v: PView): List<PReq> =
    v.requests.filter { !it.mine && (it.matches.isNotEmpty() || it.round == v.round) }.takeLast(3).reversed()

private val SlotPos = listOf(
    Pair(0, 0), Pair(1, 0), Pair(2, 0), Pair(3, 0),
    Pair(0, 1), Pair(1, 1), Pair(2, 1),
)

/** صورة بولارويد لمشتبه: وجه، اسم أول، دبوس، وعلامة حمراء اختيارية. */
@Composable
fun Polaroid(p: Person, idx: Int, mark: Int, w: Dp, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val h = w * (410f / 330f)
    val rot = ((idx * 37 + 11) % 9 - 4) * 0.9f
    Press(onClick, modifier.size(w, h).rotate(rot)) {
        Box(Modifier.matchParentSize().shadow(s(4), RoundedCornerShape(s(1))))
        Pic(R.drawable.polaroid, Modifier.matchParentSize())
        Pic(
            Pics.portrait(p.portrait),
            Modifier.offset(w * 0.0667f, w * 0.0667f).size(w * 0.8667f),
            ContentScale.Crop,
        )
        ArText(
            p.first, 8.2f, Ink, FontWeight.Bold, TextAlign.Center,
            Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.055f).fillMaxWidth(), maxLines = 1, font = Serif,
        )
        if (mark != MARK_NONE) {
            Canvas(Modifier.offset(w * 0.0667f, w * 0.0667f).size(w * 0.8667f)) {
                val d = size.minDimension
                if (mark == MARK_SUSPECT) {
                    drawCircle(Wax, radius = d * 0.47f, style = Stroke(width = d * 0.05f))
                } else {
                    val a = d * 0.16f
                    val b = d - a
                    drawLine(Wax, Offset(a, a), Offset(b, b), strokeWidth = d * 0.07f, cap = StrokeCap.Round)
                    drawLine(Wax, Offset(b, a), Offset(a, b), strokeWidth = d * 0.07f, cap = StrokeCap.Round)
                }
            }
        }
        Pic(
            Pics.pin(idx),
            Modifier.align(Alignment.TopCenter).offset(y = -(w * 0.1f)).size(w * 0.27f),
        )
    }
}

/** ورقة لاصقة صفراء لطلب زميل؛ تنبض بالحمرة إن كانت عندي وثائق تناسبه. */
@Composable
fun Sticky(r: PReq, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val s = LocalS.current
    val hot = r.matches.isNotEmpty()
    val rot = ((r.id * 7) % 5 - 2) * 2.4f
    Press(onClick, modifier.size(s(66)).rotate(rot)) {
        Pic(
            R.drawable.sticky, Modifier.matchParentSize(),
            tint = if (hot) Color(0xFFFFE27A) else Color(0xFFF0E3A8), blend = BlendMode.Modulate,
        )
        Column(
            Modifier.matchParentSize().padding(start = s(9), end = s(9), top = s(12), bottom = s(9)),
            verticalArrangement = Arrangement.spacedBy(s(1)),
        ) {
            ArText(ROLE_AR[r.from], 7f, InkSoft, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1)
            ArText(r.label, 8.6f, if (hot) Color(0xFF8E1A12) else Ink, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 3)
            Box(Modifier.weight(1f))
            ArText(
                if (hot) "لديك " + r.matches.size + " • ردّ" else "لا شيء لديك",
                6.8f, if (hot) Good else InkSoft, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), maxLines = 1,
            )
        }
        Pic(
            if (hot) R.drawable.pin_red else R.drawable.pin_yellow,
            Modifier.align(Alignment.TopCenter).offset(y = s(-1)).size(s(13)),
        )
    }
}

/** لوحة الفلين: سبع صور للمشتبهين (مع خيوط حمراء بين من تشتبه بهم) وأوراق الطلبات أسفلها. */
@Composable
fun CorkBoard(
    v: PView,
    marks: Map<String, Int>,
    onPerson: (String) -> Unit,
    onRequest: (PReq) -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalS.current
    Box(modifier) {
        Pic(R.drawable.corkboard, Modifier.matchParentSize())
        BoxWithConstraints(Modifier.matchParentSize()) {
            val w = maxWidth
            val h = maxHeight
            val ix = w * 0.075f
            val iy = h * 0.085f
            val iw = w - ix * 2
            val cell = iw / 4
            val pw = cell - s(5)
            val ph = pw * (410f / 330f)
            val gapY = s(7)
            // مواضع الصور: الصف الأول أربع، والثاني ثلاث متوسّطة
            val rowOff = listOf(cell * 0f, cell * 0.5f)
            val posX = ArrayList<Dp>()
            val posY = ArrayList<Dp>()
            for (i in 0 until 7) {
                val (c, r) = SlotPos[i]
                posX.add(ix + rowOff[r] + cell * c + (cell - pw) / 2f)
                posY.add(iy + (ph + gapY) * r + s(6))
            }
            // خيوط حمراء بين المشتبه بهم
            val pins = ArrayList<Int>()
            for ((i, per) in v.info.persons.withIndex()) if (marks[per.id] == MARK_SUSPECT) pins.add(i)
            for ((i, per) in v.info.persons.withIndex()) {
                if (i >= 7) break
                Polaroid(per, i, marks[per.id] ?: MARK_NONE, pw, { onPerson(per.id) }, Modifier.offset(posX[i], posY[i]))
            }
            if (pins.size >= 2) {
                Canvas(Modifier.matchParentSize()) {
                    val thread = Color(0xCCB3261E)
                    for (k in 0 until pins.size - 1) {
                        val a = pins[k]
                        val b = pins[k + 1]
                        val ax = (posX[a] + pw / 2f).toPx()
                        val ay = (posY[a] + ph * 0.02f).toPx()
                        val bx = (posX[b] + pw / 2f).toPx()
                        val by = (posY[b] + ph * 0.02f).toPx()
                        drawLine(thread, Offset(ax, ay), Offset(bx, by), strokeWidth = 1.6f * density)
                    }
                }
            }
            // الطلبات
            val reqs = visibleRequests(v)
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = ix, end = ix, bottom = h * 0.07f),
                horizontalArrangement = Arrangement.spacedBy(s(2), Alignment.CenterHorizontally),
            ) {
                for (r in reqs) Sticky(r, { onRequest(r) })
                if (reqs.isEmpty()) {
                    ArText(
                        "طلبات زملائك تظهر هنا", 8, Color(0xFFF3E1BC), FontWeight.Bold, TextAlign.Center,
                        Modifier.padding(bottom = s(4)), shadow = true,
                    )
                }
            }
        }
    }
}
