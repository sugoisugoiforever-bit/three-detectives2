package com.detectives.threefiles.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.detectives.threefiles.R
import game.Notice
import game.PView
import game.ROLE_AR

// ───────────── ملف المشتبه ─────────────

@Composable
fun SuspectSheet(
    v: PView,
    id: String,
    ui: UiState,
    onAsk: (String) -> Unit,
    onOpenDoc: (String) -> Unit,
    onClose: () -> Unit,
) {
    val s = LocalS.current
    val idx = v.info.persons.indexOfFirst { it.id == id }
    if (idx < 0) return
    val p = v.info.persons[idx]
    val mark = ui.marks[id] ?: MARK_NONE
    val block = moveBlock(v)
    val mentions = v.docs.filter { id in it.topics }
    Sheet("ملف المشتبه", onClose, 440) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(12), Alignment.End), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(5))) {
                ArText(p.name, 16, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                ArText(p.job, 11, Cream, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
                Note("علاماتك على اللوحة خاصة بك ولا يراها زميلاك.")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(5), Alignment.End)) {
                    Chip("بلا علامة", mark == MARK_NONE, { ui.mark(id, MARK_NONE) }, size = 10)
                    Chip("مستبعد", mark == MARK_CLEARED, { ui.mark(id, MARK_CLEARED) }, size = 10)
                    Chip("مشتبه", mark == MARK_SUSPECT, { ui.mark(id, MARK_SUSPECT) }, size = 10)
                }
            }
            Box(Modifier.padding(top = s(8), end = s(4))) {
                Polaroid(p, idx, mark, s(82), { }, Modifier)
            }
        }
        SectionLabel("وثائق تذكره (${mentions.size})")
        if (mentions.isEmpty()) {
            Note("لا شيء في وثائقك عنه حتى الآن. اسأل الفريق، فقد يكون عند زميليك.")
        } else {
            ChipRows(mentions.map { it.id to it.title }, null, 2, { onOpenDoc(it) }, 9.5f)
        }
        BrassButton(
            text = "اسأل الفريق عن " + p.first,
            onClick = { onAsk(id) },
            modifier = Modifier.fillMaxWidth(),
            enabled = block == null,
            size = 11.5f,
        )
        if (block != null) Note(block, warn = true)
    }
}

// ───────────── الدفتر الكامل ─────────────

private val NbInk = Color(0xFF3B2A1C)

private fun noticeColor(n: Notice): Color = when (n.kind) {
    "request" -> Color(0xFF8E1A12)
    "share" -> Color(0xFF2F6B2B)
    "template" -> Color(0xFF1F4E8C)
    "ability", "intercept" -> Color(0xFF6A2E86)
    "accuse" -> Color(0xFF8E1A12)
    else -> NbInk
}

/** الدفتر مفتوحاً: ملف القضية على الصفحة اليمنى، ويوميات التحقيق على اليسرى (الأحدث أولاً). */
@Composable
fun NotebookSheet(v: PView, ui: UiState, onClose: () -> Unit) {
    val s = LocalS.current
    LaunchedEffect(v.feed.size) {
        ui.readFeed = v.feed.lastOrNull()?.id ?: 0
    }
    Scrim(onClose) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = s(8), vertical = s(6))) {
            val aspect = 1188f / 888f
            val h = minOf(maxHeight, maxWidth / aspect)
            val w = h * aspect
            // سطر الدفتر ≈ 4.5% من ارتفاعه؛ نضبط حجم الخط ليوافق الأسطر المرسومة
            val line = h.value / s.k * 0.045f
            val fs = line / 1.38f
            Box(Modifier.align(Alignment.Center).size(w, h).swallowTaps()) {
                Pic(R.drawable.notebook, Modifier.matchParentSize())
                // الصفحة اليسرى: اليوميات
                Column(
                    Modifier.padding(start = w * 0.085f, top = h * 0.115f).size(w * 0.39f, h * 0.77f).verticalScroll(rememberScrollState()),
                ) {
                    ArText("يوميات التحقيق", fs * 1.1f, NbInk, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    for (n in v.feed.reversed()) {
                        ArText("ج" + n.round + " • " + n.text, fs * 0.92f, noticeColor(n), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    }
                }
                // الصفحة اليمنى: ملف القضية
                Column(
                    Modifier.padding(start = w * 0.525f, top = h * 0.115f).size(w * 0.39f, h * 0.77f).verticalScroll(rememberScrollState()),
                ) {
                    ArText(v.info.title, fs * 1.15f, NbInk, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    ArText(v.info.org + " • " + v.info.date, fs * 0.9f, Color(0xFF6A4A33), FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    ArText(v.info.brief, fs * 0.92f, NbInk, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    ArText("المشتبهون:", fs * 0.95f, NbInk, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    for (p in v.info.persons) {
                        ArText(p.name + " — " + p.job, fs * 0.88f, NbInk, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    }
                    ArText("الأسئلة الثلاثة: من؟ كيف؟ لماذا؟", fs * 0.9f, Color(0xFF8E1A12), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                }
            }
        }
    }
}

// ───────────── المساعدة ─────────────

private val HELP = listOf(
    "الهدف" to "حلّوا القضية معاً: من الفاعل؟ كيف نُفِّذت؟ ولماذا؟ لكل واحد منكم وثائق لا يراها زميلاه، ولا توجد محادثة حرّة بينكم.",
    "الجولات" to "خمس جولات، وتصل في كل جولة وثائق جديدة. تنتهي الجولة حين يضغط الجميع «أنهِ الجولة» أو ينتهي الوقت.",
    "حركتك" to "لكل لاعب حركة واحدة في الجولة: «اسأل» (مجاني)، أو «أرسل» نسخة وثيقة لزميل (قطعة نحاسية)، أو «قل» رسالة جاهزة (قطعة نحاسية).",
    "القطع النحاسية" to "ميزانية مشتركة للفريق كله. فكّروا فيما يستحق الإرسال، فهي لا تُستعاد.",
    "الطلبات" to "حين يسأل زميلك عن موضوع وعندك وثيقة عنه تظهر ورقة صفراء على لوحة الفلين ووثيقتك تنبض. اضغط الورقة لتردّ.",
    "قدرتك الخاصة" to "لكل دور قدرة تُستعمل مرة واحدة في اللعبة ولا تستهلك حركتك: تدقيق، مداهمة، أو اعتراض.",
    "الاتهام" to "بعد الجولة الرابعة تُفتح نافذة الاتهام: اختاروا إجابة لكل سؤال، واستشهدوا بوثيقتين من صاحبين مختلفين، ثم يوافق الثلاثة. إن لم تتهموا تأتي جولة أخيرة ونافذة تكفي فيها موافقة اثنين.",
    "النجوم" to "ثلاث نجوم لثلاث إجابات صحيحة كلها بأدلة حاسمة من النافذة الأولى. نجمتان لثلاث إجابات صحيحة بغير ذلك، ونجمة لإجابتين صحيحتين.",
)

@Composable
fun HelpSheet(onClose: () -> Unit) {
    val s = LocalS.current
    Scrim(onClose) {
        PaperPanel(Modifier.width(s(470)).heightIn(max = s(336)).swallowTaps()) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(horizontal = s(18), vertical = s(14)),
                verticalArrangement = Arrangement.spacedBy(s(6)),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    CloseButton(onClose)
                    ArText("كيف تُلعب؟", 17, Ink, FontWeight.Bold, TextAlign.Right, font = Serif)
                }
                for (h in HELP) {
                    ArText(h.first, 11.5f, Color(0xFF8E1A12), FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                    ArText(h.second, 10.3f, Ink, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                }
            }
        }
    }
}
