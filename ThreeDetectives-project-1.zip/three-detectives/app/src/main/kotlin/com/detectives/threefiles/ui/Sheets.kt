package com.detectives.threefiles.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import game.ABILITY_AR
import game.Action
import game.PView
import game.ROLE_AR

private val Soft = Color(0xCCEBD9A8)
private val Warn = Color(0xFFE8A598)

@Composable
fun SectionLabel(text: String) {
    ArText(text, 10.5f, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
}

@Composable
fun Note(text: String, warn: Boolean = false) {
    ArText(text, 9.4f, if (warn) Warn else Soft, if (warn) FontWeight.Bold else FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
}

/** شرائح موزّعة في صفوف بعدد ثابت (بديل بسيط عن FlowRow)، والأول عند اليمين. */
@Composable
fun ChipRows(items: List<Pair<String, String>>, selected: String?, perRow: Int, onSelect: (String) -> Unit, size: Number = 10) {
    val s = LocalS.current
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(s(5))) {
        for (row in items.chunked(perRow)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(5), Alignment.End)) {
                for (p in row.reversed()) {
                    Chip(p.second, selected == p.first, { onSelect(p.first) }, size = size)
                }
            }
        }
    }
}

// ───────────── اسأل الفريق ─────────────

@Composable
fun AskSheet(v: PView, onAsk: (String) -> Unit, onClose: () -> Unit) {
    var sel by remember { mutableStateOf<String?>(null) }
    val block = moveBlock(v)
    val kinds = listOf("person" to "أشخاص", "place" to "أماكن", "time" to "أوقات", "key" to "رموز وأرقام")
    Sheet("اسأل الفريق", onClose, 430) {
        Note("اختر موضوعاً ليصل سؤالك إلى زميليك. إن كانت عند أحدهما وثيقة عنه سيُنبَّه لإرسالها إليك. السؤال مجاني، لكنه يستهلك حركتك في هذه الجولة.")
        for (k in kinds) {
            val items = v.topics.filter { it.kind == k.first }.map { it.id to it.label }
            if (items.isNotEmpty()) {
                SectionLabel(k.second)
                ChipRows(items, sel, if (k.first == "time") 6 else if (k.first == "key") 3 else 4, { sel = it })
            }
        }
        val chosen = sel
        val label = if (chosen == null) null else v.topics.firstOrNull { it.id == chosen }?.label
        BrassButton(
            text = if (label == null) "اختر موضوعاً" else "اسأل عن «$label»",
            onClick = { if (chosen != null) onAsk(chosen) },
            modifier = Modifier.fillMaxWidth(),
            enabled = chosen != null && block == null,
            size = 12,
        )
        if (block != null) Note(block, warn = true)
    }
}

// ───────────── قل شيئاً (قوالب الرسائل) ─────────────

private class Tpl(val id: String, val title: String)

private val TPLS = listOf(
    Tpl("T1", "أين كان؟"), Tpl("T2", "أشك في"), Tpl("T3", "أستبعد"), Tpl("T4", "الأسلوب"), Tpl("T5", "الدافع"),
)

/** نفس صياغة المحرك تماماً؛ تعاد null إن نقصت خانة. */
fun previewText(v: PView, tpl: String, slots: Map<String, String>): String? {
    fun topic(slot: String, kind: String) = v.topics.firstOrNull { it.id == slots[slot] && it.kind == kind }
    fun option(q: String, slot: String) = v.info.questions.firstOrNull { it.id == q }?.options?.firstOrNull { it.id == slots[slot] }
    return when (tpl) {
        "T1" -> {
            val p = topic("person", "person")
            val l = topic("place", "place")
            val t = topic("time", "time")
            if (p == null || l == null || t == null) null
            else {
                val g = v.info.persons.firstOrNull { it.id == p.id }?.g
                p.label + " " + (if (g == "f") "كانت" else "كان") + " في " + l.label + " الساعة " + t.label
            }
        }
        "T2" -> topic("person", "person")?.let { "أشك في " + it.label }
        "T3" -> topic("person", "person")?.let { "أقترح استبعاد " + it.label + " من المشتبهين" }
        "T4" -> option("how", "how")?.let { "الأسلوب على الأرجح: " + it.label }
        "T5" -> option("why", "why")?.let { "الدافع على الأرجح: " + it.label }
        else -> null
    }
}

@Composable
fun SaySheet(v: PView, onSend: (Action) -> Unit, onClose: () -> Unit) {
    val s = LocalS.current
    var tpl by remember { mutableStateOf("T2") }
    var slots by remember { mutableStateOf(emptyMap<String, String>()) }
    val block = moveBlock(v) ?: if (v.credits < 1) "نفدت القطع النحاسية" else null
    val text = previewText(v, tpl, slots)
    val persons = v.info.persons.map { it.id to it.name }
    val places = v.topics.filter { it.kind == "place" }.map { it.id to it.label }
    val times = v.topics.filter { it.kind == "time" }.map { it.id to it.label }
    Sheet("قل شيئاً للفريق", onClose, 440) {
        Note("رسالة جاهزة تصل إلى زميليك. تكلّف قطعة نحاسية واحدة وتستهلك حركتك (لديك ${v.credits}).")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(5), Alignment.End)) {
            for (t in TPLS.reversed()) {
                Chip(t.title, tpl == t.id, { tpl = t.id; slots = emptyMap() }, size = 10.5f)
            }
        }
        if (tpl == "T1") {
            SectionLabel("من؟")
            ChipRows(persons, slots["person"], 4, { slots = slots + ("person" to it) }, 9.5f)
            SectionLabel("أين؟")
            ChipRows(places, slots["place"], 4, { slots = slots + ("place" to it) }, 9.5f)
            SectionLabel("متى؟ (أوقات ظهرت في وثائقك)")
            if (times.isEmpty()) Note("لا توجد أوقات في وثائقك بعد.", warn = true)
            ChipRows(times, slots["time"], 6, { slots = slots + ("time" to it) }, 9.5f)
        } else if (tpl == "T2" || tpl == "T3") {
            SectionLabel(if (tpl == "T2") "أشك في…" else "أقترح استبعاد…")
            ChipRows(persons, slots["person"], 4, { slots = slots + ("person" to it) }, 9.5f)
        } else {
            val q = if (tpl == "T4") "how" else "why"
            val slot = q
            SectionLabel(if (tpl == "T4") "كيف نُفِّذت الجريمة على الأرجح؟" else "ما الدافع على الأرجح؟")
            val opts = v.info.questions.firstOrNull { it.id == q }?.options ?: emptyList()
            for (o in opts) {
                Chip(o.label, slots[slot] == o.id, { slots = slots + (slot to o.id) }, Modifier.fillMaxWidth(), size = 9.5f)
            }
        }
        if (text != null) {
            LeatherPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(s(8))) {
                    Note("ستصل الرسالة هكذا:")
                    ArText("«$text»", 11.5f, Cream, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                }
            }
        }
        BrassButton(
            text = "أرسل الرسالة",
            onClick = { onSend(Action.Template(tpl, slots)) },
            modifier = Modifier.fillMaxWidth(),
            enabled = text != null && block == null,
            size = 12,
        )
        if (block != null) Note(block, warn = true)
    }
}

// ───────────── القدرة الخاصة ─────────────

@Composable
fun AbilitySheet(v: PView, onUse: () -> Unit, onPickDoc: () -> Unit, onClose: () -> Unit) {
    val s = LocalS.current
    val me = v.players[v.seat]
    Sheet("قدرتك: " + ABILITY_AR[v.seat], onClose, 400) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(10), Alignment.End), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(s(3))) {
                ArText(ROLE_AR[v.seat], 13, Brass, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth(), font = Serif)
                ArText(ROLE_DESC[v.seat], 9.6f, Cream, FontWeight.Normal, TextAlign.Right, Modifier.fillMaxWidth())
            }
            Pic(Pics.ability(v.seat), Modifier.size(s(46)), tint = Brass)
        }
        ArText(ABILITY_DESC[v.seat], 10.5f, Cream, FontWeight.Bold, TextAlign.Right, Modifier.fillMaxWidth())
        Note("تُستعمل مرة واحدة في اللعبة كلها، ولا تستهلك حركتك ولا قطعك النحاسية.")
        if (v.seat == 2 && v.interceptArmed) Note("الاعتراض مفعّل الآن وينتظر أول وثيقة تُرسَل بين زميليك.")
        BrassButton(
            text = if (me.abilityUsed) "استخدمتَ قدرتك" else if (v.seat == 0) "اختر وثيقة للتدقيق" else "استخدم القدرة الآن",
            onClick = { if (v.seat == 0) onPickDoc() else onUse() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !me.abilityUsed && v.phase == "round",
            size = 12,
        )
    }
}
