package com.detectives.threefiles.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import com.detectives.threefiles.AppModel
import com.detectives.threefiles.R
import com.detectives.threefiles.Screen

/**
 * جذر الواجهة: يثبّت وحدة القياس (ارتفاع الشاشة/360)، ويُلغي تكبير الخط واتجاه RTL العام،
 * ويرسم المكتب الخشبي خلف كل الشاشات.
 */
@Composable
fun GameRoot(model: AppModel, share: (String) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF1B1109))) {
        val k = maxHeight.value / 360f
        val density = LocalDensity.current
        CompositionLocalProvider(
            LocalS provides S(k),
            LocalDensity provides Density(density.density, 1f),
            LocalLayoutDirection provides LayoutDirection.Ltr,
        ) {
            Box(Modifier.fillMaxSize()) {
                Pic(R.drawable.desk_wood, Modifier.fillMaxSize(), ContentScale.Crop)
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.radialGradient(listOf(Color(0x00000000), Color(0x00000000), Color(0x99000000))),
                    ),
                )
                Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout).imePadding()) {
                    RootContent(model, share)
                }
            }
        }
    }
}

@Composable
private fun RootContent(model: AppModel, share: (String) -> Unit) {
    var help by remember { mutableStateOf(false) }
    val screen = model.screen
    BackHandler(enabled = screen != Screen.Menu && screen != Screen.Play) { model.back() }
    BackHandler(enabled = help) { help = false }
    when (screen) {
        Screen.Menu -> MenuScreen(
            stats = model.stats,
            onSolo = { model.go(Screen.SoloSetup) },
            onOnline = { model.go(Screen.OnlineSetup) },
            onHelp = { help = true },
            onSettings = { model.go(Screen.Settings) },
        )
        Screen.SoloSetup -> SoloSetupScreen(
            name = model.name, role = model.role, theme = model.theme, difficulty = model.difficulty,
            onName = { model.updateName(it) }, onRole = { model.updateRole(it) },
            onTheme = { model.updateTheme(it) }, onDifficulty = { model.updateDifficulty(it) },
            onStart = { model.startSolo() }, onBack = { model.back() },
        )
        Screen.OnlineSetup -> OnlineSetupScreen(
            name = model.name, server = model.server, code = model.code,
            busy = model.busy, error = model.error,
            onName = { model.updateName(it) }, onServer = { model.updateServer(it) }, onCode = { model.updateCode(it) },
            onCreate = { model.createRoom() }, onJoin = { model.joinRoom() }, onBack = { model.back() },
        )
        Screen.Settings -> SettingsScreen(
            name = model.name, sound = model.sound, server = model.server,
            onName = { model.updateName(it) }, onSound = { model.updateSound(it) },
            onServer = { model.updateServer(it) }, onTutorial = { model.go(Screen.Tutorial) },
            onBack = { model.back() },
        )
        Screen.Tutorial -> TutorialScreen({ model.finishTutorial() })
        Screen.Play -> {
            val session = model.session
            if (session != null) PlayHost(model, session, share)
        }
    }
    if (help && screen == Screen.Menu) HelpSheet { help = false }
}
