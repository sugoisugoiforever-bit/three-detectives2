package com.detectives.threefiles.ui

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.activity.compose.BackHandler
import com.detectives.threefiles.AppModel
import com.detectives.threefiles.audio.Sfx
import com.detectives.threefiles.session.GameSession
import com.detectives.threefiles.session.Snap
import kotlinx.coroutines.delay
import game.PView

private fun secondsLeft(s: Snap): Long {
    val ms = if (s.frozen) s.v.endsInMs else s.v.endsInMs - (SystemClock.elapsedRealtime() - s.at)
    return (ms.coerceAtLeast(0L) + 999L) / 1000L
}

/** الزمن المتبقي بالثواني (يتحدّث مرة كل ثانية، فلا تُعاد رسم الواجهة أكثر من ذلك). */
@Composable
private fun rememberSecondsLeft(snap: Snap): Long {
    var sec by remember(snap) { mutableStateOf(secondsLeft(snap)) }
    LaunchedEffect(snap) {
        while (true) {
            sec = secondsLeft(snap)
            if (snap.frozen) break
            delay(200)
        }
    }
    return sec
}

/** أصوات وإشعارات الأحداث الجديدة: مستجدات الدفتر، بدء الجولات، صرف القطع، وعدّ الثواني الأخيرة. */
@Composable
private fun SessionEffects(v: PView, sec: Long, frozen: Boolean, toaster: Toaster) {
    var lastId by remember { mutableStateOf(v.feed.lastOrNull()?.id ?: 0) }
    var credits by remember { mutableStateOf(v.credits) }
    val maxId = v.feed.lastOrNull()?.id ?: 0
    LaunchedEffect(maxId) {
        if (maxId > lastId) {
            val fresh = v.feed.filter { it.id > lastId }
            lastId = maxId
            for (c in cuesFor(fresh, v.seat)) {
                toaster.show(c.text)
                playCue(c.sound)
            }
        }
    }
    LaunchedEffect(v.round, v.phase) {
        if (v.phase != "ended") Sfx.bell()
    }
    LaunchedEffect(v.credits) {
        if (v.credits < credits) Sfx.coin()
        credits = v.credits
    }
    LaunchedEffect(sec) {
        if (sec in 1L..10L && !frozen && v.phase != "ended") Sfx.tick()
    }
}

@Composable
fun PauseMenu(
    online: Boolean,
    sound: Boolean,
    onSound: (Boolean) -> Unit,
    onResume: () -> Unit,
    onHelp: () -> Unit,
    onLeave: () -> Unit,
) {
    val s = LocalS.current
    var confirm by remember { mutableStateOf(false) }
    Scrim(onResume) {
        LeatherPanel(Modifier.width(s(300)).swallowTaps()) {
            Column(
                Modifier.padding(s(16)),
                verticalArrangement = Arrangement.spacedBy(s(9)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ArText(
                    if (online) "قائمة اللعبة" else "اللعبة متوقفة مؤقتاً",
                    17, Brass, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif,
                )
                if (!confirm) {
                    WaxButton("تابع التحقيق", onResume, Modifier.fillMaxWidth(), size = 13, height = 38)
                    BrassButton("كيف تُلعب؟", onHelp, Modifier.fillMaxWidth(), size = 12, height = 32)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Toggle(sound, onSound)
                        ArText("المؤثرات الصوتية", 11.5f, Cream, FontWeight.Bold, TextAlign.Right)
                    }
                    BrassButton("غادر التحقيق", { confirm = true }, Modifier.fillMaxWidth(), size = 12, height = 32)
                    if (online) Note("المؤقّت لا يتوقف في اللعب الجماعي.")
                } else {
                    ArText(
                        if (online) "هل تريد مغادرة التحقيق؟ سيحلّ محقق آلي مكانك." else "هل تريد مغادرة التحقيق؟ سيضيع تقدّمك في هذه القضية.",
                        11.5f, Cream, FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth(),
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s(8))) {
                        WaxButton("نعم، غادر", onLeave, Modifier.weight(1f), size = 12, height = 34)
                        BrassButton("ابقَ", { confirm = false }, Modifier.weight(1f), size = 12, height = 34)
                    }
                }
            }
        }
    }
}

@Composable
private fun ClosedOverlay(msg: String, onMenu: () -> Unit) {
    val s = LocalS.current
    Scrim(null) {
        LeatherPanel(Modifier.width(s(320))) {
            Column(
                Modifier.padding(s(16)),
                verticalArrangement = Arrangement.spacedBy(s(10)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ArText("انتهى الاتصال بالغرفة", 16, Brass, FontWeight.Bold, TextAlign.Center, Modifier.fillMaxWidth(), font = Serif)
                ArText(msg, 11.5f, Cream, FontWeight.Normal, TextAlign.Center, Modifier.fillMaxWidth())
                WaxButton("القائمة الرئيسية", onMenu, Modifier.fillMaxWidth(), size = 12.5f, height = 36)
            }
        }
    }
}

/** يعرض جلسة اللعب: الردهة (جماعي) ثم شاشة الجولة أو الاتهام أو الحكم، مع القائمة والإشعارات. */
@Composable
fun PlayHost(model: AppModel, session: GameSession, share: (String) -> Unit) {
    val s = LocalS.current
    val snap by session.snap.collectAsState()
    val lobby by session.lobby.collectAsState()
    val conn by session.connection.collectAsState()
    val toaster = model.toaster
    var help by remember { mutableStateOf(false) }
    val sn = snap
    val closed = conn == "closed"

    LaunchedEffect(toaster) { toaster.run() }
    LaunchedEffect(session) { session.messages.collect { toaster.show(it) } }
    LaunchedEffect(closed) {
        if (closed && session.online && lobby == null && snap == null) {
            model.abort(session.failure ?: "تعذّر الدخول إلى الغرفة.")
        }
    }
    BackHandler(enabled = !closed && (sn == null || sn.v.phase != "ended")) { model.setMenu(!model.menuOpen) }
    BackHandler(enabled = help) { help = false }

    Box(Modifier.fillMaxSize()) {
        if (sn == null) {
            LobbyScreen(
                lobby, conn,
                onSeat = { session.chooseSeat(it) },
                onConfig = { t, d -> session.config(t, d) },
                onStart = { session.start() },
                onShare = { share(lobby?.code ?: "") },
                onLeave = { model.leave() },
            )
        } else {
            val v = sn.v
            val sec = rememberSecondsLeft(sn)
            SessionEffects(v, sec, sn.frozen, toaster)
            LaunchedEffect(v.phase) {
                if (v.phase == "ended") model.recordResult(v.result?.stars ?: 0)
            }
            when (v.phase) {
                "round" -> GameScreen(v, sec * 1000L, model.ui, { session.send(it) }, { toaster.show(it) }, { model.setMenu(true) })
                "accuse" -> AccuseScreen(v, sec * 1000L, model.ui, { session.send(it) }, { toaster.show(it) }, { model.setMenu(true) })
                else -> VerdictScreen(v, session.online, { model.again() }, { model.leave() })
            }
        }
        ToastBar(toaster.text, toaster.visible, Modifier.align(Alignment.TopCenter).padding(top = s(70)))
        if (session.online && !closed && conn != "ok" && sn != null) {
            BrassPlate(Modifier.align(Alignment.TopCenter).padding(top = s(42))) {
                Box(Modifier.padding(horizontal = s(16), vertical = s(5))) {
                    ArText("انقطع الاتصال… تجري إعادة المحاولة", 10.5f, Ink, FontWeight.Bold, TextAlign.Center)
                }
            }
        }
        if (model.menuOpen && !closed) {
            PauseMenu(
                online = session.online,
                sound = model.sound,
                onSound = { model.updateSound(it) },
                onResume = { model.setMenu(false) },
                onHelp = { help = true },
                onLeave = { model.leave() },
            )
        }
        if (help) HelpSheet { help = false }
        if (closed && (sn != null || lobby != null)) {
            ClosedOverlay(session.failure ?: "أُغلقت الغرفة.") { model.leave() }
        }
    }
}
