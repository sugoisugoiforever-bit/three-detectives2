package com.detectives.threefiles

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.SideEffect
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.detectives.threefiles.audio.Sfx
import com.detectives.threefiles.ui.GameRoot

class MainActivity : ComponentActivity() {
    private lateinit var model: AppModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        model = AppModel.get(this)
        Sfx.init(applicationContext)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()
        setContent {
            GameRoot(model) { code -> shareCode(code) }
            // منع لقطات الشاشة في اللعب الجماعي فقط (وثائق كل لاعب سرية عن زميليه)
            val secure = model.session?.online == true
            SideEffect { setSecure(secure) }
        }
    }

    override fun onResume() {
        super.onResume()
        hideBars()
        model.onActivityPause(false)
    }

    override fun onPause() {
        model.onActivityPause(true)
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun setSecure(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun shareCode(code: String) {
        if (code.isEmpty()) return
        val text = "تعال نحقق معاً في لعبة «ثلاثة محققين، ملف واحد»! رمز الغرفة: $code"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "شارك رمز الغرفة"))
    }
}
