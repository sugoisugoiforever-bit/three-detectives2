import type { Env, StateLike, WSLike, WSPairCtor } from "./cf.ts";
import { library } from "./cases.ts";
import { Room, IDLE_MS, type RoomSnapshot, type Sink } from "./room.ts";

const TICK_MS = 500;
const PERSIST_EVERY_MS = 2000;
const CODE_RE = /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{5}$/;
const PID_RE = /^[A-Za-z0-9_-]{8,64}$/;

export type Upgrade = { ok: true; client: WSLike } | { ok: false; status: number; msg: string };

/**
 * كائن دائم واحد لكل غرفة: يحمل `Room` ويشغّل مؤقت اللعبة ويحفظ الحالة ليعيدها بعد أي إعادة تشغيل.
 * لا يستعمل نمط السبات (Hibernation) لأن اللعبة تحتاج مؤقتاً يعمل بلا رسائل (البوتات وانتهاء الجولات).
 */
export class GameRoom {
  private state: StateLike;
  private room: Room | null = null;
  private timer: ReturnType<typeof setInterval> | null = null;
  private seq = 0;
  private dirty = false;
  private lastPersist = 0;
  private persisting = false;
  private pairCtor: WSPairCtor;
  private clock: () => number;
  private autoTimer: boolean;
  private wrap: (client: WSLike) => Response;

  constructor(
    state: StateLike,
    _env: Env,
    opts: { pair?: WSPairCtor; clock?: () => number; timer?: boolean; wrapClient?: (c: WSLike) => Response } = {},
  ) {
    this.state = state;
    this.autoTimer = opts.timer ?? true;
    this.wrap = opts.wrapClient ?? ((c) => new Response(null, { status: 101, webSocket: c } as ResponseInit));
    this.pairCtor = opts.pair ?? ((globalThis as any).WebSocketPair as WSPairCtor);
    this.clock = opts.clock ?? Date.now;
    state.blockConcurrencyWhile(async () => {
      const snap = await state.storage.get<RoomSnapshot>("room");
      if (snap) {
        this.room = Room.restore(snap, library, this.clock());
        if (this.room) this.startTimer();
        else await state.storage.deleteAll();
      }
    });
  }

  /** نقطة الدخول من الـ Worker: `/init` لإنشاء الغرفة، و`/ws` لترقية الاتصال. */
  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url);
    if (url.pathname === "/init") return this.init(url.searchParams.get("code") ?? "");
    if (url.pathname === "/ws") {
      const r = this.upgrade(url.searchParams.get("pid") ?? "", url.searchParams.get("name") ?? "");
      if (!r.ok) return new Response(r.msg, { status: r.status });
      return this.wrap(r.client);
    }
    return new Response("not found", { status: 404 });
  }

  async init(code: string): Promise<Response> {
    if (!CODE_RE.test(code)) return new Response("bad code", { status: 400 });
    if (this.room) return new Response("taken", { status: 409 });
    this.room = new Room(code, library, this.clock());
    this.startTimer();
    await this.persist(true);
    await this.state.storage.setAlarm(this.clock() + IDLE_MS + 1000);
    return new Response("ok", { status: 200 });
  }

  /** يفحص الانضمام ويقبل اتصال WebSocket؛ يعيد 404 (لا غرفة) أو 409 (ممتلئة/بدأت) أو 400. */
  upgrade(pid: string, name: string): Upgrade {
    const room = this.room;
    if (!room) return { ok: false, status: 404, msg: "no such room" };
    if (!PID_RE.test(pid)) return { ok: false, status: 400, msg: "bad pid" };
    if (!room.canJoin(pid)) return { ok: false, status: 409, msg: "full or started" };
    const pair = new this.pairCtor();
    const client = pair[0];
    const server = pair[1];
    server.accept();
    const id = "c" + ++this.seq;
    const sink: Sink = {
      send: (t) => server.send(t),
      close: (c, r) => server.close(c, r),
    };
    const now = this.clock();
    room.join(id, pid, name, sink, now);
    this.dirty = true;
    server.addEventListener("message", (ev) => {
      if (typeof ev.data !== "string") return;
      this.room?.message(id, ev.data, this.clock());
      this.dirty = true;
    });
    const gone = () => {
      this.room?.disconnect(id, this.clock());
      this.dirty = true;
      void this.persist(true);
      void this.state.storage.setAlarm(this.clock() + IDLE_MS + 1000);
    };
    server.addEventListener("close", gone);
    server.addEventListener("error", gone);
    void this.persist(true);
    return { ok: true, client };
  }

  private startTimer(): void {
    if (this.timer !== null || !this.autoTimer) return;
    this.timer = setInterval(() => this.tick(), TICK_MS);
  }

  stopTimer(): void {
    if (this.timer !== null) clearInterval(this.timer);
    this.timer = null;
  }

  tick(): void {
    const room = this.room;
    if (!room) return this.stopTimer();
    const now = this.clock();
    room.tick(now);
    if (room.isIdle(now)) {
      void this.destroy();
      return;
    }
    if (this.dirty && now - this.lastPersist >= PERSIST_EVERY_MS) void this.persist(false);
  }

  private async persist(force: boolean): Promise<void> {
    const room = this.room;
    if (!room || this.persisting) return;
    if (!force && !this.dirty) return;
    this.persisting = true;
    this.dirty = false;
    this.lastPersist = this.clock();
    try {
      await this.state.storage.put("room", room.snapshot());
    } catch {
      this.dirty = true; // نعيد المحاولة في الدورة القادمة
    } finally {
      this.persisting = false;
    }
  }

  /** تُستدعى بعد خمول طويل (حتى لو أُخلي الكائن من الذاكرة): تحذف الغرفة نهائياً. */
  async alarm(): Promise<void> {
    const room = this.room;
    if (!room) {
      await this.state.storage.deleteAll();
      return;
    }
    if (room.isIdle(this.clock())) await this.destroy();
    else await this.state.storage.setAlarm(this.clock() + IDLE_MS + 1000);
  }

  private async destroy(): Promise<void> {
    this.stopTimer();
    const room = this.room;
    this.room = null;
    room?.close("أُغلقت الغرفة بسبب الخمول.");
    await this.state.storage.deleteAlarm();
    await this.state.storage.deleteAll();
  }
}
