import { Game, configFor, type GameState } from "./game.ts";
import { parseAction, type CaseLibrary } from "./model.ts";
import { viewOf } from "./view.ts";

export const LOBBY_GRACE_MS = 20_000;
export const GAME_GRACE_MS = 25_000;
export const IDLE_MS = 10 * 60_000;
const RATE_WINDOW_MS = 4000;
const RATE_MAX = 40;
const MAX_MSG = 4096;

/** مخرج اتصال واحد (WebSocket في الخادم الفعلي، ومحاكٍ في الاختبارات). */
export interface Sink {
  send(text: string): void;
  close(code: number, reason: string): void;
}

interface Slot { pid: string | null; name: string; conn: string | null; graceUntil: number }
interface Conn { id: string; pid: string; sink: Sink; lastLobby: string; lastView: string; stamps: number[] }

export interface RoomSnapshot {
  v: 1;
  code: string;
  theme: string;
  difficulty: number;
  hostPid: string | null;
  started: boolean;
  caseId: string | null;
  seed: number;
  slots: { pid: string | null; name: string }[];
  game: GameState | null;
}

export function cleanName(raw: string | null | undefined): string {
  const s = (raw ?? "").replace(/[\u0000-\u001f\u007f<>]/g, " ").replace(/\s+/g, " ").trim();
  return Array.from(s).slice(0, 18).join("") || "محقق";
}

/**
 * منطق الغرفة بلا أي اعتماد على الشبكة أو المؤقتات: كل دالة تستقبل الزمن `now` صراحةً.
 * الخادم الفعلي (GameRoom) يربطها بالـ WebSocket والمؤقت والتخزين.
 */
export class Room {
  readonly code: string;
  theme = "";
  difficulty = 1;
  hostPid: string | null = null;
  started = false;
  game: Game | null = null;
  caseId: string | null = null;
  seed = 0;
  slots: Slot[] = [0, 1, 2].map(() => ({ pid: null, name: "", conn: null, graceUntil: 0 }));
  conns = new Map<string, Conn>();
  lastActive: number;
  private lib: CaseLibrary;
  private rand: () => number;

  constructor(code: string, lib: CaseLibrary, now: number, rand: () => number = Math.random) {
    this.code = code;
    this.lib = lib;
    this.rand = rand;
    this.lastActive = now;
  }

  // ───────── الانضمام والمغادرة ─────────

  private slotOf(pid: string): number {
    return this.slots.findIndex((s) => s.pid === pid);
  }

  /** هل يُقبل هذا اللاعب؟ (عضو سابق، أو غرفة لم تبدأ وفيها مقعد شاغر). */
  canJoin(pid: string): boolean {
    if (this.slotOf(pid) >= 0) return true;
    return !this.started && this.slots.some((s) => s.pid === null);
  }

  join(id: string, pid: string, rawName: string, sink: Sink, now: number): boolean {
    if (!this.canJoin(pid)) return false;
    this.lastActive = now;
    let i = this.slotOf(pid);
    if (i >= 0) {
      const old = this.slots[i].conn;
      if (old !== null) this.dropConn(old, 4000, "replaced");
      if (!this.started) this.slots[i].name = cleanName(rawName);
    } else {
      i = this.slots.findIndex((s) => s.pid === null);
      this.slots[i] = { pid, name: cleanName(rawName), conn: null, graceUntil: 0 };
    }
    const slot = this.slots[i];
    slot.conn = id;
    slot.graceUntil = 0;
    if (this.hostPid === null || this.slotOf(this.hostPid) < 0) this.hostPid = pid;
    this.conns.set(id, { id, pid, sink, lastLobby: "", lastView: "", stamps: [] });
    const g = this.game;
    if (g) {
      g.seats[i].connected = true;
      if (g.seats[i].bot) g.release(i, slot.name);
    }
    this.flush(now);
    return true;
  }

  private dropConn(id: string, code: number, reason: string): void {
    const c = this.conns.get(id);
    if (!c) return;
    this.conns.delete(id);
    try { c.sink.close(code, reason); } catch { /* مغلق أصلاً */ }
  }

  /** انقطع اتصال (لا مغادرة صريحة): نمهل صاحبه قبل أن يحلّ بوت مكانه. */
  disconnect(id: string, now: number): void {
    const c = this.conns.get(id);
    if (!c) return;
    this.conns.delete(id);
    const i = this.slotOf(c.pid);
    if (i >= 0 && this.slots[i].conn === id) {
      this.slots[i].conn = null;
      this.slots[i].graceUntil = now + (this.started ? GAME_GRACE_MS : LOBBY_GRACE_MS);
      if (this.game) this.game.seats[i].connected = false;
    }
    this.lastActive = now;
    this.flush(now);
  }

  private leave(c: Conn, now: number): void {
    const i = this.slotOf(c.pid);
    this.conns.delete(c.id);
    if (i >= 0) {
      const slot = this.slots[i];
      if (this.game) this.game.takeover(i, slot.name, now);
      this.slots[i] = { pid: null, name: "", conn: null, graceUntil: 0 };
      this.fixHost();
    }
    try { c.sink.close(1000, "left"); } catch { /* مغلق أصلاً */ }
    this.flush(now);
  }

  private fixHost(): void {
    if (this.hostPid !== null && this.slotOf(this.hostPid) >= 0) return;
    const live = this.slots.find((s) => s.pid !== null && s.conn !== null) ?? this.slots.find((s) => s.pid !== null);
    this.hostPid = live ? live.pid : null;
  }

  // ───────── الرسائل الواردة ─────────

  message(id: string, text: string, now: number): void {
    const c = this.conns.get(id);
    if (!c) return;
    this.lastActive = now;
    c.stamps = c.stamps.filter((t) => now - t < RATE_WINDOW_MS);
    c.stamps.push(now);
    if (c.stamps.length > RATE_MAX) return this.err(c, "رسائل كثيرة جداً، تمهّل");
    if (text.length > MAX_MSG) return this.err(c, "رسالة كبيرة جداً");
    let m: any;
    try { m = JSON.parse(text); } catch { return this.err(c, "رسالة غير مفهومة"); }
    if (m === null || typeof m !== "object") return this.err(c, "رسالة غير مفهومة");
    const seat = this.slotOf(c.pid);
    if (seat < 0) return;
    switch (m.t) {
      case "cfg": return this.cfg(c, m, now);
      case "seat": return this.moveSeat(c, seat, m.seat, now);
      case "start": return this.start(c, now);
      case "act": return this.act(c, seat, m.a, now);
      case "again": return this.again(c, now);
      case "leave": return this.leave(c, now);
      default: return this.err(c, "أمر غير معروف");
    }
  }

  private err(c: Conn, m: string): void {
    this.send(c, { t: "err", m });
  }

  private cfg(c: Conn, m: any, now: number): void {
    if (this.started) return this.err(c, "بدأت اللعبة بالفعل");
    if (c.pid !== this.hostPid) return this.err(c, "المضيف وحده يغيّر الإعدادات");
    const theme = typeof m.theme === "string" ? m.theme : "";
    if (theme !== "" && !this.lib.hasTheme(theme)) return this.err(c, "سمة غير معروفة");
    const d = m.difficulty;
    if (!Number.isInteger(d) || d < 0 || d > 2) return this.err(c, "مستوى صعوبة غير صالح");
    this.theme = theme;
    this.difficulty = d;
    this.flush(now);
  }

  private moveSeat(c: Conn, from: number, to: unknown, now: number): void {
    if (this.started) return this.err(c, "بدأت اللعبة بالفعل");
    if (!Number.isInteger(to) || (to as number) < 0 || (to as number) > 2) return this.err(c, "مقعد غير صالح");
    const t = to as number;
    if (t === from) return;
    if (this.slots[t].pid !== null) return this.err(c, "هذا المقعد محجوز");
    this.slots[t] = this.slots[from];
    this.slots[from] = { pid: null, name: "", conn: null, graceUntil: 0 };
    this.flush(now);
  }

  private start(c: Conn, now: number): void {
    if (this.started) return;
    if (c.pid !== this.hostPid) return this.err(c, "المضيف وحده يبدأ اللعبة");
    this.seed = Math.floor(this.rand() * 0x7fffffff);
    const cs = this.lib.pick(this.theme === "" ? null : this.theme, this.seed);
    this.caseId = cs.id;
    const humans = [0, 1, 2].filter((i) => this.slots[i].pid !== null);
    const g = new Game(cs, configFor(this.difficulty), this.seed >>> 7, now, humans);
    for (const i of humans) {
      g.setSeat(i, this.slots[i].name, false);
      if (this.slots[i].conn === null) g.seats[i].connected = false;
    }
    this.game = g;
    this.started = true;
    this.flush(now);
  }

  private act(c: Conn, seat: number, raw: unknown, now: number): void {
    const g = this.game;
    if (!this.started || !g) return this.err(c, "اللعبة لم تبدأ بعد");
    const a = parseAction(raw);
    if (a === null) return this.err(c, "حركة غير صالحة");
    const e = g.handle(seat, a, now);
    if (e !== null) this.err(c, e);
    this.flush(now);
  }

  private again(c: Conn, now: number): void {
    const g = this.game;
    if (!this.started || !g || g.phase !== "ended") return;
    this.game = null;
    this.started = false;
    this.caseId = null;
    for (let i = 0; i < 3; i++) {
      const s = this.slots[i];
      if (s.pid !== null && s.conn === null) this.slots[i] = { pid: null, name: "", conn: null, graceUntil: 0 };
    }
    this.fixHost();
    for (const cc of this.conns.values()) cc.lastView = "";
    this.flush(now);
  }

  // ───────── الزمن ─────────

  tick(now: number): void {
    for (let i = 0; i < 3; i++) {
      const s = this.slots[i];
      if (s.pid === null || s.conn !== null || s.graceUntil === 0 || now < s.graceUntil) continue;
      s.graceUntil = 0;
      if (this.started && this.game) {
        this.game.takeover(i, s.name, now);
      } else if (!this.started) {
        this.slots[i] = { pid: null, name: "", conn: null, graceUntil: 0 };
        this.fixHost();
      }
    }
    if (this.game) this.game.tick(now);
    this.flush(now);
  }

  isIdle(now: number): boolean {
    return this.conns.size === 0 && now - this.lastActive >= IDLE_MS;
  }

  /** يغلق كل الاتصالات برسالة نهائية (إغلاق الغرفة). */
  close(msg: string): void {
    for (const c of [...this.conns.values()]) {
      this.send(c, { t: "closed", m: msg });
      this.dropConn(c.id, 1000, "closed");
    }
  }

  // ───────── الإرسال ─────────

  private send(c: Conn, o: unknown): void {
    try { c.sink.send(JSON.stringify(o)); } catch { /* سيُكتشف الانقطاع من جهة الشبكة */ }
  }

  private lobbyFor(c: Conn): unknown {
    const seat = this.slotOf(c.pid);
    const g = this.game;
    return {
      t: "lobby", code: this.code, seat, host: c.pid === this.hostPid, theme: this.theme, difficulty: this.difficulty,
      started: this.started,
      seats: this.slots.map((s, i) => ({
        seat: i, name: g ? g.seats[i].name : s.name, bot: g ? g.seats[i].bot : s.pid === null, connected: s.conn !== null,
      })),
    };
  }

  /** يرسل لكل اتصال ما تغيّر فقط (الردهة، ثم عرض اللاعب إن بدأت اللعبة). */
  flush(now: number): void {
    const g = this.game;
    for (const c of [...this.conns.values()]) {
      const lobby = JSON.stringify(this.lobbyFor(c));
      if (lobby !== c.lastLobby) {
        c.lastLobby = lobby;
        c.sink.send(lobby);
      }
      if (!g || !this.started) continue;
      const seat = this.slotOf(c.pid);
      if (seat < 0) continue;
      const v = viewOf(g, seat, now);
      const key = JSON.stringify({ ...v, endsInMs: 0 });
      if (key !== c.lastView) {
        c.lastView = key;
        c.sink.send(JSON.stringify({ t: "view", v }));
      }
    }
  }

  // ───────── الحفظ والاستعادة ─────────

  snapshot(): RoomSnapshot {
    return {
      v: 1, code: this.code, theme: this.theme, difficulty: this.difficulty, hostPid: this.hostPid,
      started: this.started, caseId: this.caseId, seed: this.seed,
      slots: this.slots.map((s) => ({ pid: s.pid, name: s.name })),
      game: this.game ? this.game.toState() : null,
    };
  }

  static restore(s: RoomSnapshot, lib: CaseLibrary, now: number, rand: () => number = Math.random): Room | null {
    const r = new Room(s.code, lib, now, rand);
    r.theme = s.theme;
    r.difficulty = s.difficulty;
    r.hostPid = s.hostPid;
    r.started = s.started;
    r.caseId = s.caseId;
    r.seed = s.seed;
    for (let i = 0; i < 3; i++) {
      const p = s.slots[i];
      r.slots[i] = { pid: p.pid, name: p.name, conn: null, graceUntil: p.pid === null ? 0 : now + (s.started ? GAME_GRACE_MS : LOBBY_GRACE_MS) };
    }
    if (s.started) {
      const cs = s.caseId === null ? null : lib.find(s.caseId);
      if (cs === null || s.game === null) return null;
      r.game = new Game(cs, s.game.cfg, s.seed >>> 7, now, [], s.game);
      for (let i = 0; i < 3; i++) if (r.slots[i].pid !== null) r.game.seats[i].connected = false;
    }
    return r;
  }
}
