// ما يراه مقعدٌ واحد من اللعبة (لا سرّ لا يعرفه صاحبه). نقل حرفي لـ Views.kt؛ الناتج هو نفس JSON الذي يقرؤه العميل.
import type { Game } from "./game.ts";
import { QIDS, ROLE_IDS, type PView } from "./model.ts";

export function viewOf(g: Game, seat: number, now: number): PView {
  const c = g.c;
  const me = g.seats[seat];
  const docs = [...me.visible].map((id) => {
    const d = c.docById.get(id)!;
    const own = d.owner === seat;
    return {
      id: d.id, owner: d.owner, round: d.round, kind: d.kind, title: d.title, stamp: d.stamp, serial: d.serial,
      lines: d.lines, topics: d.topics,
      from: own ? -1 : (me.from.get(id) ?? d.owner),
      // لا يعرف المستلِم مع من شاركها المرسِل بعده؛ هذا ما تكشفه قدرة الاعتراض
      copies: own ? [...(g.copies.get(id) ?? [])].sort((a, b) => a - b) : [d.owner, seat].sort((a, b) => a - b),
      audit: seat === 0 ? (g.audits.get(id) ?? null) : null,
    };
  });
  const seen = new Set<string>();
  for (const d of docs) for (const t of d.topics) seen.add(t);
  const topics = c.topics.filter((t) => t.kind === "person" || t.kind === "place" || seen.has(t.id));

  const requests = g.requests.map((r) => {
    const t = c.topicById.get(r.topic)!;
    const matches = r.from === seat ? [] : [...me.visible].filter((id) => {
      const d = c.docById.get(id)!;
      return d.owner === seat && d.topics.includes(r.topic) && !g.seats[r.from].visible.has(id);
    });
    return { id: r.id, from: r.from, topic: r.topic, label: t.label, round: r.round, matches, mine: r.from === seat };
  });
  const players = g.seats.map((s, i) => ({
    seat: i, role: ROLE_IDS[i], name: s.name, bot: s.bot, connected: s.connected, ready: s.ready,
    moveUsed: s.moveUsed, abilityUsed: s.abilityUsed,
  }));
  const citedIds = new Set<string>();
  for (const q of QIDS) for (const d of g.cites.get(q)!) if (d !== null) citedIds.add(d);
  const cited = [...citedIds].map((id) => {
    const d = c.docById.get(id)!;
    return { id: d.id, title: d.title, owner: d.owner };
  });
  const answers: Record<string, number | null> = {};
  for (const [k, v] of g.answers) answers[k] = v;
  const cites: Record<string, (string | null)[]> = {};
  for (const q of QIDS) cites[q] = [...g.cites.get(q)!];
  return {
    phase: g.phase, round: g.round, window: g.window,
    endsInMs: g.phase === "ended" ? 0 : Math.max(0, g.phaseEndsAt - now),
    credits: g.credits, creditsMax: g.cfg.credits, seat, players,
    info: {
      id: c.id, theme: c.theme, title: c.title, brief: c.brief, org: c.org, date: c.date, window: c.window,
      persons: c.persons, questions: c.questions,
    },
    docs, topics,
    feed: g.feed.filter((n) => n.to === -1 || n.to === seat),
    requests, interceptArmed: seat === 2 ? g.interceptArmed : false,
    draft: {
      answers, cites, approvals: [...g.approvals], valid: g.draftValid(), required: g.required(), window: g.window,
    },
    result: g.result,
    cited,
  };
}

/** JSON قانوني (مفاتيح مرتّبة) للمقارنة بين نسختي المحرك. */
export function canon(v: unknown): string {
  if (v === null || v === undefined) return "null";
  if (typeof v === "number") return String(v);
  if (typeof v === "boolean") return v ? "true" : "false";
  if (typeof v === "string") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(canon).join(",") + "]";
  const o = v as Record<string, unknown>;
  return "{" + Object.keys(o).sort().map((k) => JSON.stringify(k) + ":" + canon(o[k])).join(",") + "}";
}

/** تجزئة FNV-1a على وحدات UTF-16 (تُحسب بالطريقة نفسها في Kotlin). */
export function fnv(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}
