import data from "./cases.data.ts";
import { CaseLibrary } from "./model.ts";

export const library = new CaseLibrary(data);
