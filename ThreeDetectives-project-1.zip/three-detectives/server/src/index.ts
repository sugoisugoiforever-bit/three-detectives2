import type { Env } from "./cf.ts";
import { library } from "./cases.ts";

export { GameRoom } from "./room-do.ts";

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const CODE_RE = /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{5}$/;
const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, OPTIONS",
  "access-control-allow-headers": "content-type",
};

function json(o: unknown, status = 200): Response {
  return new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json; charset=utf-8", ...CORS } });
}

export function newCode(rand: (n: number) => number): string {
  let s = "";
  for (let i = 0; i < 5; i++) s += ALPHABET[rand(ALPHABET.length)];
  return s;
}

function cryptoRand(n: number): number {
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return a[0] % n;
}

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    const path = url.pathname;
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

    if (path === "/api/ping" && req.method === "GET") {
      return json({ ok: true, service: "detectives", v: 1, cases: library.size });
    }

    if (path === "/api/create" && req.method === "POST") {
      for (let attempt = 0; attempt < 8; attempt++) {
        const code = newCode(cryptoRand);
        const stub = env.ROOMS.get(env.ROOMS.idFromName(code));
        const r = await stub.fetch("https://room/init?code=" + code, { method: "POST" });
        if (r.status === 200) return json({ code });
        if (r.status !== 409) break;
      }
      return json({ error: "تعذّر إنشاء الغرفة، حاول مجدداً" }, 503);
    }

    const m = /^\/ws\/([^/]+)$/.exec(path);
    if (m && req.method === "GET") {
      const code = decodeURIComponent(m[1]).toUpperCase();
      if (!CODE_RE.test(code)) return new Response("no such room", { status: 404 });
      if ((req.headers.get("upgrade") ?? "").toLowerCase() !== "websocket") return new Response("expected websocket", { status: 426 });
      const stub = env.ROOMS.get(env.ROOMS.idFromName(code));
      const q = new URLSearchParams({ pid: url.searchParams.get("pid") ?? "", name: url.searchParams.get("name") ?? "" });
      return stub.fetch(new Request("https://room/ws?" + q.toString(), req));
    }

    if (path === "/" || path === "") {
      return new Response("Three Detectives game server (detectives) — OK\n", { status: 200, headers: { "content-type": "text/plain; charset=utf-8" } });
    }
    return json({ error: "not found" }, 404);
  },
};
