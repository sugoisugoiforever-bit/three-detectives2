// بوتات قائمة على القواعد: نقل حرفي لـ Bots.kt (نفس الترتيب ونفس استهلاك المولّد العشوائي).
import { type Doc, QIDS, QUESTION_AR, ROLE_AR } from "./model.ts";
import type { Game, Req, Seat } from "./game.ts";

export interface BotState {
  abilityRound: number[];
  guessAt: number[];
  overrides: [string, number][];
}

const byValueDesc = (value: (id: string) => number) => (a: string, b: string) => value(b) - value(a);

export class BotDriver {
  private abilityRound: number[];
  private guessAt = [0, 0, 0];
  private overrides = new Map<string, number>();

  private g: Game;

  constructor(g: Game) {
    this.g = g;
    this.abilityRound = [0, 1, 2].map(() => 1 + g.rng.nextInt(3));
  }

  toState(): BotState {
    return { abilityRound: [...this.abilityRound], guessAt: [...this.guessAt], overrides: [...this.overrides] };
  }

  loadState(s: BotState): void {
    this.abilityRound = [...s.abilityRound];
    this.guessAt = [...s.guessAt];
    this.overrides = new Map(s.overrides);
  }

  private delay(minMs: number, maxMs: number): number {
    const span = Math.max(Math.trunc(maxMs - minMs), 1);
    return Math.trunc((minMs + this.g.rng.nextInt(span)) * this.g.cfg.botPace);
  }

  private value = (id: string): number => {
    let sum = 0;
    for (const cl of this.g.c.claims) if (cl.needs.includes(id)) sum += Math.abs(cl.w);
    return sum;
  };

  private skilled(): boolean {
    return this.g.rng.nextInt(100) < Math.trunc(this.g.cfg.botSkill * 100);
  }

  // ───────── جدولة ─────────
  onRoundStart(now: number): void {
    for (let i = 0; i <= 2; i++) {
      const s = this.g.seats[i];
      if (!s.bot) continue;
      s.nextAt = now + this.delay(6_000, 25_000);
      s.readyAt = Infinity;
    }
  }

  onAccuseStart(now: number): void {
    this.overrides.clear();
    for (let i = 0; i <= 2; i++) {
      const s = this.g.seats[i];
      s.accuseAt = now + this.delay(4_000, 16_000);
      this.guessAt[i] = s.accuseAt + this.delay(25_000, 45_000);
    }
  }

  /** يُستدعى عند تحويل مقعد بشري إلى بوت أثناء اللعب. */
  adopt(i: number, now: number): void {
    const s = this.g.seats[i];
    if (this.g.phase === "round") {
      s.nextAt = now + this.delay(4_000, 12_000);
      s.readyAt = Infinity;
    } else if (this.g.phase === "accuse") {
      s.accuseAt = now + this.delay(3_000, 8_000);
      this.guessAt[i] = s.accuseAt + this.delay(25_000, 45_000);
    }
  }

  /** وصل سؤال جديد: البوتات التي لم تستهلك حركتها تنتبه له. */
  onRequest(now: number): void {
    for (let i = 0; i <= 2; i++) {
      const s = this.g.seats[i];
      if (!s.bot || s.moveUsed) continue;
      if (this.pendingReply(i) === null) continue;
      s.ready = false;
      s.readyAt = Infinity;
      s.nextAt = Math.min(s.nextAt, now + this.delay(2_000, 7_000));
    }
  }

  onTick(now: number): void {
    for (let i = 0; i <= 2; i++) {
      const s = this.g.seats[i];
      if (!s.bot) continue;
      if (this.g.phase === "round") this.roundTick(i, s, now);
      else if (this.g.phase === "accuse") this.accuseTick(i, s, now);
      else return;
      if ((this.g.phase as string) === "ended") return; // قد تغيّر الطور داخل الاستدعاء
    }
  }

  // ───────── الجولة ─────────
  private roundTick(i: number, s: Seat, now: number): void {
    if (s.ready) return;
    if (now >= s.nextAt) {
      let acted = false;
      if (!s.moveUsed) acted = this.act(i, now);
      this.useAbility(i, now);
      if (acted || s.moveUsed) {
        s.nextAt = Infinity;
        s.readyAt = now + this.delay(3_000, 9_000);
      } else {
        s.nextAt = now + 15_000;
        if (s.readyAt === Infinity) s.readyAt = now + this.delay(4_000, 10_000);
      }
    }
    if (now >= s.readyAt && !s.ready) this.g.handle(i, { a: "ready", on: true }, now);
  }

  /** أقدم سؤال يمكن لهذا البوت الردّ عليه: (السؤال، وثائقه المطابقة مرتبةً بالأهمية). */
  private pendingReply(i: number): { r: Req; docs: Doc[] } | null {
    const g = this.g;
    const s = g.seats[i];
    for (const r of g.requests) {
      if (r.from === i || s.answered.has(r.id)) continue;
      const ids = [...s.visible].filter((id) => {
        const d = g.c.docById.get(id)!;
        return d.owner === i && d.topics.includes(r.topic) && !g.seats[r.from].visible.has(id);
      });
      ids.sort(byValueDesc(this.value));
      if (ids.length > 0) return { r, docs: ids.map((id) => g.c.docById.get(id)!) };
    }
    return null;
  }

  private act(i: number, now: number): boolean {
    const g = this.g;
    const s = g.seats[i];
    // 1) الردّ على سؤال زميل بمشاركة الوثيقة الأنسب
    const rep = this.pendingReply(i);
    if (rep !== null && g.credits >= 1) {
      const { r, docs } = rep;
      const pick = this.skilled() || docs.length === 1 ? docs[0] : docs[g.rng.nextInt(docs.length)];
      const err = g.handle(i, { a: "share", doc: pick.id, to: r.from }, now);
      if (err === null) return true;
      s.answered.add(r.id);
    }
    // 2) سؤال عن رمزٍ يظهر في وثيقة واحدة فقط من وثائقي
    const tok = this.pickTopic(i);
    if (tok !== null) return g.handle(i, { a: "request", topic: tok }, now) === null;
    return false;
  }

  private pickTopic(i: number): string | null {
    const g = this.g;
    const s = g.seats[i];
    const asked = new Set(g.requests.map((r) => r.topic));
    const keyCount = new Map<string, number>();
    const personCount = new Map<string, number>();
    const best = new Map<string, number>();
    for (const id of s.visible) {
      const d = g.c.docById.get(id)!;
      const v = this.value(id);
      for (const t of d.topics) {
        const kind = g.c.topicById.get(t)!.kind;
        if (kind === "key") {
          keyCount.set(t, (keyCount.get(t) ?? 0) + 1);
          best.set(t, Math.max(best.get(t) ?? 0, v));
        } else if (kind === "person" && v > 0) {
          personCount.set(t, (personCount.get(t) ?? 0) + 1);
          best.set(t, Math.max(best.get(t) ?? 0, v));
        }
      }
    }
    // الرموز أولاً، ثم الأشخاص الواردون في وثائق ذات صلة
    for (const counts of [keyCount, personCount]) {
      const cands = [...counts].filter(([k, n]) => n === 1 && !asked.has(k)).map(([k]) => k);
      cands.sort((a, b) => {
        const d = (best.get(b) ?? 0) - (best.get(a) ?? 0);
        if (d !== 0) return d;
        return a < b ? -1 : a > b ? 1 : 0;
      });
      if (cands.length === 0) continue;
      return this.skilled() ? cands[0] : cands[g.rng.nextInt(cands.length)];
    }
    return null;
  }

  private useAbility(i: number, now: number): void {
    const g = this.g;
    const s = g.seats[i];
    if (s.abilityUsed || g.round < this.abilityRound[i]) return;
    if (i === 0) {
      let bestId: string | null = null;
      let bestV = -Infinity;
      for (const id of s.visible) {
        if (g.audits.has(id)) continue;
        const v = this.value(id);
        if (v > bestV) {
          bestV = v;
          bestId = id;
        }
      }
      if (bestId === null) return;
      g.handle(0, { a: "ability", arg: bestId }, now);
    } else {
      g.handle(i, { a: "ability", arg: null }, now);
    }
  }

  // ───────── الاتهام ─────────
  private accuseTick(i: number, s: Seat, now: number): void {
    const g = this.g;
    if (now < s.accuseAt) return;
    s.accuseAt = now + this.delay(3_000, 7_000);
    for (const q of QIDS) {
      if (g.phase !== "accuse") return;
      this.fillAnswer(i, q, now);
      const cur = g.answers.get(q);
      if (cur !== null && cur !== undefined) this.fillCites(i, q, cur, now);
    }
    if (g.phase === "accuse") this.decide(i, now);
  }

  private fillAnswer(i: number, q: string, now: number): void {
    const g = this.g;
    const s = g.seats[i];
    const cur = g.answers.get(q) ?? null;
    const bel = g.belief(s.visible, q);
    if (cur === null) {
      const pick = bel ?? (now >= this.guessAt[i] ? g.rng.nextInt(g.c.questions.find((x) => x.id === q)!.options.length) : null);
      if (pick !== null) g.handle(i, { a: "answer", q, opt: pick }, now);
    } else if (bel !== null && bel !== cur) {
      const by = g.answerBy.get(q);
      const n = this.overrides.get(q) ?? 0;
      if (by !== undefined && g.seats[by].bot && n < 2) {
        this.overrides.set(q, n + 1);
        g.handle(i, { a: "answer", q, opt: bel }, now);
      }
    }
  }

  private fillCites(i: number, q: string, opt: number, now: number): void {
    const g = this.g;
    const s = g.seats[i];
    const cur = g.cites.get(q)!;
    if (cur[0] !== null && cur[1] !== null) return;
    // الوثائق الداعمة للإجابة المختارة حسب وزن الأدلة، ثم الأهم فالأهم
    const sup = g.c.claims
      .filter((cl) => cl.q === q && cl.opt === opt && cl.w > 0 && cl.needs.every((n) => s.visible.has(n)))
      .sort((a, b) => b.w - a.w)
      .flatMap((cl) => cl.needs);
    const rest = [...s.visible].sort(byValueDesc(this.value));
    const order = [...new Set([...sup, ...rest])].filter((id) => s.visible.has(id));
    for (let slot = 0; slot <= 1; slot++) {
      if (cur[slot] !== null) continue;
      const other = cur[1 - slot];
      const otherOwner = other !== null ? g.c.docById.get(other)!.owner : null;
      const pick = order.find((id) => id !== other && (otherOwner === null || g.c.docById.get(id)!.owner !== otherOwner));
      if (pick === undefined) return;
      g.handle(i, { a: "cite", q, slot, doc: pick }, now);
    }
  }

  private decide(i: number, now: number): void {
    const g = this.g;
    const s = g.seats[i];
    if (g.approvals[i] || !g.draftValid()) return;
    for (const q of QIDS) {
      const bel = g.belief(s.visible, q);
      const cur = g.answers.get(q) ?? null;
      if (bel !== null && bel !== cur) {
        const key = `${q}:${cur}`;
        if (!s.objected.has(key)) {
          s.objected.add(key);
          g.note("accuse", i, -1, `${ROLE_AR[i]} يعترض على إجابة «${QUESTION_AR[q]}»`);
        }
        return;
      }
    }
    // في النافذة الأخيرة لا تحسم البوتات القرار قبل أن يقول البشر كلمتهم
    if (g.window === 2) {
      const humans = [0, 1, 2].filter((k) => !g.seats[k].bot && g.seats[k].connected);
      const humansDone = humans.every((k) => g.approvals[k]);
      const remaining = g.phaseEndsAt - now;
      if (humans.length > 0 && !humansDone && remaining > 30_000) return;
    }
    g.handle(i, { a: "approve", on: true }, now);
  }
}
