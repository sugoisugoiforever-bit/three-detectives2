// نموذج القضية والأنواع المشتركة. يطابق engine/src/main/kotlin/game/Model.kt حرفياً (نفس أسماء الحقول في JSON).

export const ROLE_IDS = ["analyst", "field", "comms"];
export const ROLE_AR = ["المحلل المالي", "المحقق الميداني", "خبير الاتصالات"];
export const ABILITY_AR = ["تدقيق", "مداهمة", "اعتراض"];
export const QIDS = ["who", "how", "why"];
export const QUESTION_AR: Record<string, string> = { who: "من؟", how: "كيف؟", why: "لماذا؟" };
export const KIND_AR: Record<string, string> = {
  bank: "كشف حساب مصرفي", invoice: "فاتورة", report: "تقرير ميداني", witness: "إفادة شاهد",
  calls: "سجل مكالمات", chat: "محادثة نصية", access: "سجل دخول ومراقبة", memo: "مذكرة تدقيق",
};

export interface Person { id: string; name: string; first: string; g: string; job: string; portrait: number }
export interface Opt { id: string; label: string; sub: string | null; person: string | null }
export interface Question { id: string; prompt: string; options: Opt[] }
export interface Topic { id: string; kind: string; label: string }
export interface Line { t: string; k?: string; v?: string; c?: string[]; who?: string; time?: string }
export interface Doc {
  id: string; owner: number; round: number; kind: string; title: string; stamp: string; serial: number;
  lines: Line[]; topics: string[]; rel: string;
}
export interface Claim { q: string; opt: number; w: number; needs: string[] }

export interface Case {
  id: string; theme: string; title: string; brief: string; org: string; date: string; window: string[];
  persons: Person[]; questions: Question[]; topics: Topic[]; docs: Doc[];
  truth: Record<string, number>; claims: Claim[]; proof: Record<string, string[][]>;
  docById: Map<string, Doc>; topicById: Map<string, Topic>;
}

export function parseCase(m: any): Case {
  const persons: Person[] = m.persons.map((p: any) => ({
    id: p.id, name: p.name, first: p.first, g: p.g, job: p.job, portrait: p.portrait,
  }));
  const questions: Question[] = m.questions.map((q: any) => ({
    id: q.id, prompt: q.prompt,
    options: q.options.map((o: any) => ({ id: o.id, label: o.label, sub: o.sub ?? null, person: o.person ?? null })),
  }));
  const topics: Topic[] = m.topics.map((t: any) => ({ id: t.id, kind: t.kind, label: t.label }));
  const docs: Doc[] = m.docs.map((d: any) => ({
    id: d.id, owner: ROLE_IDS.indexOf(d.owner), round: d.round, kind: d.kind, title: d.title,
    stamp: d.stamp, serial: d.serial, lines: d.lines, topics: d.topics, rel: d.rel,
  }));
  const claims: Claim[] = m.claims.map((c: any) => ({ q: c.q, opt: c.opt, w: c.w, needs: c.needs }));
  return {
    id: m.id, theme: m.theme, title: m.title, brief: m.brief, org: m.org, date: m.date, window: m.window,
    persons, questions, topics, docs, truth: m.truth, claims, proof: m.proof,
    docById: new Map(docs.map((d) => [d.id, d])),
    topicById: new Map(topics.map((t) => [t.id, t])),
  };
}

export function optionCount(c: Case, q: string): number {
  return questionOf(c, q).options.length;
}

export function questionOf(c: Case, q: string): Question {
  const r = c.questions.find((x) => x.id === q);
  if (!r) throw new Error("no question " + q);
  return r;
}

/** مكتبة قضايا: مصفوفة JSON. تُحلَّل القضية عند الطلب فقط (مثل نسخة Kotlin). */
export class CaseLibrary {
  private raw: any[];
  constructor(raw: any[]) {
    this.raw = raw;
  }
  get size(): number { return this.raw.length; }
  themeNames(): string[] { return [...new Set(this.raw.map((c) => c.theme as string))]; }
  pick(theme: string | null, seed: number): Case {
    const idx: number[] = [];
    for (let i = 0; i < this.raw.length; i++) if (theme === null || this.raw[i].theme === theme) idx.push(i);
    if (idx.length === 0) throw new Error("no cases for theme " + theme);
    const i = idx[((seed % idx.length) + idx.length) % idx.length];
    return parseCase(this.raw[i]);
  }
  get(index: number): Case { return parseCase(this.raw[index]); }
  find(id: string): Case | null {
    const r = this.raw.find((c) => c.id === id);
    return r ? parseCase(r) : null;
  }
  hasTheme(theme: string): boolean { return this.raw.some((c) => c.theme === theme); }
}

// ───────────── الحركات ─────────────

export type Action =
  | { a: "share"; doc: string; to: number }
  | { a: "request"; topic: string }
  | { a: "template"; tpl: string; slots: Record<string, string> }
  | { a: "ability"; arg: string | null }
  | { a: "ready"; on: boolean }
  | { a: "answer"; q: string; opt: number | null }
  | { a: "cite"; q: string; slot: number; doc: string | null }
  | { a: "approve"; on: boolean };

const isInt = (x: unknown): x is number => typeof x === "number" && Number.isInteger(x);
const isStr = (x: unknown): x is string => typeof x === "string";
const strOrNull = (x: unknown): string | null | undefined => (x === null || x === undefined ? null : isStr(x) ? x : undefined);

/** يتحقق صارماً من حركة واردة من الشبكة؛ يعيد null إن كانت معطوبة. */
export function parseAction(m: unknown): Action | null {
  if (typeof m !== "object" || m === null) return null;
  const o = m as Record<string, unknown>;
  switch (o.a) {
    case "share": return isStr(o.doc) && isInt(o.to) ? { a: "share", doc: o.doc, to: o.to } : null;
    case "request": return isStr(o.topic) ? { a: "request", topic: o.topic } : null;
    case "template": {
      if (!isStr(o.tpl) || typeof o.slots !== "object" || o.slots === null) return null;
      const slots: Record<string, string> = {};
      for (const [k, v] of Object.entries(o.slots as Record<string, unknown>)) {
        if (!isStr(v)) return null;
        slots[k] = v;
      }
      return { a: "template", tpl: o.tpl, slots };
    }
    case "ability": {
      const arg = strOrNull(o.arg);
      return arg === undefined ? null : { a: "ability", arg };
    }
    case "ready": return typeof o.on === "boolean" ? { a: "ready", on: o.on } : null;
    case "answer": {
      if (!isStr(o.q)) return null;
      if (o.opt === null || o.opt === undefined) return { a: "answer", q: o.q, opt: null };
      return isInt(o.opt) ? { a: "answer", q: o.q, opt: o.opt } : null;
    }
    case "cite": {
      const doc = strOrNull(o.doc);
      return isStr(o.q) && isInt(o.slot) && doc !== undefined ? { a: "cite", q: o.q, slot: o.slot, doc } : null;
    }
    case "approve": return typeof o.on === "boolean" ? { a: "approve", on: o.on } : null;
    default: return null;
  }
}

// ───────────── ما يراه اللاعب ─────────────

export interface Notice { id: number; round: number; kind: string; from: number; to: number; text: string; doc: string | null }
export interface PProof { id: string; title: string; owner: number }
export interface PView {
  phase: string; round: number; window: number; endsInMs: number; credits: number; creditsMax: number; seat: number;
  players: { seat: number; role: string; name: string; bot: boolean; connected: boolean; ready: boolean; moveUsed: boolean; abilityUsed: boolean }[];
  info: {
    id: string; theme: string; title: string; brief: string; org: string; date: string; window: string[];
    persons: Person[]; questions: Question[];
  };
  docs: {
    id: string; owner: number; round: number; kind: string; title: string; stamp: string; serial: number;
    lines: Line[]; topics: string[]; from: number; copies: number[]; audit: string | null;
  }[];
  topics: Topic[];
  feed: Notice[];
  requests: { id: number; from: number; topic: string; label: string; round: number; matches: string[]; mine: boolean }[];
  interceptArmed: boolean;
  draft: {
    answers: Record<string, number | null>; cites: Record<string, (string | null)[]>; approvals: boolean[];
    valid: boolean; required: number; window: number;
  };
  result: {
    win: boolean; stars: number; correct: boolean[]; ironclad: boolean[]; window: number;
    solution: { q: string; label: string; proof: PProof[] }[];
  } | null;
  cited: PProof[];
}
export type PResult = NonNullable<PView["result"]>;
