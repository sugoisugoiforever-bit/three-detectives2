// واجهات بنيوية دنيا لما نستعمله من Cloudflare، حتى لا نعتمد على حزمة الأنواع الرسمية
// (فلا يتعارض شيء إن ثُبّتت) ويمكن اختبار الكود في Node بمحاكاة بسيطة.

export interface WSLike {
  accept(): void;
  send(data: string): void;
  close(code?: number, reason?: string): void;
  addEventListener(type: "message", fn: (ev: { data: unknown }) => void): void;
  addEventListener(type: "close" | "error", fn: (ev: unknown) => void): void;
}

export interface StorageLike {
  get<T = unknown>(key: string): Promise<T | undefined>;
  put(key: string, value: unknown): Promise<void>;
  deleteAll(): Promise<void>;
  setAlarm(at: number): Promise<void>;
  deleteAlarm(): Promise<void>;
}

export interface StateLike {
  storage: StorageLike;
  blockConcurrencyWhile<T>(fn: () => Promise<T>): Promise<T>;
}

export interface StubLike {
  fetch(input: string | Request, init?: RequestInit): Promise<Response>;
}

export interface NamespaceLike {
  idFromName(name: string): unknown;
  get(id: unknown): StubLike;
}

export interface Env {
  ROOMS: NamespaceLike;
}

export type WSPairCtor = new () => { 0: WSLike; 1: WSLike };
