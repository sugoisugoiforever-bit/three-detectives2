// محرك اللعبة: نقل حرفي لـ engine/src/main/kotlin/game/Engine.kt (القواعد نفسها بالترتيب نفسه واستهلاك المولّد العشوائي نفسه).
import {
  type Action, type Case, type Doc, type Notice, type Opt, type PResult, type Topic,
  KIND_AR, QIDS, QUESTION_AR, ROLE_AR, optionCount, questionOf,
} from "./model.ts";
import { BotDriver, type BotState } from "./bots.ts";

export interface Config { credits: number; roundMs: number; accuseMs: number; botSkill: number; botPace: number }
export const Configs = {
  easy: (): Config => ({ credits: 8, roundMs: 240_000, accuseMs: 180_000, botSkill: 0.9, botPace: 1.0 }),
  normal: (): Config => ({ credits: 7, roundMs: 240_000, accuseMs: 180_000, botSkill: 0.7, botPace: 1.0 }),
  hard: (): Config => ({ credits: 6, roundMs: 240_000, accuseMs: 180_000, botSkill: 0.5, botPace: 1.0 }),
};
export function configFor(difficulty: number): Config {
  return difficulty === 0 ? Configs.easy() : difficulty === 2 ? Configs.hard() : Configs.normal();
}

/** مولّد xorshift32 بأعداد 32 بت موقّعة كما في Kotlin. */
export class Rng {
  s: number;
  constructor(seed: number) {
    this.s = (seed | 0) === 0 ? 0x1f123bb5 : seed | 0;
  }
  next(): number {
    let x = this.s;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.s = x | 0;
    return this.s;
  }
  nextInt(n: number): number {
    return (this.next() >>> 0) % n;
  }
}

export class Seat {
  connected = true;
  ready = false;
  moveUsed = false;
  abilityUsed = false;
  visible = new Set<string>();
  from = new Map<string, number>();
  // جدولة البوت
  nextAt = Infinity;
  readyAt = 0;
  accuseAt = 0;
  abilityDone = false;
  answered = new Set<number>();
  objected = new Set<string>();
  name: string;
  bot: boolean;
  constructor(name: string, bot: boolean) {
    this.name = name;
    this.bot = bot;
  }
}

export interface Req { id: number; from: number; topic: string; round: number }
export interface WinRes { correct: boolean[]; ironclad: boolean[] }

/** لقطة قابلة للتخزين الكامل (JSON) لاستعادة الغرفة بعد إعادة تشغيل الخادم. */
export interface GameState {
  rng: number;
  cfg: Config;
  seats: {
    name: string; bot: boolean; connected: boolean; ready: boolean; moveUsed: boolean; abilityUsed: boolean;
    visible: string[]; from: [string, number][]; nextAt: number | null; readyAt: number | null; accuseAt: number;
    abilityDone: boolean; answered: number[]; objected: string[];
  }[];
  phase: string; round: number; window: number; phaseEndsAt: number; credits: number;
  delivered: string[]; copies: [string, number[]][]; feed: Notice[]; requests: Req[];
  answers: [string, number | null][]; cites: [string, (string | null)[]][]; approvals: boolean[];
  answerBy: [string, number][]; interceptArmed: boolean; audits: [string, string][];
  windows: [number, WinRes][]; result: PResult | null; nextId: number; bots: BotState;
}

const inf = (x: number | null): number => (x === null ? Infinity : x);
const fin = (x: number): number | null => (Number.isFinite(x) ? x : null);
const setEq = (a: Set<string | null>, b: string[]): boolean => a.size === new Set(b).size && b.every((x) => a.has(x));

export class Game {
  rng: Rng;
  seats: Seat[];
  phase = "round";
  round = 0;
  window = 0;
  phaseEndsAt = 0;
  credits: number;
  delivered = new Set<string>();
  copies = new Map<string, Set<number>>();
  feed: Notice[] = [];
  requests: Req[] = [];
  answers = new Map<string, number | null>();
  cites = new Map<string, (string | null)[]>();
  approvals = [false, false, false];
  answerBy = new Map<string, number>(); // آخر من عدّل إجابة السؤال (للبوتات)
  interceptArmed = false;
  audits = new Map<string, string>();
  windows = new Map<number, WinRes>();
  result: PResult | null = null;
  nextId = 1;
  bots: BotDriver;

  c: Case;
  cfg: Config;

  constructor(c: Case, cfg: Config, seed: number, now: number, humans: Iterable<number> = [], restore?: GameState) {
    this.c = c;
    this.cfg = cfg;
    this.rng = new Rng(seed);
    this.seats = [0, 1, 2].map((i) => new Seat(ROLE_AR[i], true));
    this.credits = cfg.credits;
    this.bots = new BotDriver(this);
    if (restore) {
      this.loadState(restore);
      return;
    }
    for (const q of QIDS) {
      this.answers.set(q, null);
      this.cites.set(q, [null, null]);
    }
    for (const h of humans) this.seats[h].bot = false;
    this.startRound(1, now);
  }

  // ───────── مساعدات ─────────
  note(kind: string, from: number, to: number, text: string, doc: string | null = null): number {
    const id = this.nextId++;
    this.feed.push({ id, round: this.round, kind, from, to, text, doc });
    return id;
  }

  private noteOthers(kind: string, from: number, text: string): void {
    for (let s = 0; s <= 2; s++) if (s !== from) this.note(kind, from, s, text);
  }

  setSeat(seat: number, name: string, bot: boolean): void {
    this.seats[seat].name = name;
    this.seats[seat].bot = bot;
  }

  seesTopic(seat: number, topicId: string): boolean {
    for (const id of this.seats[seat].visible) if (this.c.docById.get(id)!.topics.includes(topicId)) return true;
    return false;
  }

  /** تقدير اللاعب للإجابة من الوثائق التي يراها (يستعمله البوت). */
  belief(visible: Set<string>, q: string): number | null {
    const sc: number[] = new Array(optionCount(this.c, q)).fill(0);
    for (const cl of this.c.claims) {
      if (cl.q === q && cl.needs.every((n) => visible.has(n))) sc[cl.opt] += cl.w;
    }
    const top = Math.max(...sc);
    if (top <= 0) return null;
    const idx: number[] = [];
    sc.forEach((v, i) => { if (v === top) idx.push(i); });
    return idx.length === 1 ? idx[0] : null;
  }

  // ───────── سير الجولات ─────────
  startRound(r: number, now: number): void {
    this.round = r;
    this.phase = "round";
    this.phaseEndsAt = now + this.cfg.roundMs;
    for (const s of this.seats) {
      s.ready = false;
      s.moveUsed = false;
    }
    this.note("round", -1, -1, `بدأت الجولة ${r} من 5`);
    for (const d of this.c.docs) if (d.round === r) this.deliver(d);
    this.bots.onRoundStart(now);
  }

  private deliver(d: Doc): void {
    if (this.delivered.has(d.id)) return;
    this.delivered.add(d.id);
    this.seats[d.owner].visible.add(d.id);
    let cp = this.copies.get(d.id);
    if (!cp) this.copies.set(d.id, (cp = new Set()));
    cp.add(d.owner);
    this.note("doc", -1, d.owner, `وصلتك وثيقة جديدة: «${d.title}»`, d.id);
  }

  endRound(now: number): void {
    if (this.round < 4) this.startRound(this.round + 1, now);
    else this.openAccusation(this.round === 4 ? 1 : 2, now);
  }

  private openAccusation(w: number, now: number): void {
    this.phase = "accuse";
    this.window = w;
    this.phaseEndsAt = now + this.cfg.accuseMs;
    this.approvals.fill(false);
    this.note("accuse", -1, -1, w === 1 ? "فُتحت نافذة الاتهام: يلزم إجماع الثلاثة" : "نافذة الاتهام الأخيرة: تكفي موافقة اثنين");
    this.bots.onAccuseStart(now);
  }

  /** تنتهي الجولة عندما يجهز كل المتصلين (المنقطع لا يعطّل زميليه). */
  checkAllReady(now: number): void {
    if (this.phase === "round" && this.seats.some((s) => s.ready) && this.seats.every((s) => s.ready || !s.connected)) {
      this.endRound(now);
    }
  }

  /** يحوّل مقعداً إلى بوت (انقطاع لاعب أو مقعد شاغر). */
  takeover(seat: number, name: string, now: number): void {
    const s = this.seats[seat];
    s.name = name;
    s.bot = true;
    s.connected = true;
    this.bots.adopt(seat, now);
  }

  /** يعيد مقعداً إلى لاعب بشري. */
  release(seat: number, name: string): void {
    const s = this.seats[seat];
    s.name = name;
    s.bot = false;
    s.connected = true;
  }

  tick(now: number): void {
    if (this.phase === "ended") return;
    this.bots.onTick(now);
    if (this.phase === "ended") return;
    if (now >= this.phaseEndsAt) {
      if (this.phase === "round") this.endRound(now);
      else if (this.phase === "accuse") {
        if (this.window === 1) {
          this.note("accuse", -1, -1, "انتهت النافذة دون اتهام. أمامكم جولة أخيرة");
          this.startRound(5, now);
        } else this.finish();
      }
    }
  }

  // ───────── الحركات ─────────
  /** يعيد null عند النجاح، أو رسالة خطأ عربية تُعرض للاعب. */
  handle(seat: number, a: Action, now: number): string | null {
    if (this.phase === "ended") return "انتهت القضية";
    switch (a.a) {
      case "share": return this.share(seat, a);
      case "request": return this.request(seat, a, now);
      case "template": return this.template(seat, a);
      case "ability": return this.ability(seat, a);
      case "ready":
        if (this.phase !== "round") return "لا جولة جارية الآن";
        this.seats[seat].ready = a.on;
        this.checkAllReady(now);
        return null;
      case "answer": return this.answer(seat, a);
      case "cite": return this.cite(seat, a);
      case "approve": return this.approve(seat, a, now);
    }
  }

  private commCheck(seat: number): string | null {
    if (this.phase !== "round") return "التواصل متاح أثناء الجولات فقط";
    if (this.seats[seat].moveUsed) return "استهلكتَ حركتك في هذه الجولة";
    return null;
  }

  private share(seat: number, a: Extract<Action, { a: "share" }>): string | null {
    const e = this.commCheck(seat);
    if (e) return e;
    const s = this.seats[seat];
    const d = this.c.docById.get(a.doc);
    if (!d) return "وثيقة غير موجودة";
    if (d.owner !== seat || !s.visible.has(a.doc)) return "يمكنك مشاركة وثائقك الأصلية فقط";
    if (!(a.to >= 0 && a.to <= 2) || a.to === seat) return "اختر زميلاً آخر";
    if (this.seats[a.to].visible.has(a.doc)) return "هذه الوثيقة عند زميلك أصلاً";
    if (this.credits < 1) return "نفدت القطع النحاسية";
    this.credits -= 1;
    s.moveUsed = true;
    this.seats[a.to].visible.add(a.doc);
    this.seats[a.to].from.set(a.doc, seat);
    let cp = this.copies.get(a.doc);
    if (!cp) this.copies.set(a.doc, (cp = new Set()));
    cp.add(a.to);
    this.note("share", seat, seat, `أرسلتَ «${d.title}» إلى ${ROLE_AR[a.to]}`, a.doc);
    this.note("share", seat, a.to, `${ROLE_AR[seat]} أرسل إليك وثيقة: «${d.title}»`, a.doc);
    if (this.interceptArmed && seat !== 2 && a.to !== 2) {
      this.interceptArmed = false;
      this.note("intercept", -1, 2, `اعتراض ناجح: أُرسلت وثيقة «${d.title}» (${KIND_AR[d.kind]}) من ${ROLE_AR[seat]} إلى ${ROLE_AR[a.to]}`);
    }
    return null;
  }

  private request(seat: number, a: Extract<Action, { a: "request" }>, now: number): string | null {
    const e = this.commCheck(seat);
    if (e) return e;
    const t = this.c.topicById.get(a.topic);
    if (!t) return "موضوع غير معروف";
    if (t.kind === "key" && !this.seesTopic(seat, a.topic)) return "لم تعثر على هذا الرمز في وثائقك";
    this.seats[seat].moveUsed = true;
    const id = this.note("request", seat, -1, `${ROLE_AR[seat]} يسأل: هل عندك شيء عن «${t.label}»؟`);
    this.requests.push({ id, from: seat, topic: a.topic, round: this.round });
    this.bots.onRequest(now);
    return null;
  }

  private slotTopic(seat: number, a: Extract<Action, { a: "template" }>, slot: string, kind: string): Topic | null {
    const id = a.slots[slot];
    if (id === undefined) return null;
    const t = this.c.topicById.get(id);
    if (!t) return null;
    if (t.kind !== kind) return null;
    // الأوقات والرموز لا تُستعمل إلا إن ظهرت في وثائق اللاعب نفسه
    if ((kind === "key" || kind === "time") && !this.seesTopic(seat, t.id)) return null;
    return t;
  }

  private slotOption(a: Extract<Action, { a: "template" }>, slot: string, q: string): Opt | null {
    const id = a.slots[slot];
    if (id === undefined) return null;
    return questionOf(this.c, q).options.find((o) => o.id === id) ?? null;
  }

  renderTemplate(seat: number, a: Extract<Action, { a: "template" }>): string | null {
    switch (a.tpl) {
      case "T1": {
        const p = this.slotTopic(seat, a, "person", "person");
        const l = this.slotTopic(seat, a, "place", "place");
        const t = this.slotTopic(seat, a, "time", "time");
        if (!p || !l || !t) return null;
        const g = this.c.persons.find((x) => x.id === p.id)!.g;
        return `${p.label} ${g === "f" ? "كانت" : "كان"} في ${l.label} الساعة ${t.label}`;
      }
      case "T2": { const p = this.slotTopic(seat, a, "person", "person"); return p ? `أشك في ${p.label}` : null; }
      case "T3": { const p = this.slotTopic(seat, a, "person", "person"); return p ? `أقترح استبعاد ${p.label} من المشتبهين` : null; }
      case "T4": { const o = this.slotOption(a, "how", "how"); return o ? `الأسلوب على الأرجح: ${o.label}` : null; }
      case "T5": { const o = this.slotOption(a, "why", "why"); return o ? `الدافع على الأرجح: ${o.label}` : null; }
      default: return null;
    }
  }

  private template(seat: number, a: Extract<Action, { a: "template" }>): string | null {
    const e = this.commCheck(seat);
    if (e) return e;
    if (this.credits < 1) return "نفدت القطع النحاسية";
    const text = this.renderTemplate(seat, a);
    if (text === null) return "أكمل خانات القالب بشكل صحيح";
    this.credits -= 1;
    this.seats[seat].moveUsed = true;
    this.note("template", seat, -1, `${ROLE_AR[seat]}: ${text}`);
    return null;
  }

  private ability(seat: number, a: Extract<Action, { a: "ability" }>): string | null {
    if (this.phase !== "round") return "القدرات تُستخدم أثناء الجولات فقط";
    const s = this.seats[seat];
    if (s.abilityUsed) return "استخدمتَ قدرتك في هذه الجلسة";
    if (seat === 0) {
      const id = a.arg;
      if (id === null) return "اختر وثيقة للتدقيق";
      const d = this.c.docById.get(id);
      if (!d || !s.visible.has(id)) return "اختر وثيقة تراها على مكتبك";
      const res = d.rel === "decisive" ? "decisive" : "noise";
      this.audits.set(id, res);
      s.abilityUsed = true;
      this.note("ability", 0, 0, `نتيجة التدقيق: «${d.title}» ${res === "decisive" ? "وثيقة حاسمة للحل" : "تشويش لا يفيد الحل"}`, id);
      this.noteOthers("ability", 0, "المحلل المالي استخدم قدرة «تدقيق»");
    } else if (seat === 1) {
      const next = this.c.docs.find((d) => d.round === this.round + 1 && !this.delivered.has(d.id));
      if (!next) return "لا توجد وثائق قادمة لجلبها الآن";
      this.deliver(next);
      s.abilityUsed = true;
      this.note("ability", 1, 1, `نجحت المداهمة: وصلت وثيقة مبكرة إلى ${ROLE_AR[next.owner]}`);
      this.noteOthers("ability", 1, `المحقق الميداني داهم موقعاً فوصلت وثيقة مبكرة إلى ${ROLE_AR[next.owner]}`);
    } else {
      this.interceptArmed = true;
      s.abilityUsed = true;
      this.note("ability", 2, 2, "فُعّل الاعتراض: سيُكشف عنوان أول وثيقة تُرسل بين زميليك");
    }
    return null;
  }

  // ───────── الاتهام والتصويت ─────────
  private accuseCheck(): string | null {
    return this.phase !== "accuse" ? "نافذة الاتهام غير مفتوحة" : null;
  }

  private resetApprovals(): void {
    this.approvals.fill(false);
  }

  private answer(seat: number, a: Extract<Action, { a: "answer" }>): string | null {
    const e = this.accuseCheck();
    if (e) return e;
    if (!QIDS.includes(a.q)) return "سؤال غير معروف";
    if (a.opt !== null && !(a.opt >= 0 && a.opt < optionCount(this.c, a.q))) return "خيار غير صالح";
    this.answers.set(a.q, a.opt);
    this.answerBy.set(a.q, seat);
    this.resetApprovals();
    return null;
  }

  private cite(seat: number, a: Extract<Action, { a: "cite" }>): string | null {
    const e = this.accuseCheck();
    if (e) return e;
    if (!QIDS.includes(a.q) || !(a.slot >= 0 && a.slot <= 1)) return "إحالة غير صالحة";
    if (a.doc !== null && !this.seats[seat].visible.has(a.doc)) return "لا تستطيع الاستشهاد بوثيقة لم تصلك عبر اللعبة";
    this.cites.get(a.q)![a.slot] = a.doc;
    this.resetApprovals();
    return null;
  }

  draftError(): string | null {
    for (const q of QIDS) {
      const ct = this.cites.get(q)!;
      if (this.answers.get(q) === null) return `اختاروا إجابة لسؤال «${QUESTION_AR[q]}»`;
      if (ct[0] === null || ct[1] === null) return `أرفقوا وثيقتين لسؤال «${QUESTION_AR[q]}»`;
      if (ct[0] === ct[1]) return `الوثيقتان في «${QUESTION_AR[q]}» متطابقتان`;
      if (this.c.docById.get(ct[0])!.owner === this.c.docById.get(ct[1])!.owner) return `وثائق «${QUESTION_AR[q]}» يجب أن تكون من لاعبَين مختلفين`;
    }
    return null;
  }

  draftValid(): boolean { return this.draftError() === null; }
  required(): number { return this.window === 1 ? 3 : 2; }

  private approve(seat: number, a: Extract<Action, { a: "approve" }>, now: number): string | null {
    const e = this.accuseCheck();
    if (e) return e;
    if (a.on) {
      const de = this.draftError();
      if (de) return de;
    }
    this.approvals[seat] = a.on;
    if (a.on && this.approvals.filter((x) => x).length >= this.required()) this.submit(now);
    return null;
  }

  private isIronclad(q: string): boolean {
    const ct = this.cites.get(q)!;
    const cited = new Set<string | null>([ct[0], ct[1]]);
    return this.c.proof[q].some((p) => setEq(cited, p));
  }

  private submit(now: number): void {
    const correct = QIDS.map((q) => this.answers.get(q) === this.c.truth[q]);
    const ironclad = QIDS.map((q, i) => correct[i] && this.isIronclad(q));
    this.windows.set(this.window, { correct, ironclad });
    const n = correct.filter((x) => x).length;
    if (n === 3 || this.window === 2) this.finish();
    else {
      this.note("accuse", -1, -1, `رُفعت التهمة لكنها غير مكتملة: ${n} من 3 إجابات صحيحة. تابعوا التحقيق في الجولة الأخيرة`);
      this.resetApprovals();
      this.startRound(5, now);
    }
  }

  starsFor(correct: number, allIronclad: boolean, w: number): number {
    if (correct === 3) return allIronclad && w === 1 ? 3 : 2;
    if (correct === 2) return 1;
    return 0;
  }

  private finish(): void {
    this.phase = "ended";
    let best = 0;
    let bestW = 0;
    for (let w = 1; w <= 2; w++) {
      const r = this.windows.get(w);
      if (!r) continue;
      const st = this.starsFor(r.correct.filter((x) => x).length, r.ironclad.every((x) => x), w);
      if (st > best || bestW === 0) {
        best = st;
        bestW = w;
      }
    }
    const last = this.windows.get(bestW);
    const solution = QIDS.map((q) => {
      const pair = this.c.proof[q][0];
      return {
        q,
        label: questionOf(this.c, q).options[this.c.truth[q]].label,
        proof: pair.map((id) => {
          const d = this.c.docById.get(id)!;
          return { id: d.id, title: d.title, owner: d.owner };
        }),
      };
    });
    this.result = {
      win: best >= 1, stars: best,
      correct: last?.correct ?? [false, false, false],
      ironclad: last?.ironclad ?? [false, false, false],
      window: bestW, solution,
    };
    const label = best === 3 ? "قضية محكمة" : best === 2 ? "قضية مغلقة" : best === 1 ? "إغلاق بثغرة" : "فشل التحقيق";
    this.note("verdict", -1, -1, `الحكم النهائي: ${label}`);
  }

  // ───────── التخزين ─────────
  toState(): GameState {
    return {
      rng: this.rng.s, cfg: this.cfg,
      seats: this.seats.map((s) => ({
        name: s.name, bot: s.bot, connected: s.connected, ready: s.ready, moveUsed: s.moveUsed, abilityUsed: s.abilityUsed,
        visible: [...s.visible], from: [...s.from], nextAt: fin(s.nextAt), readyAt: fin(s.readyAt), accuseAt: s.accuseAt,
        abilityDone: s.abilityDone, answered: [...s.answered], objected: [...s.objected],
      })),
      phase: this.phase, round: this.round, window: this.window, phaseEndsAt: this.phaseEndsAt, credits: this.credits,
      delivered: [...this.delivered], copies: [...this.copies].map(([k, v]) => [k, [...v]]),
      feed: this.feed, requests: this.requests,
      answers: [...this.answers], cites: [...this.cites].map(([k, v]) => [k, [...v]]), approvals: [...this.approvals],
      answerBy: [...this.answerBy], interceptArmed: this.interceptArmed, audits: [...this.audits],
      windows: [...this.windows], result: this.result, nextId: this.nextId, bots: this.bots.toState(),
    };
  }

  private loadState(st: GameState): void {
    this.rng.s = st.rng | 0;
    st.seats.forEach((x, i) => {
      const s = this.seats[i];
      s.name = x.name; s.bot = x.bot; s.connected = x.connected; s.ready = x.ready;
      s.moveUsed = x.moveUsed; s.abilityUsed = x.abilityUsed;
      s.visible = new Set(x.visible); s.from = new Map(x.from);
      s.nextAt = inf(x.nextAt); s.readyAt = inf(x.readyAt); s.accuseAt = x.accuseAt;
      s.abilityDone = x.abilityDone; s.answered = new Set(x.answered); s.objected = new Set(x.objected);
    });
    this.phase = st.phase; this.round = st.round; this.window = st.window;
    this.phaseEndsAt = st.phaseEndsAt; this.credits = st.credits;
    this.delivered = new Set(st.delivered);
    this.copies = new Map(st.copies.map(([k, v]) => [k, new Set(v)]));
    this.feed = st.feed; this.requests = st.requests;
    this.answers = new Map(st.answers);
    this.cites = new Map(st.cites.map(([k, v]) => [k, [...v]]));
    this.approvals = [...st.approvals];
    this.answerBy = new Map(st.answerBy);
    this.interceptArmed = st.interceptArmed;
    this.audits = new Map(st.audits);
    this.windows = new Map(st.windows);
    this.result = st.result; this.nextId = st.nextId;
    this.bots.loadState(st.bots);
  }
}
