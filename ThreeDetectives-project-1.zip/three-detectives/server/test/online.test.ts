import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import WebSocket from "ws";
import { Host } from "./host.ts";
import { GAME_GRACE_MS, IDLE_MS } from "../src/room.ts";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function until(cond: () => boolean, what: string, ms = 3000): Promise<void> {
  const t0 = Date.now();
  while (!cond()) {
    if (Date.now() - t0 > ms) throw new Error("انتهت المهلة: " + what);
    await sleep(2);
  }
}

class Client {
  ws!: WebSocket;
  msgs: any[] = [];
  closed = false;
  static open(url: string): Promise<Client | { status: number }> {
    return new Promise((ok) => {
      const c = new Client();
      c.ws = new WebSocket(url);
      c.ws.on("open", () => ok(c));
      c.ws.on("unexpected-response", (_req, res) => { ok({ status: res.statusCode ?? 0 }); res.resume(); });
      c.ws.on("error", () => {});
      c.ws.on("message", (d) => c.msgs.push(JSON.parse(String(d))));
      c.ws.on("close", () => (c.closed = true));
    });
  }
  send(o: unknown) { this.ws.send(JSON.stringify(o)); }
  last(t: string): any { return [...this.msgs].reverse().find((m) => m.t === t); }
  get view(): any { return this.last("view")?.v; }
  get lobby(): any { return this.last("lobby"); }
}

const host = new Host();
before(() => host.listen());
after(() => host.close());

async function create(): Promise<string> {
  const r = await fetch(host.url("/api/create"), { method: "POST" });
  assert.equal(r.status, 200);
  const j = (await r.json()) as { code: string };
  assert.match(j.code, /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{5}$/);
  return j.code;
}
const join = async (code: string, pid: string, name: string) => {
  const c = await Client.open(host.wsUrl(`/ws/${code}?pid=${pid}&name=${encodeURIComponent(name)}`));
  assert.ok(c instanceof Client, "فشل الاتصال: " + JSON.stringify(c));
  return c as Client;
};

test("نقاط HTTP: ping وcreate والمسارات المجهولة", async () => {
  const p = await fetch(host.url("/api/ping"));
  const txt = await p.text();
  assert.equal(p.status, 200);
  assert.ok(txt.includes("detectives"));
  assert.equal(JSON.parse(txt).cases, 180);
  assert.equal((await fetch(host.url("/api/nope"))).status, 404);
  assert.equal((await fetch(host.url("/api/create"))).status, 404); // GET غير مسموح
  assert.equal((await fetch(host.url("/api/ping"), { method: "OPTIONS" })).status, 204);
  const a = await create(), b = await create();
  assert.notEqual(a, b);
});

test("رفض الاتصال: غرفة غير موجودة 404، رمز مشوّه 404، هوية سيئة 400، ممتلئة 409", async () => {
  assert.deepEqual(await Client.open(host.wsUrl("/ws/ZZZZZ?pid=abcdefgh&name=x")), { status: 404 });
  assert.deepEqual(await Client.open(host.wsUrl("/ws/12?pid=abcdefgh&name=x")), { status: 404 });
  const code = await create();
  assert.deepEqual(await Client.open(host.wsUrl(`/ws/${code}?pid=a&name=x`)), { status: 400 });
  const cs = [await join(code, "player-aaa", "أ"), await join(code, "player-bbb", "ب"), await join(code, "player-ccc", "ج")];
  assert.deepEqual(await Client.open(host.wsUrl(`/ws/${code}?pid=player-ddd&name=د`)), { status: 409 });
  // الرمز غير حساس لحالة الأحرف
  const low = await Client.open(host.wsUrl(`/ws/${code.toLowerCase()}?pid=player-aaa&name=أ`));
  assert.ok(low instanceof Client);
  cs.forEach((c) => c.ws.close());
  (low as Client).ws.close();
});

test("لعبة كاملة عبر WebSocket: ردهة، إعداد، بدء، لعب، نهاية، ثم «مجدداً»", async () => {
  const code = await create();
  const [a, b, c] = [await join(code, "player-aaa", "سامر"), await join(code, "player-bbb", "ليلى"), await join(code, "player-ccc", "كمال")];
  await until(() => [a, b, c].every((x) => x.lobby), "الردهة");
  assert.deepEqual([a, b, c].map((x) => x.lobby.seat), [0, 1, 2]);
  assert.equal(a.lobby.host, true);
  b.send({ t: "cfg", theme: "museum", difficulty: 0 });
  await until(() => b.last("err"), "رفض إعداد غير المضيف");
  a.send({ t: "cfg", theme: "museum", difficulty: 0 });
  await until(() => c.lobby.theme === "museum" && c.lobby.difficulty === 0, "بث الإعداد");
  a.send({ t: "start" });
  await until(() => [a, b, c].every((x) => x.view), "العروض");
  assert.equal(a.view.info.theme, "museum");
  assert.equal(a.view.credits, 8); // سهل
  assert.deepEqual([a, b, c].map((x) => x.view.seat), [0, 1, 2]);

  const clients = [a, b, c];
  const readied = new Set<string>();
  let guard = 0;
  while (clients[0].view.phase !== "ended" && guard++ < 4000) {
    for (const [i, cl] of clients.entries()) {
      const v = cl.view;
      const key = `${i}:${v.round}:${v.phase}`;
      if (v.phase === "round" && !readied.has(key)) { readied.add(key); cl.send({ t: "act", a: { a: "ready", on: true } }); }
    }
    host.tick(5000);
    await sleep(3);
  }
  await until(() => clients.every((x) => x.view.phase === "ended"), "نهاية اللعبة");
  assert.ok(clients.every((x) => x.view.result), "النتيجة");
  assert.ok(clients[0].view.result.stars >= 0);

  c.send({ t: "again" });
  await until(() => clients.every((x) => x.lobby.started === false), "العودة إلى الردهة");
  a.send({ t: "start" });
  await until(() => clients.every((x) => x.view.phase === "round" && x.view.round === 1 && x.view.feed.length >= 0 && !x.view.result), "جولة جديدة");
  clients.forEach((x) => x.ws.close());
});

test("انقطاع اتصال: بوت بعد المهلة ثم عودة اللاعب بالهوية نفسها", async () => {
  const code = await create();
  const [a, b] = [await join(code, "player-aaa", "سامر"), await join(code, "player-bbb", "ليلى")];
  a.send({ t: "start" });
  await until(() => a.view && b.view, "العروض");
  b.ws.terminate();
  await until(() => a.view.players[1].connected === false, "اكتشاف الانقطاع");
  host.tick(GAME_GRACE_MS + 1000);
  await until(() => a.view.players[1].bot === true, "حلول البوت");
  const b2 = await join(code, "player-bbb", "ليلى");
  await until(() => b2.view && b2.view.players[1].bot === false, "عودة المقعد");
  await until(() => a.view.players[1].bot === false && a.view.players[1].connected, "عرض العودة للآخرين");
  assert.equal(b2.view.seat, 1);
  a.ws.close(); b2.ws.close();
});

test("إعادة تشغيل الكائن: تُستعاد الغرفة من التخزين وتتابع اللعبة", async () => {
  const code = await create();
  const [a, b] = [await join(code, "player-aaa", "سامر"), await join(code, "player-bbb", "ليلى")];
  a.send({ t: "cfg", theme: "techco", difficulty: 2 });
  a.send({ t: "start" });
  await until(() => a.view && b.view, "العروض");
  a.send({ t: "act", a: { a: "request", topic: a.view.topics.find((t: any) => t.kind === "person").id } });
  await until(() => a.view.players[0].moveUsed, "حركة");
  host.tick(60_000);
  await sleep(20);
  const before = JSON.stringify({ round: a.view.round, docs: a.view.docs.map((d: any) => d.id), credits: a.view.credits });
  await sleep(2100); // مهلة الحفظ الدوري
  host.tick(2500);
  await sleep(30);
  a.ws.terminate(); b.ws.terminate();
  await sleep(30);
  host.evict(code);
  const a2 = await join(code, "player-aaa", "سامر");
  await until(() => a2.view, "عرض بعد الاستعادة");
  assert.equal(a2.lobby.theme, "techco");
  assert.equal(a2.lobby.difficulty, 2);
  assert.equal(a2.view.seat, 0);
  assert.equal(a2.view.players[0].moveUsed, true);
  const after = JSON.stringify({ round: a2.view.round, docs: a2.view.docs.map((d: any) => d.id), credits: a2.view.credits });
  assert.equal(after, before);
  assert.deepEqual(await Client.open(host.wsUrl(`/ws/${code}?pid=player-zzz&name=غريب`)), { status: 409 });
  a2.ws.close();
});

test("الخمول: الغرفة المهجورة تُحذف ويصير رمزها غير موجود", async () => {
  const code = await create();
  const a = await join(code, "player-aaa", "سامر");
  await until(() => a.lobby, "الردهة");
  a.ws.close();
  await until(() => a.closed, "إغلاق");
  host.tick(IDLE_MS + 5000);
  await sleep(30);
  assert.equal(host.storage(code).data.size, 0);
  assert.equal(host.storage(code).alarmAt, null);
  assert.deepEqual(await Client.open(host.wsUrl(`/ws/${code}?pid=player-aaa&name=x`)), { status: 404 });
});
