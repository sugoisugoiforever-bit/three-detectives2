import { test } from "node:test";
import assert from "node:assert/strict";
import { library } from "../src/cases.ts";
import { Room, GAME_GRACE_MS, LOBBY_GRACE_MS, IDLE_MS, cleanName, type Sink } from "../src/room.ts";

class Fake implements Sink {
  msgs: any[] = [];
  closed: [number, string] | null = null;
  send(t: string) { this.msgs.push(JSON.parse(t)); }
  close(code: number, reason: string) { this.closed = [code, reason]; }
  last(t: string) { return [...this.msgs].reverse().find((m) => m.t === t); }
  all(t: string) { return this.msgs.filter((m) => m.t === t); }
}

const mk = (now = 0) => new Room("ABCDE", library, now, () => 0.42);
const say = (r: Room, id: string, o: unknown, now: number) => r.message(id, JSON.stringify(o), now);

function lobby3(now = 0) {
  const r = mk(now);
  const s = [new Fake(), new Fake(), new Fake()];
  ["p0", "p1", "p2"].forEach((p, i) => assert.ok(r.join("c" + i, p, "لاعب" + i, s[i], now)));
  return { r, s };
}

test("الانضمام: مقاعد بالترتيب، أول لاعب مضيف، والرابع مرفوض", () => {
  const { r, s } = lobby3();
  assert.deepEqual(s.map((x) => x.last("lobby").seat), [0, 1, 2]);
  assert.equal(s[0].last("lobby").host, true);
  assert.equal(s[1].last("lobby").host, false);
  assert.equal(r.canJoin("p9"), false);
  assert.equal(r.canJoin("p1"), true);
  const l = s[0].last("lobby");
  assert.equal(l.started, false);
  assert.equal(l.difficulty, 1);
  assert.deepEqual(l.seats.map((x: any) => [x.name, x.bot, x.connected]), [["لاعب0", false, true], ["لاعب1", false, true], ["لاعب2", false, true]]);
});

test("الإعدادات: للمضيف وحده وبقيم صالحة فقط", () => {
  const { r, s } = lobby3();
  say(r, "c1", { t: "cfg", theme: "museum", difficulty: 2 }, 1);
  assert.match(s[1].last("err").m, /المضيف/);
  say(r, "c0", { t: "cfg", theme: "nope", difficulty: 2 }, 1);
  assert.match(s[0].last("err").m, /سمة/);
  say(r, "c0", { t: "cfg", theme: "museum", difficulty: 7 }, 1);
  assert.match(s[0].all("err").at(-1).m, /صعوبة/);
  say(r, "c0", { t: "cfg", theme: "techco", difficulty: 2 }, 1);
  assert.equal(s[2].last("lobby").theme, "techco");
  assert.equal(s[2].last("lobby").difficulty, 2);
  say(r, "c0", { t: "cfg", theme: "", difficulty: 0 }, 2);
  assert.equal(s[1].last("lobby").theme, "");
});

test("اختيار المقعد: ينتقل إلى مقعد شاغر ويُرفض المحجوز", () => {
  const r = mk();
  const a = new Fake(), b = new Fake();
  r.join("a", "pa", "أ", a, 0);
  r.join("b", "pb", "ب", b, 0);
  say(r, "b", { t: "seat", seat: 0 }, 1);
  assert.match(b.last("err").m, /محجوز/);
  say(r, "b", { t: "seat", seat: 2 }, 1);
  assert.equal(b.last("lobby").seat, 2);
  assert.deepEqual(a.last("lobby").seats.map((x: any) => x.connected), [true, false, true]);
  say(r, "b", { t: "seat", seat: 9 }, 1);
  assert.match(b.all("err").at(-1).m, /مقعد/);
});

test("البدء: للمضيف وحده، وكل لاعب يتلقى منظوره الخاص", () => {
  const { r, s } = lobby3();
  say(r, "c1", { t: "start" }, 1);
  assert.match(s[1].last("err").m, /المضيف/);
  assert.equal(s[0].last("view"), undefined);
  say(r, "c0", { t: "start" }, 2);
  for (let i = 0; i < 3; i++) {
    const v = s[i].last("view").v;
    assert.equal(v.seat, i);
    assert.equal(v.phase, "round");
    assert.equal(s[i].last("lobby").started, true);
    assert.deepEqual(v.players.map((p: any) => p.bot), [false, false, false]);
  }
  // لا أسرار: كل لاعب يرى وثائقه فقط
  const owners = s.map((x) => new Set(x.last("view").v.docs.map((d: any) => d.owner)));
  owners.forEach((o, i) => assert.ok(o.has(i)));
  assert.equal(r.canJoin("p9"), false);
  say(r, "c0", { t: "cfg", theme: "museum", difficulty: 0 }, 3);
  assert.match(s[0].last("err").m, /بدأت/);
});

test("الحركات: صالحة تُطبَّق وتُبثّ، وغير الصالحة ترجع رسالة خطأ لصاحبها فقط", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "start" }, 0);
  const n1 = s[1].all("view").length;
  say(r, "c0", { t: "act", a: { a: "ready", on: true } }, 1000);
  assert.equal(s[0].last("view").v.players[0].ready, true);
  assert.equal(s[1].last("view").v.players[0].ready, true);
  assert.ok(s[1].all("view").length > n1);
  const e = s[1].all("err").length;
  say(r, "c1", { t: "act", a: { a: "bogus" } }, 1100);
  assert.match(s[1].last("err").m, /غير صالحة/);
  say(r, "c1", { t: "act", a: { a: "share", doc: "zzz", to: 0 } }, 1200);
  assert.equal(s[1].all("err").length, e + 2);
  assert.equal(s[0].all("err").length, 0);
});

test("لا إرسال بلا تغيير: tick بلا أحداث لا يبعث عروضاً جديدة", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "start" }, 0);
  r.tick(500);
  const n = s[0].msgs.length;
  r.tick(600); r.tick(700);
  assert.equal(s[0].msgs.length, n);
});

test("رسائل معطوبة أو كبيرة أو كثيرة لا تُسقط الغرفة", () => {
  const { r, s } = lobby3();
  r.message("c0", "not json", 1);
  r.message("c0", "42", 1);
  r.message("c0", JSON.stringify({ t: "zzz" }), 1);
  r.message("c0", "x".repeat(5000), 1);
  r.message("nobody", "{}", 1);
  assert.equal(s[0].all("err").length, 4);
  for (let i = 0; i < 60; i++) say(r, "c1", { t: "cfg", theme: "", difficulty: 1 }, 10);
  assert.ok(s[1].all("err").some((e) => /كثيرة/.test(e.m)));
});

test("انقطاع في الردهة: يُحجز المقعد مهلة ثم يُحرَّر وينتقل الاستضافة", () => {
  const { r, s } = lobby3();
  r.disconnect("c0", 1000);
  assert.equal(s[1].last("lobby").seats[0].connected, false);
  r.tick(1000 + LOBBY_GRACE_MS - 1);
  assert.equal(r.slots[0].pid, "p0");
  r.tick(1000 + LOBBY_GRACE_MS);
  assert.equal(r.slots[0].pid, null);
  assert.equal(r.hostPid, "p1");
  assert.equal(s[1].last("lobby").host, true);
  assert.equal(r.canJoin("p9"), true);
});

test("مغادرة صريحة في الردهة تحرّر المقعد فوراً", () => {
  const { r, s } = lobby3();
  say(r, "c1", { t: "leave" }, 5);
  assert.deepEqual(s[1].closed, [1000, "left"]);
  assert.equal(r.slots[1].pid, null);
  assert.equal(s[0].last("lobby").seats[1].connected, false);
  assert.ok(r.join("n", "pn", "جديد", new Fake(), 6));
  assert.equal(r.slots[1].pid, "pn");
});

test("انقطاع أثناء اللعب: بوت يحلّ مكانه بعد المهلة، وعودته تُرجع المقعد", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "start" }, 0);
  r.disconnect("c2", 2000);
  assert.equal(s[0].last("view").v.players[2].connected, false);
  assert.equal(s[0].last("view").v.players[2].bot, false);
  r.tick(2000 + GAME_GRACE_MS);
  assert.equal(s[0].last("view").v.players[2].bot, true);
  assert.equal(s[0].last("lobby").seats[2].bot, true);
  assert.equal(r.canJoin("p9"), false);
  const back = new Fake();
  assert.ok(r.join("c2b", "p2", "لاعب2", back, 40_000));
  assert.equal(back.last("view").v.seat, 2);
  assert.equal(back.last("view").v.players[2].bot, false);
  assert.equal(s[0].last("view").v.players[2].bot, false);
  assert.equal(s[0].last("view").v.players[2].connected, true);
});

test("عودة سريعة ضمن المهلة لا تُشغّل بوتاً، واتصال جديد يستبدل القديم", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "start" }, 0);
  r.disconnect("c1", 1000);
  const back = new Fake();
  r.join("c1b", "p1", "لاعب1", back, 5000);
  r.tick(1000 + GAME_GRACE_MS + 1);
  assert.equal(s[0].last("view").v.players[1].bot, false);
  const again = new Fake();
  r.join("c1c", "p1", "لاعب1", again, 6000);
  assert.deepEqual(back.closed, [4000, "replaced"]);
  r.disconnect("c1b", 6100); // اتصال قديم مستبدَل: يجب ألا يؤثر
  assert.equal(s[0].last("view").v.players[1].connected, true);
});

test("مغادرة صريحة أثناء اللعب: بوت فوري وتفقد الهوية مقعدها", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "start" }, 0);
  say(r, "c2", { t: "leave" }, 3000);
  assert.equal(s[0].last("view").v.players[2].bot, true);
  assert.equal(r.canJoin("p2"), false);
});

test("لعبة كاملة بثلاثة لاعبين: تنتهي، ثم «العب مجدداً» يعيد الجميع إلى الردهة", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "cfg", theme: "warehouse", difficulty: 0 }, 0);
  say(r, "c0", { t: "start" }, 0);
  let now = 0;
  while (s[0].last("view").v.phase !== "ended" && now < 3_000_000) {
    now += 500;
    if (now % 10_000 === 0) for (let i = 0; i < 3; i++) say(r, "c" + i, { t: "act", a: { a: "ready", on: true } }, now);
    r.tick(now);
  }
  assert.equal(s[0].last("view").v.phase, "ended");
  assert.ok(s[2].last("view").v.result);
  say(r, "c2", { t: "again" }, now);
  for (const x of s) assert.equal(x.last("lobby").started, false);
  assert.equal(r.started, false);
  say(r, "c0", { t: "start" }, now + 10);
  assert.equal(s[1].last("view").v.phase, "round");
  assert.equal(s[1].last("view").v.round, 1);
  say(r, "c1", { t: "again" }, now + 20); // أثناء اللعب: لا أثر
  assert.equal(r.started, true);
});

test("الحفظ والاستعادة: الغرفة تعود وسط اللعب وتمهل أصحابها قبل البوت", () => {
  const { r, s } = lobby3();
  say(r, "c0", { t: "cfg", theme: "techco", difficulty: 2 }, 0);
  say(r, "c0", { t: "start" }, 0);
  say(r, "c1", { t: "act", a: { a: "ready", on: true } }, 1000);
  for (let now = 500; now <= 130_000; now += 500) r.tick(now);
  const snap = JSON.parse(JSON.stringify(r.snapshot()));
  const r2 = Room.restore(snap, library, 131_000, () => 0.1)!;
  assert.ok(r2);
  assert.equal(r2.started, true);
  assert.equal(r2.theme, "techco");
  assert.equal(r2.hostPid, "p0");
  const back = new Fake();
  assert.ok(r2.join("x", "p1", "لاعب1", back, 132_000));
  const v1 = back.last("view").v, v0 = s[1].last("view").v;
  assert.equal(v1.seat, 1);
  assert.equal(v1.round, v0.round);
  assert.deepEqual(v1.docs.map((d: any) => d.id), v0.docs.map((d: any) => d.id));
  assert.equal(r2.canJoin("p9"), false);
  r2.tick(131_000 + GAME_GRACE_MS + 1); // p0 وp2 لم يعودا: يحلّ مكانهما بوتان
  assert.equal(back.last("view").v.players[0].bot, true);
  assert.equal(back.last("view").v.players[1].bot, false);
});

test("استعادة غرفة في الردهة، ولقطة معطوبة ترجع null", () => {
  const { r } = lobby3();
  const r2 = Room.restore(JSON.parse(JSON.stringify(r.snapshot())), library, 10)!;
  assert.deepEqual(r2.slots.map((x) => x.pid), ["p0", "p1", "p2"]);
  const bad = { ...r.snapshot(), started: true };
  assert.equal(Room.restore(bad, library, 10), null);
});

test("الخمول والإغلاق", () => {
  const r = mk(0);
  const a = new Fake();
  r.join("a", "pa", "أ", a, 0);
  assert.equal(r.isIdle(IDLE_MS * 2), false); // ما دام فيها اتصال
  r.disconnect("a", 1000);
  assert.equal(r.isIdle(1000 + IDLE_MS - 1), false);
  assert.equal(r.isIdle(1000 + IDLE_MS), true);
  const b = new Fake();
  r.join("b", "pa", "أ", b, 2000);
  r.close("أُغلقت الغرفة");
  assert.deepEqual(b.last("closed"), { t: "closed", m: "أُغلقت الغرفة" });
  assert.deepEqual(b.closed, [1000, "closed"]);
});

test("تنقية الأسماء", () => {
  assert.equal(cleanName("  <b>سامر</b>\n\t "), "b سامر /b");
  assert.equal(cleanName(""), "محقق");
  assert.equal(cleanName(null), "محقق");
  assert.equal(cleanName("ا".repeat(40)).length, 18);
  assert.equal(Array.from(cleanName("😀".repeat(30))).length, 18);
});
