// اختبار «الفوضى»: حركات عشوائية (صالحة وخاطئة ومشوّهة) من ثلاثة مقاعد، مع تبديل البشر/البوت.
// يُنفَّذ بالتطابق نفسه في Kotlin (engine/src/test/kotlin/game/Chaos.kt) ويجب أن يتطابق الأثر حرفياً.
import { Game, Rng, configFor } from "../src/game.ts";
import { QIDS, optionCount, parseAction, questionOf, type Case, type CaseLibrary } from "../src/model.ts";
import { canon, fnv, viewOf } from "../src/view.ts";

const pickDoc = (r: Rng, c: Case) => (r.nextInt(10) === 0 ? "nodoc" : c.docs[r.nextInt(c.docs.length)].id);
const pickTopic = (r: Rng, c: Case) => (r.nextInt(10) === 0 ? "notopic" : c.topics[r.nextInt(c.topics.length)].id);
function pickKind(r: Rng, c: Case, kind: string): string {
  const list = c.topics.filter((t) => t.kind === kind);
  if (list.length === 0 || r.nextInt(5) === 0) return pickTopic(r, c);
  return list[r.nextInt(list.length)].id;
}
const pickOpt = (r: Rng, c: Case, q: string) => {
  const o = questionOf(c, q).options;
  return o[r.nextInt(o.length)].id;
};

export function chaosAction(r: Rng, c: Case, phase: string): Record<string, unknown> {
  const k = phase === "accuse" ? 4 + r.nextInt(6) : r.nextInt(10);
  switch (k) {
    case 0: return { a: "share", doc: pickDoc(r, c), to: r.nextInt(4) };
    case 1: return { a: "request", topic: pickTopic(r, c) };
    case 2: {
      const tpl = "T" + (1 + r.nextInt(6));
      return {
        a: "template", tpl,
        slots: { person: pickKind(r, c, "person"), place: pickKind(r, c, "place"), time: pickKind(r, c, "time"), how: pickOpt(r, c, "how"), why: pickOpt(r, c, "why") },
      };
    }
    case 3: {
      const arg = r.nextInt(3) === 0 ? null : r.nextInt(2) === 0 ? pickDoc(r, c) : pickTopic(r, c);
      return { a: "ability", arg };
    }
    case 4: return { a: "ready", on: r.nextInt(4) === 0 };
    case 5:
    case 9: {
      const q = QIDS[r.nextInt(3)];
      const opt = r.nextInt(8) === 0 ? null : r.nextInt(optionCount(c, q) + 2) - 1;
      return { a: "answer", q, opt };
    }
    case 6: {
      const q = QIDS[r.nextInt(3)];
      const slot = r.nextInt(3);
      const doc = r.nextInt(8) === 0 ? null : pickDoc(r, c);
      return { a: "cite", q, slot, doc };
    }
    case 7: return { a: "approve", on: r.nextInt(5) !== 0 };
    default: {
      const v = r.nextInt(3);
      if (v === 0) return { a: "share", doc: "x" };
      if (v === 1) return { a: "zzz" };
      return { a: "ready", on: "yes" };
    }
  }
}

const SETS: number[][] = [[0, 1, 2], [0, 1, 2], [1], [0, 2], [0, 1, 2], []];
const DIFFS = [1, 2, 0, 1, 2, 0];

export function chaosTrace(lib: CaseLibrary): string[] {
  const out: string[] = [];
  for (let k = 0; k < SETS.length; k++) {
    const idx = (k * 53 + 11) % lib.size;
    const humans = SETS[k];
    const g = new Game(lib.get(idx), configFor(DIFFS[k]), 5000 + k * 31, 0, humans);
    for (const h of humans) g.setSeat(h, "لاعب" + h, false);
    const r = new Rng(99 + k);
    let errHash = 0x811c9dc5;
    let errCount = 0;
    let bad = 0;
    out.push(`chaos k=${k} idx=${idx} id=${g.c.id} humans=${humans.join(",")}`);
    for (let step = 1; step <= 4000; step++) {
      const now = step * 500;
      for (let s = 0; s < 3; s++) {
        if (r.nextInt(60) === 0) {
          if (g.seats[s].bot) g.release(s, "عائد" + s);
          else g.takeover(s, "آلي" + s, now);
        }
        if (r.nextInt(5) !== 0) continue;
        const text = JSON.stringify(chaosAction(r, g.c, g.phase));
        const a = parseAction(JSON.parse(text));
        if (a === null) { bad++; continue; }
        const e = g.handle(s, a, now);
        if (e !== null) { errCount++; errHash = fnv(errHash.toString(16) + e); }
      }
      g.tick(now);
      if (step % 40 === 0 || g.phase === "ended") {
        const hs = [0, 1, 2].map((s) => fnv(canon(viewOf(g, s, now))).toString(16));
        out.push(`t=${now} ph=${g.phase} r=${g.round} w=${g.window} cr=${g.credits} feed=${g.feed.length} err=${errCount}/${errHash.toString(16)} bad=${bad} v=${hs.join(",")}`);
      }
      if (g.phase === "ended") break;
    }
    out.push(`end phase=${g.phase} result=${fnv(canon(viewOf(g, 0, 0).result)).toString(16)}`);
  }
  return out;
}
