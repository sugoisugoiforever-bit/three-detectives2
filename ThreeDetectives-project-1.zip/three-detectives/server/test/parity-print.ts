import { library } from "../src/cases.ts";
import { parityTrace } from "./parity-driver.ts";
console.log(parityTrace(library).join("\n"));
