// سيناريو التكافؤ: يُشغَّل بالتطابق نفسه في Kotlin (engine/src/test/kotlin/game/Parity.kt) وهنا، ويُقارَن الناتج سطراً بسطر.
import { Game, configFor, type Config } from "../src/game.ts";
import { QIDS, type Action, type CaseLibrary } from "../src/model.ts";
import { canon, fnv, viewOf } from "../src/view.ts";

const DIFFS = [0, 1, 2, 1, 2, 0];

export function parityTrace(lib: CaseLibrary): string[] {
  const out: string[] = [];
  for (let k = 0; k < DIFFS.length; k++) {
    const idx = (k * 37 + 5) % lib.size;
    const base = configFor(DIFFS[k]);
    const cfg: Config = k % 2 === 1 ? { ...base, botPace: 0.5 } : base;
    const humans = k % 3 === 0 ? [0] : k % 3 === 1 ? [1, 2] : [];
    const g = new Game(lib.get(idx), cfg, 1000 + k * 7919, 0, humans);
    for (const h of humans) g.setSeat(h, "لاعب" + h, false);
    const did = new Set<string>();
    let errHash = 0x811c9dc5;
    let errCount = 0;
    const act = (seat: number, a: Action, now: number) => {
      const e = g.handle(seat, a, now);
      if (e !== null) {
        errCount++;
        errHash = fnv(errHash.toString(16) + e);
      }
    };
    out.push(`case k=${k} idx=${idx} id=${g.c.id} diff=${DIFFS[k]} humans=${humans.join(",")}`);
    for (let step = 1; step <= 3200; step++) {
      const now = step * 500;
      for (const h of humans) humanPolicy(g, h, now, did, act);
      g.tick(now);
      if (step % 20 === 0 || g.phase === "ended") {
        const hs = [0, 1, 2].map((s) => fnv(canon(viewOf(g, s, now))).toString(16));
        out.push(`t=${now} ph=${g.phase} r=${g.round} w=${g.window} cr=${g.credits} feed=${g.feed.length} err=${errCount}/${errHash.toString(16)} v=${hs.join(",")}`);
      }
      if (g.phase === "ended") break;
    }
    out.push(`end phase=${g.phase} result=${fnv(canon(viewOf(g, 0, 0).result)).toString(16)} stars=${g.result?.stars}`);
  }
  return out;
}

function humanPolicy(g: Game, h: number, now: number, did: Set<string>, act: (s: number, a: Action, n: number) => void): void {
  const seat = g.seats[h];
  if (g.phase === "round") {
    const start = g.phaseEndsAt - g.cfg.roundMs;
    const off = now - start;
    const key = (n: string) => `${n}:${h}:${g.round}`;
    if (off >= 8000 && !seat.moveUsed && !did.has(key("req"))) {
      did.add(key("req"));
      const t = g.c.topics.find((x) => x.kind === "person")!;
      act(h, { a: "request", topic: t.id }, now);
    }
    if (off >= 20000 && g.round >= 2 && !seat.abilityUsed && !did.has(key("abi"))) {
      did.add(key("abi"));
      const arg = h === 0 ? ([...seat.visible][0] ?? null) : null;
      act(h, { a: "ability", arg }, now);
    }
    if (off >= 40000 && !seat.moveUsed && !did.has(key("shr"))) {
      did.add(key("shr"));
      const own = [...seat.visible].find((id) => g.c.docById.get(id)!.owner === h);
      if (own !== undefined) act(h, { a: "share", doc: own, to: (h + 1) % 3 }, now);
    }
    if (off >= 60000 && g.round % 2 === 1 && !seat.ready) act(h, { a: "ready", on: true }, now);
    if (off >= 120000 && !seat.ready) act(h, { a: "ready", on: true }, now);
  } else if (g.phase === "accuse") {
    const start = g.phaseEndsAt - g.cfg.accuseMs;
    const off = now - start;
    const key = (n: string) => `${n}:${h}:${g.window}`;
    if (off >= 6000 && !did.has(key("fill"))) {
      did.add(key("fill"));
      const vis = [...seat.visible];
      for (const q of QIDS) {
        act(h, { a: "answer", q, opt: g.c.truth[q] }, now);
        const d0 = vis[0];
        const d1 = vis.find((id) => g.c.docById.get(id)!.owner !== g.c.docById.get(d0)!.owner);
        act(h, { a: "cite", q, slot: 0, doc: d0 }, now);
        if (d1 !== undefined) act(h, { a: "cite", q, slot: 1, doc: d1 }, now);
      }
    }
    if (off >= 40000 && !did.has(key("ok"))) {
      did.add(key("ok"));
      act(h, { a: "approve", on: true }, now);
    }
  }
}
