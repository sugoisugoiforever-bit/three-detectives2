// مضيف اختبار: يشغّل Worker وكائنات الغرف الحقيقية داخل Node، ويربط اتصالات `ws` الفعلية بنهاية الخادم.
import http from "node:http";
import type { AddressInfo } from "node:net";
import { WebSocketServer, type WebSocket } from "ws";
import worker from "../src/index.ts";
import { GameRoom } from "../src/room-do.ts";
import type { Env, StateLike, StorageLike, WSLike } from "../src/cf.ts";

type Handler = (ev: any) => void;

class End implements WSLike {
  peer!: End;
  handlers = new Map<string, Handler[]>();
  closed = false;
  accept(): void {}
  backlog: unknown[] = []; // رسائل وصلت قبل ربط مستمع (كما في workerd: تُحفظ حتى يُربط)
  addEventListener(type: string, fn: Handler): void {
    const l = this.handlers.get(type) ?? [];
    l.push(fn);
    this.handlers.set(type, l);
    if (type === "message" && this.backlog.length > 0) {
      const q = this.backlog;
      this.backlog = [];
      for (const ev of q) queueMicrotask(() => fn(ev));
    }
  }
  emit(type: string, ev: unknown): void {
    if (type === "message" && !this.handlers.has("message")) {
      this.backlog.push(ev);
      return;
    }
    for (const h of this.handlers.get(type) ?? []) h(ev);
  }
  send(data: string): void {
    if (this.closed) throw new Error("socket closed");
    const p = this.peer;
    queueMicrotask(() => p.emit("message", { data }));
  }
  close(code?: number, reason?: string): void {
    if (this.closed) return;
    this.closed = true;
    this.peer.closed = true;
    const p = this.peer;
    queueMicrotask(() => {
      p.emit("close", { code, reason });
      this.emit("close", { code, reason });
    });
  }
}

export class FakePair {
  0: End;
  1: End;
  constructor() {
    const a = new End(), b = new End();
    a.peer = b;
    b.peer = a;
    this[0] = a;
    this[1] = b;
  }
}

export class FakeStorage implements StorageLike {
  data = new Map<string, string>();
  alarmAt: number | null = null;
  async get<T>(k: string): Promise<T | undefined> {
    const v = this.data.get(k);
    return v === undefined ? undefined : (JSON.parse(v) as T);
  }
  async put(k: string, v: unknown): Promise<void> { this.data.set(k, JSON.stringify(v)); }
  async deleteAll(): Promise<void> { this.data.clear(); }
  async setAlarm(at: number): Promise<void> { this.alarmAt = at; }
  async deleteAlarm(): Promise<void> { this.alarmAt = null; }
}

export class Host {
  clock = { t: 1_700_000_000_000 };
  storages = new Map<string, FakeStorage>();
  rooms = new Map<string, GameRoom>();
  server!: http.Server;
  port = 0;
  private wss = new WebSocketServer({ noServer: true });

  env: Env = {
    ROOMS: {
      idFromName: (n: string) => n,
      get: (id: unknown) => ({
        fetch: async (input, init) => {
          const r = this.room(String(id));
          await (r as any).ready;
          return r.fetch(new Request(input as any, init));
        },
      }),
    },
  };

  storage(code: string): FakeStorage {
    let s = this.storages.get(code);
    if (!s) this.storages.set(code, (s = new FakeStorage()));
    return s;
  }

  room(code: string): GameRoom {
    let r = this.rooms.get(code);
    if (!r) {
      const storage = this.storage(code);
      const state: StateLike = { storage, blockConcurrencyWhile: (fn) => { pending.push(fn()); return Promise.resolve(undefined as any); } };
      const pending: Promise<unknown>[] = [];
      r = new GameRoom(state, this.env, {
        pair: FakePair as any,
        clock: () => this.clock.t,
        timer: false,
        wrapClient: (client) => Object.assign(new Response(null, { status: 200 }), { fakeClient: client }),
      });
      (r as any).ready = Promise.all(pending);
      this.rooms.set(code, r);
    }
    return r;
  }

  /** يحاكي إخلاء الكائن من الذاكرة ثم إيقاظه لاحقاً من التخزين. */
  evict(code: string): void {
    this.rooms.get(code)?.stopTimer();
    this.rooms.delete(code);
  }

  /** يقدّم الزمن ويشغّل دورات المؤقت لكل الغرف. */
  tick(ms: number, step = 500): void {
    for (let t = 0; t < ms; t += step) {
      this.clock.t += step;
      for (const r of this.rooms.values()) r.tick();
    }
  }

  async listen(): Promise<void> {
    this.server = http.createServer(async (req, res) => {
      const r = await worker.fetch(new Request("http://host" + req.url, { method: req.method }), this.env);
      res.writeHead(r.status, Object.fromEntries(r.headers));
      res.end(Buffer.from(await r.arrayBuffer()));
    });
    this.server.on("upgrade", async (req, socket, head) => {
      const path = (req.url ?? "").split("?")[0];
      const code = decodeURIComponent(path.split("/")[2] ?? "").toUpperCase();
      if (this.storages.has(code)) await (this.room(code) as any).ready;
      const r = await worker.fetch(new Request("http://host" + req.url, { headers: { upgrade: "websocket" } }), this.env);
      const client = (r as any).fakeClient as End | undefined;
      if (!client) {
        socket.write(`HTTP/1.1 ${r.status} X\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
        socket.destroy();
        return;
      }
      this.wss.handleUpgrade(req, socket, head, (ws: WebSocket) => {
        client.addEventListener("message", (ev: any) => ws.readyState === 1 && ws.send(ev.data));
        client.addEventListener("close", () => ws.close(1000));
        ws.on("message", (d) => { try { client.send(String(d)); } catch { /* مغلق */ } });
        ws.on("close", () => client.close(1000, "bye"));
        ws.on("error", () => client.close(1011, "error"));
      });
    });
    await new Promise<void>((ok) => this.server.listen(0, "127.0.0.1", ok));
    this.port = (this.server.address() as AddressInfo).port;
  }

  async close(): Promise<void> {
    for (const r of this.rooms.values()) r.stopTimer();
    this.wss.close();
    this.server.closeAllConnections();
    await new Promise((ok) => this.server.close(ok));
  }

  url(path: string): string { return `http://127.0.0.1:${this.port}${path}`; }
  wsUrl(path: string): string { return `ws://127.0.0.1:${this.port}${path}`; }
}
