import { library } from "../src/cases.ts";
import { chaosTrace } from "./chaos-driver.ts";
console.log(chaosTrace(library).join("\n"));
