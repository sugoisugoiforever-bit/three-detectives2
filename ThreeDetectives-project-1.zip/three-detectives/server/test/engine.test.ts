import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { library } from "../src/cases.ts";
import { Game, configFor } from "../src/game.ts";
import { viewOf, canon } from "../src/view.ts";
import { parityTrace } from "./parity-driver.ts";
import { chaosTrace } from "./chaos-driver.ts";

const golden = (n: string) => readFileSync(new URL(`./golden/${n}.txt`, import.meta.url), "utf8").trimEnd().split("\n");

test("التكافؤ مع محرك Kotlin: ألعاب مبرمجة", () => {
  const got = parityTrace(library);
  const want = golden("parity");
  assert.equal(got.length, want.length);
  for (let i = 0; i < want.length; i++) assert.equal(got[i], want[i], `السطر ${i + 1}`);
});

test("التكافؤ مع محرك Kotlin: حركات عشوائية وخاطئة", () => {
  const got = chaosTrace(library);
  const want = golden("chaos");
  assert.equal(got.length, want.length);
  for (let i = 0; i < want.length; i++) assert.equal(got[i], want[i], `السطر ${i + 1}`);
});

test("المكتبة: 180 قضية وثلاث سمات وقابلية الاختيار الحتمي", () => {
  assert.equal(library.size, 180);
  assert.deepEqual(library.themeNames().sort(), ["museum", "techco", "warehouse"]);
  assert.equal(library.pick("museum", 5).id, library.pick("museum", 5).id);
  assert.equal(library.pick("techco", 3).theme, "techco");
});

test("ألعاب كاملة بالبوتات تنتهي على كل المستويات ولكل السمات", () => {
  for (const d of [0, 1, 2]) {
    for (const theme of ["museum", "techco", "warehouse"]) {
      const g = new Game(library.pick(theme, d * 11 + 3), configFor(d), 77 + d, 0, []);
      let now = 0;
      while (g.phase !== "ended" && now < 3_000_000) { now += 500; g.tick(now); }
      assert.equal(g.phase, "ended", `${theme}/${d}`);
      assert.ok(g.result !== null);
      assert.ok(g.result!.stars >= 0 && g.result!.stars <= 3);
    }
  }
});

test("الحفظ والاستعادة: لعبة مستعادة في منتصفها تتابع بالتطابق نفسه", () => {
  for (const cut of [30_000, 245_000, 700_000, 1_150_000, 1_250_000]) {
    const mk = () => new Game(library.get(17), configFor(1), 4242, 0, [1]);
    const a = mk();
    a.setSeat(1, "لاعب", false);
    let now = 0;
    while (now < cut) { now += 500; a.tick(now); }
    const state = JSON.parse(JSON.stringify(a.toState()));
    const b = new Game(library.get(17), configFor(1), 4242, now, [1], state);
    assert.equal(canon(viewOf(b, 1, now)), canon(viewOf(a, 1, now)), "عند الاستعادة");
    while (a.phase !== "ended" && now < 3_000_000) {
      now += 500;
      a.tick(now);
      b.tick(now);
      assert.equal(canon(viewOf(b, 0, now)), canon(viewOf(a, 0, now)), `t=${now}`);
      assert.equal(canon(viewOf(b, 2, now)), canon(viewOf(a, 2, now)), `t=${now}`);
    }
    assert.equal(b.phase, a.phase);
    assert.equal(canon(b.result), canon(a.result));
  }
});
