import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// وحدة محرك اللعبة: Kotlin نقي بلا أي اعتماد على أندرويد،
// فيعمل داخل التطبيق (اللعب الفردي) ويُختبر على JVM عادي.
plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// الاختبار الذاتي للمحرك: ./gradlew :engine:selfTest
tasks.register<JavaExec>("selfTest") {
    group = "verification"
    description = "Runs the engine self-test (rules, bots, case library)."
    val test = sourceSets["test"]
    classpath = test.runtimeClasspath
    mainClass.set("game.SelfTestKt")
    workingDir = rootProject.projectDir
}
