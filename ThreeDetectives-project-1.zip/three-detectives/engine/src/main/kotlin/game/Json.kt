package game

/**
 * JSON مصغَّر بلا اعتماديات (يعمل على JVM وأندرويد):
 * الكائنات Map<String, Any?> والمصفوفات List<Any?> والأرقام Long/Double.
 */
object Json {
    fun parse(s: String): Any? {
        val p = Parser(s)
        val v = p.value()
        p.ws()
        if (p.i != s.length) throw IllegalArgumentException("JSON: trailing data at ${p.i}")
        return v
    }

    fun stringify(v: Any?, sortKeys: Boolean = false): String {
        val sb = StringBuilder()
        write(sb, v, sortKeys)
        return sb.toString()
    }

    private fun write(sb: StringBuilder, v: Any?, sort: Boolean) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(if (v) "true" else "false")
            is Int -> sb.append(v)
            is Long -> sb.append(v)
            is Double -> {
                if (v == Math.floor(v) && Math.abs(v) < 1e15) sb.append(v.toLong()) else sb.append(v)
            }
            is Number -> sb.append(v.toString())
            is String -> quote(sb, v)
            is Map<*, *> -> {
                sb.append('{')
                val keys = if (sort) v.keys.map { it as String }.sorted() else v.keys.map { it as String }
                var first = true
                for (k in keys) {
                    if (!first) sb.append(',')
                    first = false
                    quote(sb, k)
                    sb.append(':')
                    write(sb, v[k], sort)
                }
                sb.append('}')
            }
            is List<*> -> {
                sb.append('[')
                for ((i, x) in v.withIndex()) {
                    if (i > 0) sb.append(',')
                    write(sb, x, sort)
                }
                sb.append(']')
            }
            else -> throw IllegalArgumentException("JSON: unsupported type ${v::class}")
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (ch in s) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (ch < ' ') sb.append(String.format("\\u%04x", ch.code)) else sb.append(ch)
            }
        }
        sb.append('"')
    }

    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun value(): Any? {
            ws()
            if (i >= s.length) throw IllegalArgumentException("JSON: unexpected end")
            return when (s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> num()
            }
        }

        private fun lit(word: String, v: Any?): Any? {
            if (!s.startsWith(word, i)) throw IllegalArgumentException("JSON: bad literal at $i")
            i += word.length
            return v
        }

        private fun num(): Any {
            val st = i
            while (i < s.length && (s[i] in '0'..'9' || s[i] == '-' || s[i] == '+' || s[i] == '.' || s[i] == 'e' || s[i] == 'E')) i++
            val t = s.substring(st, i)
            if (t.isEmpty()) throw IllegalArgumentException("JSON: bad number at $st")
            return if (t.contains('.') || t.contains('e') || t.contains('E')) t.toDouble() else t.toLong()
        }

        private fun str(): String {
            i++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw IllegalArgumentException("JSON: unterminated string")
                val ch = s[i++]
                when (ch) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        val e = s[i++]
                        when (e) {
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000c')
                            'u' -> {
                                sb.append(s.substring(i, i + 4).toInt(16).toChar())
                                i += 4
                            }
                            else -> sb.append(e)
                        }
                    }
                    else -> sb.append(ch)
                }
            }
        }

        private fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            ws()
            if (s[i] == ']') {
                i++
                return out
            }
            while (true) {
                out.add(value())
                ws()
                val ch = s[i++]
                if (ch == ']') return out
                if (ch != ',') throw IllegalArgumentException("JSON: expected , or ] at ${i - 1}")
            }
        }

        private fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            ws()
            if (s[i] == '}') {
                i++
                return out
            }
            while (true) {
                ws()
                val k = str()
                ws()
                if (s[i++] != ':') throw IllegalArgumentException("JSON: expected : at ${i - 1}")
                out[k] = value()
                ws()
                val ch = s[i++]
                if (ch == '}') return out
                if (ch != ',') throw IllegalArgumentException("JSON: expected , or } at ${i - 1}")
            }
        }
    }
}

// مساعدات القراءة المنمَّطة
@Suppress("UNCHECKED_CAST")
fun Any?.asMap(): Map<String, Any?> = this as Map<String, Any?>

@Suppress("UNCHECKED_CAST")
fun Any?.asList(): List<Any?> = this as List<Any?>

fun Map<String, Any?>.str(k: String): String = this[k] as String
fun Map<String, Any?>.strOrNull(k: String): String? = this[k] as String?
fun Map<String, Any?>.int(k: String): Int = (this[k] as Number).toInt()
fun Map<String, Any?>.long(k: String): Long = (this[k] as Number).toLong()
fun Map<String, Any?>.bool(k: String): Boolean = this[k] as Boolean
fun Map<String, Any?>.obj(k: String): Map<String, Any?> = this[k].asMap()
fun Map<String, Any?>.list(k: String): List<Any?> = this[k].asList()
fun Map<String, Any?>.strList(k: String): List<String> = this[k].asList().map { it as String }
