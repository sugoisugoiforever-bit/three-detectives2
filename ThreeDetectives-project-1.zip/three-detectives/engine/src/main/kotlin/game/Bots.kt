package game

/**
 * بوتات قائمة على القواعد (بدون أي نموذج لغوي): تتأخر قليلاً، تسأل عن الرموز، ترد على الأسئلة،
 * وتملأ مسودة الاتهام من قناعتها هي. تتصرف دوماً عبر Game.handle كأي لاعب آخر.
 */
class BotDriver(private val g: Game) {
    private val abilityRound = IntArray(3) { 1 + g.rng.nextInt(3) }
    private val guessAt = LongArray(3)
    private val overrides = HashMap<String, Int>()

    private fun delay(minMs: Long, maxMs: Long): Long {
        val span = (maxMs - minMs).toInt().coerceAtLeast(1)
        return ((minMs + g.rng.nextInt(span)) * g.cfg.botPace).toLong()
    }

    private fun value(id: String): Int = g.c.claims.filter { id in it.needs }.sumOf { Math.abs(it.w) }

    private fun skilled(): Boolean = g.rng.nextInt(100) < (g.cfg.botSkill * 100).toInt()

    // ───────── جدولة ─────────
    fun onRoundStart(now: Long) {
        for (i in 0..2) {
            val s = g.seats[i]
            if (!s.bot) continue
            s.nextAt = now + delay(6_000, 25_000)
            s.readyAt = Long.MAX_VALUE
        }
    }

    fun onAccuseStart(now: Long) {
        overrides.clear()
        for (i in 0..2) {
            val s = g.seats[i]
            s.accuseAt = now + delay(4_000, 16_000)
            guessAt[i] = s.accuseAt + delay(25_000, 45_000)
        }
    }

    /** يُستدعى عند تحويل مقعد بشري إلى بوت أثناء اللعب. */
    fun adopt(i: Int, now: Long) {
        val s = g.seats[i]
        if (g.phase == "round") {
            s.nextAt = now + delay(4_000, 12_000)
            s.readyAt = Long.MAX_VALUE
        } else if (g.phase == "accuse") {
            s.accuseAt = now + delay(3_000, 8_000)
            guessAt[i] = s.accuseAt + delay(25_000, 45_000)
        }
    }

    /** وصل سؤال جديد: البوتات التي لم تستهلك حركتها تنتبه له. */
    fun onRequest(now: Long) {
        for (i in 0..2) {
            val s = g.seats[i]
            if (!s.bot || s.moveUsed) continue
            if (pendingReply(i) == null) continue
            s.ready = false
            s.readyAt = Long.MAX_VALUE
            s.nextAt = minOf(s.nextAt, now + delay(2_000, 7_000))
        }
    }

    fun onTick(now: Long) {
        for (i in 0..2) {
            val s = g.seats[i]
            if (!s.bot) continue
            when (g.phase) {
                "round" -> roundTick(i, s, now)
                "accuse" -> accuseTick(i, s, now)
                else -> return
            }
            if (g.phase == "ended") return
        }
    }

    // ───────── الجولة ─────────
    private fun roundTick(i: Int, s: Seat, now: Long) {
        if (s.ready) return
        if (now >= s.nextAt) {
            var acted = false
            if (!s.moveUsed) acted = act(i, now)
            useAbility(i, now)
            if (acted || s.moveUsed) {
                s.nextAt = Long.MAX_VALUE
                s.readyAt = now + delay(3_000, 9_000)
            } else {
                s.nextAt = now + 15_000
                if (s.readyAt == Long.MAX_VALUE) s.readyAt = now + delay(4_000, 10_000)
            }
        }
        if (now >= s.readyAt && !s.ready) g.handle(i, Action.Ready(true), now)
    }

    /** أقدم سؤال يمكن لهذا البوت الردّ عليه: (السؤال، وثائقه المطابقة مرتبةً بالأهمية). */
    private fun pendingReply(i: Int): Pair<Req, List<Doc>>? {
        val s = g.seats[i]
        for (r in g.requests) {
            if (r.from == i || r.id in s.answered) continue
            val docs = s.visible.map { g.c.docById[it]!! }
                .filter { it.owner == i && it.topics.contains(r.topic) && it.id !in g.seats[r.from].visible }
                .sortedByDescending { value(it.id) }
            if (docs.isNotEmpty()) return Pair(r, docs)
        }
        return null
    }

    private fun act(i: Int, now: Long): Boolean {
        val s = g.seats[i]
        // 1) الردّ على سؤال زميل بمشاركة الوثيقة الأنسب
        val rep = pendingReply(i)
        if (rep != null && g.credits >= 1) {
            val (r, docs) = rep
            val pick = if (skilled() || docs.size == 1) docs[0] else docs[g.rng.nextInt(docs.size)]
            val err = g.handle(i, Action.Share(pick.id, r.from), now)
            if (err == null) return true
            s.answered.add(r.id)
        }
        // 2) سؤال عن رمزٍ يظهر في وثيقة واحدة فقط من وثائقي
        val tok = pickTopic(i)
        if (tok != null) return g.handle(i, Action.Request(tok), now) == null
        return false
    }

    private fun pickTopic(i: Int): String? {
        val s = g.seats[i]
        val asked = g.requests.map { it.topic }.toSet()
        val keyCount = HashMap<String, Int>()
        val personCount = HashMap<String, Int>()
        val best = HashMap<String, Int>()
        for (id in s.visible) {
            val d = g.c.docById[id]!!
            val v = value(id)
            for (t in d.topics) {
                val kind = g.c.topicById[t]!!.kind
                if (kind == "key") {
                    keyCount[t] = (keyCount[t] ?: 0) + 1
                    best[t] = maxOf(best[t] ?: 0, v)
                } else if (kind == "person" && v > 0) {
                    personCount[t] = (personCount[t] ?: 0) + 1
                    best[t] = maxOf(best[t] ?: 0, v)
                }
            }
        }
        // الرموز أولاً، ثم الأشخاص الواردون في وثائق ذات صلة
        for (counts in listOf(keyCount, personCount)) {
            val cands = counts.filter { it.value == 1 && it.key !in asked }.keys
                .sortedWith(compareByDescending<String> { best[it] ?: 0 }.thenBy { it })
            if (cands.isEmpty()) continue
            return if (skilled()) cands[0] else cands[g.rng.nextInt(cands.size)]
        }
        return null
    }

    private fun useAbility(i: Int, now: Long) {
        val s = g.seats[i]
        if (s.abilityUsed || g.round < abilityRound[i]) return
        when (i) {
            0 -> {
                val d = s.visible.filter { it !in g.audits }.maxByOrNull { value(it) } ?: return
                g.handle(0, Action.Ability(d), now)
            }
            else -> g.handle(i, Action.Ability(null), now)
        }
    }

    // ───────── الاتهام ─────────
    private fun accuseTick(i: Int, s: Seat, now: Long) {
        if (now < s.accuseAt) return
        s.accuseAt = now + delay(3_000, 7_000)
        for (q in QIDS) {
            if (g.phase != "accuse") return
            fillAnswer(i, q, now)
            g.answers[q]?.let { fillCites(i, q, it, now) }
        }
        if (g.phase == "accuse") decide(i, now)
    }

    private fun fillAnswer(i: Int, q: String, now: Long) {
        val s = g.seats[i]
        val cur = g.answers[q]
        val bel = g.belief(s.visible, q)
        if (cur == null) {
            val pick = bel ?: if (now >= guessAt[i]) g.rng.nextInt(g.c.optionCount(q)) else null
            if (pick != null) g.handle(i, Action.Answer(q, pick), now)
        } else if (bel != null && bel != cur) {
            val by = g.answerBy[q]
            val n = overrides[q] ?: 0
            if (by != null && g.seats[by].bot && n < 2) {
                overrides[q] = n + 1
                g.handle(i, Action.Answer(q, bel), now)
            }
        }
    }

    private fun fillCites(i: Int, q: String, opt: Int, now: Long) {
        val s = g.seats[i]
        val cur = g.cites[q]!!
        if (cur[0] != null && cur[1] != null) return
        // الوثائق الداعمة للإجابة المختارة حسب وزن الأدلة، ثم الأهم فالأهم
        val supporting = g.c.claims.filter { it.q == q && it.opt == opt && it.w > 0 && s.visible.containsAll(it.needs) }
            .sortedByDescending { it.w }.flatMap { it.needs }.distinct()
        val rest = s.visible.sortedByDescending { value(it) }
        val order = (supporting + rest).distinct().filter { it in s.visible }
        for (slot in 0..1) {
            if (cur[slot] != null) continue
            val other = cur[1 - slot]
            val otherOwner = other?.let { g.c.docById[it]!!.owner }
            val pick = order.firstOrNull { id ->
                id != other && (otherOwner == null || g.c.docById[id]!!.owner != otherOwner)
            } ?: return
            g.handle(i, Action.Cite(q, slot, pick), now)
        }
    }

    private fun decide(i: Int, now: Long) {
        val s = g.seats[i]
        if (g.approvals[i] || !g.draftValid()) return
        for (q in QIDS) {
            val bel = g.belief(s.visible, q)
            val cur = g.answers[q]
            if (bel != null && bel != cur) {
                val key = "$q:$cur"
                if (s.objected.add(key)) g.note("accuse", i, -1, "${ROLE_AR[i]} يعترض على إجابة «${QUESTION_AR[q]}»")
                return
            }
        }
        // في النافذة الأخيرة لا تحسم البوتات القرار قبل أن يقول البشر كلمتهم
        if (g.window == 2) {
            val humans = (0..2).filter { !g.seats[it].bot && g.seats[it].connected }
            val humansDone = humans.all { g.approvals[it] }
            val remaining = g.phaseEndsAt - now
            if (humans.isNotEmpty() && !humansDone && remaining > 30_000) return
        }
        g.handle(i, Action.Approve(true), now)
    }
}
