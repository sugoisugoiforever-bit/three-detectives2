package game

/** ما يراه مقعدٌ واحد من اللعبة؛ لا يحتوي أي سرّ لا يعرفه صاحبه. */
fun Game.view(seat: Int, now: Long): PView {
    val me = seats[seat]
    val docs = me.visible.map { id ->
        val d = c.docById[id]!!
        val own = d.owner == seat
        PDoc(
            d.id, d.owner, d.round, d.kind, d.title, d.stamp, d.serial, d.lines, d.topics,
            from = if (own) -1 else (me.from[id] ?: d.owner),
            // لا يعرف المستلِم مع من شاركها المرسِل بعده؛ هذا ما تكشفه قدرة الاعتراض
            copies = if (own) (copies[id] ?: emptySet<Int>()).sorted() else listOf(d.owner, seat).sorted(),
            audit = if (seat == 0) audits[id] else null,
        )
    }
    val seen = HashSet<String>()
    for (d in docs) seen.addAll(d.topics)
    val topics = c.topics.filter { it.kind == "person" || it.kind == "place" || it.id in seen }

    val reqs = requests.map { r ->
        val t = c.topicById[r.topic]!!
        val matches = if (r.from == seat) emptyList() else me.visible.filter { id ->
            val d = c.docById[id]!!
            d.owner == seat && d.topics.contains(r.topic) && id !in seats[r.from].visible
        }
        PReq(r.id, r.from, r.topic, t.label, r.round, matches, r.from == seat)
    }
    val players = seats.mapIndexed { i, s ->
        PPlayer(i, ROLE_IDS[i], s.name, s.bot, s.connected, s.ready, s.moveUsed, s.abilityUsed)
    }
    val citedIds = LinkedHashSet<String>()
    for (q in QIDS) for (d in cites[q]!!) if (d != null) citedIds.add(d)
    val cited = citedIds.map { id ->
        val d = c.docById[id]!!
        PProof(d.id, d.title, d.owner)
    }
    return PView(
        phase = phase, round = round, window = window,
        endsInMs = if (phase == "ended") 0 else maxOf(0L, phaseEndsAt - now),
        credits = credits, creditsMax = cfg.credits, seat = seat, players = players,
        info = CaseInfo(c.id, c.theme, c.title, c.brief, c.org, c.date, c.window, c.persons, c.questions),
        docs = docs, topics = topics,
        feed = feed.filter { it.to == -1 || it.to == seat },
        requests = reqs, interceptArmed = if (seat == 2) interceptArmed else false,
        draft = PDraft(
            answers = LinkedHashMap(answers),
            cites = QIDS.associateWith { cites[it]!!.toList() },
            approvals = approvals.toList(), valid = draftValid(), required = required(), window = window,
        ),
        result = result,
        cited = cited,
    )
}

// ───────────── JSON ─────────────

private fun lineJson(l: Line): Map<String, Any?> {
    val m = LinkedHashMap<String, Any?>()
    m["t"] = l.t
    l.k?.let { m["k"] = it }
    l.v?.let { m["v"] = it }
    l.c?.let { m["c"] = it }
    l.who?.let { m["who"] = it }
    l.time?.let { m["time"] = it }
    return m
}

private fun lineFrom(m: Map<String, Any?>) = Line(
    m.str("t"), m.strOrNull("k"), m.strOrNull("v"),
    (m["c"] as List<*>?)?.map { it as String }, m.strOrNull("who"), m.strOrNull("time"),
)

private fun personJson(p: Person) = linkedMapOf<String, Any?>(
    "id" to p.id, "name" to p.name, "first" to p.first, "g" to p.g, "job" to p.job, "portrait" to p.portrait,
)

private fun personFrom(m: Map<String, Any?>) = Person(m.str("id"), m.str("name"), m.str("first"), m.str("g"), m.str("job"), m.int("portrait"))

private fun optJson(o: Opt) = linkedMapOf<String, Any?>("id" to o.id, "label" to o.label, "sub" to o.sub, "person" to o.person)
private fun optFrom(m: Map<String, Any?>) = Opt(m.str("id"), m.str("label"), m.strOrNull("sub"), m.strOrNull("person"))

private fun questionJson(q: Question) = linkedMapOf<String, Any?>("id" to q.id, "prompt" to q.prompt, "options" to q.options.map { optJson(it) })
private fun questionFrom(m: Map<String, Any?>) = Question(m.str("id"), m.str("prompt"), m.list("options").map { optFrom(it.asMap()) })

private fun topicJson(t: Topic) = linkedMapOf<String, Any?>("id" to t.id, "kind" to t.kind, "label" to t.label)
private fun topicFrom(m: Map<String, Any?>) = Topic(m.str("id"), m.str("kind"), m.str("label"))

private fun docJson(d: PDoc) = linkedMapOf<String, Any?>(
    "id" to d.id, "owner" to d.owner, "round" to d.round, "kind" to d.kind, "title" to d.title, "stamp" to d.stamp,
    "serial" to d.serial, "lines" to d.lines.map { lineJson(it) }, "topics" to d.topics, "from" to d.from,
    "copies" to d.copies, "audit" to d.audit,
)

private fun docFrom(m: Map<String, Any?>) = PDoc(
    m.str("id"), m.int("owner"), m.int("round"), m.str("kind"), m.str("title"), m.str("stamp"), m.int("serial"),
    m.list("lines").map { lineFrom(it.asMap()) }, m.strList("topics"), m.int("from"),
    m.list("copies").map { (it as Number).toInt() }, m.strOrNull("audit"),
)

private fun noticeJson(n: Notice) = linkedMapOf<String, Any?>(
    "id" to n.id, "round" to n.round, "kind" to n.kind, "from" to n.from, "to" to n.to, "text" to n.text, "doc" to n.doc,
)

private fun noticeFrom(m: Map<String, Any?>) = Notice(m.int("id"), m.int("round"), m.str("kind"), m.int("from"), m.int("to"), m.str("text"), m.strOrNull("doc"))

private fun reqJson(r: PReq) = linkedMapOf<String, Any?>(
    "id" to r.id, "from" to r.from, "topic" to r.topic, "label" to r.label, "round" to r.round,
    "matches" to r.matches, "mine" to r.mine,
)

private fun reqFrom(m: Map<String, Any?>) = PReq(m.int("id"), m.int("from"), m.str("topic"), m.str("label"), m.int("round"), m.strList("matches"), m.bool("mine"))

private fun playerJson(p: PPlayer) = linkedMapOf<String, Any?>(
    "seat" to p.seat, "role" to p.role, "name" to p.name, "bot" to p.bot, "connected" to p.connected,
    "ready" to p.ready, "moveUsed" to p.moveUsed, "abilityUsed" to p.abilityUsed,
)

private fun playerFrom(m: Map<String, Any?>) = PPlayer(
    m.int("seat"), m.str("role"), m.str("name"), m.bool("bot"), m.bool("connected"),
    m.bool("ready"), m.bool("moveUsed"), m.bool("abilityUsed"),
)

private fun draftJson(d: PDraft) = linkedMapOf<String, Any?>(
    "answers" to d.answers, "cites" to d.cites, "approvals" to d.approvals,
    "valid" to d.valid, "required" to d.required, "window" to d.window,
)

private fun draftFrom(m: Map<String, Any?>): PDraft {
    val ans = LinkedHashMap<String, Int?>()
    for ((k, v) in m.obj("answers")) ans[k] = (v as Number?)?.toInt()
    val ct = LinkedHashMap<String, List<String?>>()
    for ((k, v) in m.obj("cites")) ct[k] = v.asList().map { it as String? }
    return PDraft(ans, ct, m.list("approvals").map { it as Boolean }, m.bool("valid"), m.int("required"), m.int("window"))
}

private fun resultJson(r: PResult) = linkedMapOf<String, Any?>(
    "win" to r.win, "stars" to r.stars, "correct" to r.correct, "ironclad" to r.ironclad, "window" to r.window,
    "solution" to r.solution.map { s ->
        linkedMapOf<String, Any?>("q" to s.q, "label" to s.label, "proof" to s.proof.map { p ->
            linkedMapOf<String, Any?>("id" to p.id, "title" to p.title, "owner" to p.owner)
        })
    },
)

private fun resultFrom(m: Map<String, Any?>) = PResult(
    m.bool("win"), m.int("stars"), m.list("correct").map { it as Boolean }, m.list("ironclad").map { it as Boolean },
    m.int("window"),
    m.list("solution").map { s ->
        val sm = s.asMap()
        PSolution(sm.str("q"), sm.str("label"), sm.list("proof").map { p ->
            val pm = p.asMap()
            PProof(pm.str("id"), pm.str("title"), pm.int("owner"))
        })
    },
)

fun PView.toJson(): Map<String, Any?> = linkedMapOf(
    "phase" to phase, "round" to round, "window" to window, "endsInMs" to endsInMs, "credits" to credits,
    "creditsMax" to creditsMax, "seat" to seat,
    "players" to players.map { playerJson(it) },
    "info" to linkedMapOf<String, Any?>(
        "id" to info.id, "theme" to info.theme, "title" to info.title, "brief" to info.brief, "org" to info.org,
        "date" to info.date, "window" to info.window, "persons" to info.persons.map { personJson(it) },
        "questions" to info.questions.map { questionJson(it) },
    ),
    "docs" to docs.map { docJson(it) },
    "topics" to topics.map { topicJson(it) },
    "feed" to feed.map { noticeJson(it) },
    "requests" to requests.map { reqJson(it) },
    "interceptArmed" to interceptArmed,
    "draft" to draftJson(draft),
    "result" to result?.let { resultJson(it) },
    "cited" to cited.map { linkedMapOf<String, Any?>("id" to it.id, "title" to it.title, "owner" to it.owner) },
)

fun pviewFromJson(m: Map<String, Any?>): PView {
    val im = m.obj("info")
    return PView(
        phase = m.str("phase"), round = m.int("round"), window = m.int("window"), endsInMs = m.long("endsInMs"),
        credits = m.int("credits"), creditsMax = m.int("creditsMax"), seat = m.int("seat"),
        players = m.list("players").map { playerFrom(it.asMap()) },
        info = CaseInfo(
            im.str("id"), im.str("theme"), im.str("title"), im.str("brief"), im.str("org"), im.str("date"),
            im.strList("window"), im.list("persons").map { personFrom(it.asMap()) },
            im.list("questions").map { questionFrom(it.asMap()) },
        ),
        docs = m.list("docs").map { docFrom(it.asMap()) },
        topics = m.list("topics").map { topicFrom(it.asMap()) },
        feed = m.list("feed").map { noticeFrom(it.asMap()) },
        requests = m.list("requests").map { reqFrom(it.asMap()) },
        interceptArmed = m.bool("interceptArmed"),
        draft = draftFrom(m.obj("draft")),
        result = (m["result"] as Map<*, *>?)?.let { resultFrom(it.asMap()) },
        cited = (m["cited"] as List<*>?)?.map { c ->
            val cm = c.asMap()
            PProof(cm.str("id"), cm.str("title"), cm.int("owner"))
        } ?: emptyList(),
    )
}
