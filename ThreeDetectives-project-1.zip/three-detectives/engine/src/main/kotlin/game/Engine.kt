package game

data class Config(
    val credits: Int = 7,
    val roundMs: Long = 240_000,
    val accuseMs: Long = 180_000,
    val botSkill: Double = 0.7,   // احتمال أن يختار البوت أفضل وثيقة (وليس خطأً بشرياً)
    val botPace: Double = 1.0,    // مضاعف تأخير البوت (أقل = أسرع)
) {
    companion object {
        fun easy() = Config(credits = 8, botSkill = 0.9)
        fun normal() = Config()
        fun hard() = Config(credits = 6, botSkill = 0.5)
    }
}

/** مولّد أرقام xorshift32: بسيط وقابل للنقل حرفياً إلى TypeScript. */
class Rng(seed: Int) {
    private var s: Int = if (seed == 0) 0x1F123BB5 else seed
    fun next(): Int {
        var x = s
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        s = x
        return x
    }

    fun nextInt(n: Int): Int = ((next().toLong() and 0xFFFFFFFFL) % n).toInt()
}

class Seat(var name: String, var bot: Boolean) {
    var connected = true
    var ready = false
    var moveUsed = false
    var abilityUsed = false
    val visible = LinkedHashSet<String>()
    val from = HashMap<String, Int>()
    // جدولة البوت
    var nextAt = Long.MAX_VALUE
    var readyAt = 0L
    var accuseAt = 0L
    var abilityDone = false
    val answered = HashSet<Int>()
    val objected = HashSet<String>()
}

data class Req(val id: Int, val from: Int, val topic: String, val round: Int)
data class WinRes(val correct: List<Boolean>, val ironclad: List<Boolean>)

val KIND_AR = mapOf(
    "bank" to "كشف حساب مصرفي", "invoice" to "فاتورة", "report" to "تقرير ميداني", "witness" to "إفادة شاهد",
    "calls" to "سجل مكالمات", "chat" to "محادثة نصية", "access" to "سجل دخول ومراقبة", "memo" to "مذكرة تدقيق",
)

class Game(val c: Case, val cfg: Config, seed: Int, now: Long, humans: Set<Int> = emptySet()) {
    val rng = Rng(seed)
    val seats = Array(3) { Seat(ROLE_AR[it], true) }
    var phase = "round"
    var round = 0
    var window = 0
    var phaseEndsAt = 0L
    var credits = cfg.credits
    val delivered = HashSet<String>()
    val copies = HashMap<String, MutableSet<Int>>()
    val feed = ArrayList<Notice>()
    val requests = ArrayList<Req>()
    val answers = LinkedHashMap<String, Int?>()
    val cites = LinkedHashMap<String, Array<String?>>()
    val approvals = BooleanArray(3)
    val answerBy = HashMap<String, Int>()   // آخر من عدّل إجابة السؤال (للبوتات)
    var interceptArmed = false
    val audits = HashMap<String, String>()
    val windows = HashMap<Int, WinRes>()
    var result: PResult? = null
    private var nextId = 1
    private val bots = BotDriver(this)

    init {
        for (q in QIDS) {
            answers[q] = null
            cites[q] = arrayOf(null, null)
        }
        for (h in humans) seats[h].bot = false
        startRound(1, now)
    }

    // ───────── مساعدات ─────────
    fun note(kind: String, from: Int, to: Int, text: String, doc: String? = null): Int {
        val id = nextId++
        feed.add(Notice(id, round, kind, from, to, text, doc))
        return id
    }

    private fun noteOthers(kind: String, from: Int, text: String) {
        for (s in 0..2) if (s != from) note(kind, from, s, text)
    }

    fun setSeat(seat: Int, name: String, bot: Boolean) {
        seats[seat].name = name
        seats[seat].bot = bot
    }

    fun seesTopic(seat: Int, topicId: String): Boolean =
        seats[seat].visible.any { c.docById[it]!!.topics.contains(topicId) }

    /** تقدير اللاعب للإجابة من الوثائق التي يراها (يستعمله البوت). */
    fun belief(visible: Set<String>, q: String): Int? {
        val sc = IntArray(c.optionCount(q))
        for (cl in c.claims) if (cl.q == q && visible.containsAll(cl.needs)) sc[cl.opt] += cl.w
        val top = sc.max()
        if (top <= 0) return null
        val idx = sc.indices.filter { sc[it] == top }
        return if (idx.size == 1) idx[0] else null
    }

    // ───────── سير الجولات ─────────
    fun startRound(r: Int, now: Long) {
        round = r
        phase = "round"
        phaseEndsAt = now + cfg.roundMs
        for (s in seats) {
            s.ready = false
            s.moveUsed = false
        }
        note("round", -1, -1, "بدأت الجولة $r من 5")
        for (d in c.docs) if (d.round == r) deliver(d)
        bots.onRoundStart(now)
    }

    private fun deliver(d: Doc) {
        if (!delivered.add(d.id)) return
        seats[d.owner].visible.add(d.id)
        copies.getOrPut(d.id) { HashSet() }.add(d.owner)
        note("doc", -1, d.owner, "وصلتك وثيقة جديدة: «${d.title}»", d.id)
    }

    fun endRound(now: Long) {
        if (round < 4) startRound(round + 1, now) else openAccusation(if (round == 4) 1 else 2, now)
    }

    private fun openAccusation(w: Int, now: Long) {
        phase = "accuse"
        window = w
        phaseEndsAt = now + cfg.accuseMs
        approvals.fill(false)
        note("accuse", -1, -1, if (w == 1) "فُتحت نافذة الاتهام: يلزم إجماع الثلاثة" else "نافذة الاتهام الأخيرة: تكفي موافقة اثنين")
        bots.onAccuseStart(now)
    }

    /** تنتهي الجولة عندما يجهز كل المتصلين (المنقطع لا يعطّل زميليه). */
    fun checkAllReady(now: Long) {
        if (phase == "round" && seats.any { it.ready } && seats.all { it.ready || !it.connected }) endRound(now)
    }

    /** يحوّل مقعداً إلى بوت (انقطاع لاعب أو مقعد شاغر). */
    fun takeover(seat: Int, name: String, now: Long) {
        val s = seats[seat]
        s.name = name
        s.bot = true
        s.connected = true
        bots.adopt(seat, now)
    }

    /** يعيد مقعداً إلى لاعب بشري. */
    fun release(seat: Int, name: String) {
        val s = seats[seat]
        s.name = name
        s.bot = false
        s.connected = true
    }

    fun tick(now: Long) {
        if (phase == "ended") return
        bots.onTick(now)
        if (phase == "ended") return
        if (now >= phaseEndsAt) {
            if (phase == "round") endRound(now)
            else if (phase == "accuse") {
                if (window == 1) {
                    note("accuse", -1, -1, "انتهت النافذة دون اتهام. أمامكم جولة أخيرة")
                    startRound(5, now)
                } else finish()
            }
        }
    }

    // ───────── الحركات ─────────
    /** يعيد null عند النجاح، أو رسالة خطأ عربية تُعرض للاعب. */
    fun handle(seat: Int, a: Action, now: Long): String? {
        if (phase == "ended") return "انتهت القضية"
        return when (a) {
            is Action.Share -> share(seat, a)
            is Action.Request -> request(seat, a, now)
            is Action.Template -> template(seat, a)
            is Action.Ability -> ability(seat, a)
            is Action.Ready -> {
                if (phase != "round") "لا جولة جارية الآن"
                else {
                    seats[seat].ready = a.on
                    checkAllReady(now)
                    null
                }
            }
            is Action.Answer -> answer(seat, a)
            is Action.Cite -> cite(seat, a)
            is Action.Approve -> approve(seat, a, now)
        }
    }

    private fun commCheck(seat: Int): String? {
        if (phase != "round") return "التواصل متاح أثناء الجولات فقط"
        if (seats[seat].moveUsed) return "استهلكتَ حركتك في هذه الجولة"
        return null
    }

    private fun share(seat: Int, a: Action.Share): String? {
        commCheck(seat)?.let { return it }
        val s = seats[seat]
        val d = c.docById[a.doc] ?: return "وثيقة غير موجودة"
        if (d.owner != seat || a.doc !in s.visible) return "يمكنك مشاركة وثائقك الأصلية فقط"
        if (a.to !in 0..2 || a.to == seat) return "اختر زميلاً آخر"
        if (a.doc in seats[a.to].visible) return "هذه الوثيقة عند زميلك أصلاً"
        if (credits < 1) return "نفدت القطع النحاسية"
        credits -= 1
        s.moveUsed = true
        seats[a.to].visible.add(a.doc)
        seats[a.to].from[a.doc] = seat
        copies.getOrPut(a.doc) { HashSet() }.add(a.to)
        note("share", seat, seat, "أرسلتَ «${d.title}» إلى ${ROLE_AR[a.to]}", a.doc)
        note("share", seat, a.to, "${ROLE_AR[seat]} أرسل إليك وثيقة: «${d.title}»", a.doc)
        if (interceptArmed && seat != 2 && a.to != 2) {
            interceptArmed = false
            note("intercept", -1, 2, "اعتراض ناجح: أُرسلت وثيقة «${d.title}» (${KIND_AR[d.kind]}) من ${ROLE_AR[seat]} إلى ${ROLE_AR[a.to]}")
        }
        return null
    }

    private fun request(seat: Int, a: Action.Request, now: Long): String? {
        commCheck(seat)?.let { return it }
        val t = c.topicById[a.topic] ?: return "موضوع غير معروف"
        if (t.kind == "key" && !seesTopic(seat, a.topic)) return "لم تعثر على هذا الرمز في وثائقك"
        seats[seat].moveUsed = true
        val id = note("request", seat, -1, "${ROLE_AR[seat]} يسأل: هل عندك شيء عن «${t.label}»؟")
        requests.add(Req(id, seat, a.topic, round))
        bots.onRequest(now)
        return null
    }

    private fun slotTopic(seat: Int, a: Action.Template, slot: String, kind: String): Topic? {
        val t = c.topicById[a.slots[slot] ?: return null] ?: return null
        if (t.kind != kind) return null
        // الأوقات والرموز لا تُستعمل إلا إن ظهرت في وثائق اللاعب نفسه
        if ((kind == "key" || kind == "time") && !seesTopic(seat, t.id)) return null
        return t
    }

    private fun slotOption(a: Action.Template, slot: String, q: String): Opt? {
        val id = a.slots[slot] ?: return null
        return c.question(q).options.firstOrNull { it.id == id }
    }

    fun renderTemplate(seat: Int, a: Action.Template): String? = when (a.tpl) {
        "T1" -> {
            val p = slotTopic(seat, a, "person", "person")
            val l = slotTopic(seat, a, "place", "place")
            val t = slotTopic(seat, a, "time", "time")
            if (p == null || l == null || t == null) null
            else {
                val g = c.persons.first { it.id == p.id }.g
                "${p.label} ${if (g == "f") "كانت" else "كان"} في ${l.label} الساعة ${t.label}"
            }
        }
        "T2" -> slotTopic(seat, a, "person", "person")?.let { "أشك في ${it.label}" }
        "T3" -> slotTopic(seat, a, "person", "person")?.let { "أقترح استبعاد ${it.label} من المشتبهين" }
        "T4" -> slotOption(a, "how", "how")?.let { "الأسلوب على الأرجح: ${it.label}" }
        "T5" -> slotOption(a, "why", "why")?.let { "الدافع على الأرجح: ${it.label}" }
        else -> null
    }

    private fun template(seat: Int, a: Action.Template): String? {
        commCheck(seat)?.let { return it }
        if (credits < 1) return "نفدت القطع النحاسية"
        val text = renderTemplate(seat, a) ?: return "أكمل خانات القالب بشكل صحيح"
        credits -= 1
        seats[seat].moveUsed = true
        note("template", seat, -1, "${ROLE_AR[seat]}: $text")
        return null
    }

    private fun ability(seat: Int, a: Action.Ability): String? {
        if (phase != "round") return "القدرات تُستخدم أثناء الجولات فقط"
        val s = seats[seat]
        if (s.abilityUsed) return "استخدمتَ قدرتك في هذه الجلسة"
        when (seat) {
            0 -> {
                val id = a.arg ?: return "اختر وثيقة للتدقيق"
                val d = c.docById[id]
                if (d == null || id !in s.visible) return "اختر وثيقة تراها على مكتبك"
                val res = if (d.rel == "decisive") "decisive" else "noise"
                audits[id] = res
                s.abilityUsed = true
                note("ability", 0, 0, "نتيجة التدقيق: «${d.title}» ${if (res == "decisive") "وثيقة حاسمة للحل" else "تشويش لا يفيد الحل"}", id)
                noteOthers("ability", 0, "المحلل المالي استخدم قدرة «تدقيق»")
            }
            1 -> {
                val next = c.docs.firstOrNull { it.round == round + 1 && it.id !in delivered }
                    ?: return "لا توجد وثائق قادمة لجلبها الآن"
                deliver(next)
                s.abilityUsed = true
                note("ability", 1, 1, "نجحت المداهمة: وصلت وثيقة مبكرة إلى ${ROLE_AR[next.owner]}")
                noteOthers("ability", 1, "المحقق الميداني داهم موقعاً فوصلت وثيقة مبكرة إلى ${ROLE_AR[next.owner]}")
            }
            else -> {
                interceptArmed = true
                s.abilityUsed = true
                note("ability", 2, 2, "فُعّل الاعتراض: سيُكشف عنوان أول وثيقة تُرسل بين زميليك")
            }
        }
        return null
    }

    // ───────── الاتهام والتصويت ─────────
    private fun accuseCheck(): String? = if (phase != "accuse") "نافذة الاتهام غير مفتوحة" else null

    private fun resetApprovals() = approvals.fill(false)

    private fun answer(seat: Int, a: Action.Answer): String? {
        accuseCheck()?.let { return it }
        if (a.q !in QIDS) return "سؤال غير معروف"
        if (a.opt != null && a.opt !in 0 until c.optionCount(a.q)) return "خيار غير صالح"
        answers[a.q] = a.opt
        answerBy[a.q] = seat
        resetApprovals()
        return null
    }

    private fun cite(seat: Int, a: Action.Cite): String? {
        accuseCheck()?.let { return it }
        if (a.q !in QIDS || a.slot !in 0..1) return "إحالة غير صالحة"
        if (a.doc != null && a.doc !in seats[seat].visible) return "لا تستطيع الاستشهاد بوثيقة لم تصلك عبر اللعبة"
        cites[a.q]!![a.slot] = a.doc
        resetApprovals()
        return null
    }

    fun draftError(): String? {
        for (q in QIDS) {
            val ct = cites[q]!!
            if (answers[q] == null) return "اختاروا إجابة لسؤال «${QUESTION_AR[q]}»"
            if (ct[0] == null || ct[1] == null) return "أرفقوا وثيقتين لسؤال «${QUESTION_AR[q]}»"
            if (ct[0] == ct[1]) return "الوثيقتان في «${QUESTION_AR[q]}» متطابقتان"
            if (c.docById[ct[0]!!]!!.owner == c.docById[ct[1]!!]!!.owner) return "وثائق «${QUESTION_AR[q]}» يجب أن تكون من لاعبَين مختلفين"
        }
        return null
    }

    fun draftValid(): Boolean = draftError() == null
    fun required(): Int = if (window == 1) 3 else 2

    private fun approve(seat: Int, a: Action.Approve, now: Long): String? {
        accuseCheck()?.let { return it }
        if (a.on) draftError()?.let { return it }
        approvals[seat] = a.on
        if (a.on && approvals.count { it } >= required()) submit(now)
        return null
    }

    private fun isIronclad(q: String): Boolean {
        val cited = setOf(cites[q]!![0], cites[q]!![1])
        return c.proof[q]!!.any { it.toSet() == cited }
    }

    private fun submit(now: Long) {
        val correct = QIDS.map { answers[it] == c.truth[it] }
        val ironclad = QIDS.mapIndexed { i, q -> correct[i] && isIronclad(q) }
        windows[window] = WinRes(correct, ironclad)
        val n = correct.count { it }
        if (n == 3 || window == 2) finish()
        else {
            note("accuse", -1, -1, "رُفعت التهمة لكنها غير مكتملة: $n من 3 إجابات صحيحة. تابعوا التحقيق في الجولة الأخيرة")
            resetApprovals()
            startRound(5, now)
        }
    }

    fun starsFor(correct: Int, allIronclad: Boolean, w: Int): Int = when {
        correct == 3 -> if (allIronclad && w == 1) 3 else 2
        correct == 2 -> 1
        else -> 0
    }

    private fun finish() {
        phase = "ended"
        var best = 0
        var bestW = 0
        for (w in 1..2) {
            val r = windows[w] ?: continue
            val st = starsFor(r.correct.count { it }, r.ironclad.all { it }, w)
            if (st > best || bestW == 0) {
                best = st
                bestW = w
            }
        }
        val last = windows[bestW]
        val solution = QIDS.map { q ->
            val pair = c.proof[q]!![0]
            PSolution(q, c.question(q).options[c.truth[q]!!].label, pair.map {
                val d = c.docById[it]!!
                PProof(d.id, d.title, d.owner)
            })
        }
        result = PResult(
            win = best >= 1, stars = best,
            correct = last?.correct ?: listOf(false, false, false),
            ironclad = last?.ironclad ?: listOf(false, false, false),
            window = bestW, solution = solution,
        )
        val label = when (best) {
            3 -> "قضية محكمة"
            2 -> "قضية مغلقة"
            1 -> "إغلاق بثغرة"
            else -> "فشل التحقيق"
        }
        note("verdict", -1, -1, "الحكم النهائي: $label")
    }
}
