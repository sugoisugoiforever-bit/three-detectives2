package game

val ROLE_IDS = listOf("analyst", "field", "comms")
val ROLE_AR = listOf("المحلل المالي", "المحقق الميداني", "خبير الاتصالات")
val ABILITY_AR = listOf("تدقيق", "مداهمة", "اعتراض")
val QIDS = listOf("who", "how", "why")
val QUESTION_AR = mapOf("who" to "من؟", "how" to "كيف؟", "why" to "لماذا؟")

// ───────────── القضية (تُقرأ من مكتبة القضايا) ─────────────

data class Person(val id: String, val name: String, val first: String, val g: String, val job: String, val portrait: Int)
data class Opt(val id: String, val label: String, val sub: String?, val person: String?)
data class Question(val id: String, val prompt: String, val options: List<Opt>)
data class Topic(val id: String, val kind: String, val label: String)

/** سطر داخل وثيقة: t = kv | p | hrow | row | msg */
data class Line(
    val t: String,
    val k: String? = null,
    val v: String? = null,
    val c: List<String>? = null,
    val who: String? = null,
    val time: String? = null,
)

data class Doc(
    val id: String, val owner: Int, val round: Int, val kind: String, val title: String,
    val stamp: String, val serial: Int, val lines: List<Line>, val topics: List<String>, val rel: String,
)

data class Claim(val q: String, val opt: Int, val w: Int, val needs: List<String>)

class Case(
    val id: String, val theme: String, val title: String, val brief: String, val org: String,
    val date: String, val window: List<String>, val persons: List<Person>, val questions: List<Question>,
    val topics: List<Topic>, val docs: List<Doc>, val truth: Map<String, Int>, val claims: List<Claim>,
    val proof: Map<String, List<List<String>>>,
) {
    val docById: Map<String, Doc> = docs.associateBy { it.id }
    val topicById: Map<String, Topic> = topics.associateBy { it.id }
    fun question(q: String): Question = questions.first { it.id == q }
    fun optionCount(q: String): Int = question(q).options.size
}

private fun parseLine(m: Map<String, Any?>) = Line(
    m.str("t"), m.strOrNull("k"), m.strOrNull("v"),
    (m["c"] as List<*>?)?.map { it as String }, m.strOrNull("who"), m.strOrNull("time"),
)

fun parseCase(m: Map<String, Any?>): Case {
    val persons = m.list("persons").map {
        val p = it.asMap()
        Person(p.str("id"), p.str("name"), p.str("first"), p.str("g"), p.str("job"), p.int("portrait"))
    }
    val questions = m.list("questions").map {
        val q = it.asMap()
        Question(q.str("id"), q.str("prompt"), q.list("options").map { o ->
            val om = o.asMap()
            Opt(om.str("id"), om.str("label"), om.strOrNull("sub"), om.strOrNull("person"))
        })
    }
    val topics = m.list("topics").map {
        val t = it.asMap()
        Topic(t.str("id"), t.str("kind"), t.str("label"))
    }
    val docs = m.list("docs").map {
        val d = it.asMap()
        Doc(
            d.str("id"), ROLE_IDS.indexOf(d.str("owner")), d.int("round"), d.str("kind"), d.str("title"),
            d.str("stamp"), d.int("serial"), d.list("lines").map { l -> parseLine(l.asMap()) },
            d.strList("topics"), d.str("rel"),
        )
    }
    val truth = m.obj("truth").mapValues { (it.value as Number).toInt() }
    val claims = m.list("claims").map {
        val c = it.asMap()
        Claim(c.str("q"), c.int("opt"), c.int("w"), c.strList("needs"))
    }
    val proof = m.obj("proof").mapValues { e -> e.value.asList().map { p -> p.asList().map { x -> x as String } } }
    return Case(
        m.str("id"), m.str("theme"), m.str("title"), m.str("brief"), m.str("org"), m.str("date"),
        m.strList("window"), persons, questions, topics, docs, truth, claims, proof,
    )
}

/** مكتبة قضايا JSONL: سطر لكل قضية. تُحلَّل القضية عند الطلب فقط. */
class CaseLibrary(private val lines: List<String>) {
    val size: Int get() = lines.size
    private val themes: List<String> by lazy {
        lines.map { l -> l.substringAfter("\"theme\":\"").substringBefore("\"") }
    }

    fun themeNames(): List<String> = themes.distinct()

    /** يختار قضية حتمياً من البذرة، ويقيّد السمة إن طُلب ذلك. */
    fun pick(theme: String?, seed: Long): Case {
        val idx = lines.indices.filter { theme == null || themes[it] == theme }
        require(idx.isNotEmpty()) { "no cases for theme $theme" }
        val i = idx[((seed % idx.size) + idx.size).toInt() % idx.size]
        return parseCase(Json.parse(lines[i]).asMap())
    }

    fun get(index: Int): Case = parseCase(Json.parse(lines[index]).asMap())
}

// ───────────── الحركات (من العميل إلى المحرك) ─────────────

sealed class Action {
    data class Share(val doc: String, val to: Int) : Action()
    data class Request(val topic: String) : Action()
    data class Template(val tpl: String, val slots: Map<String, String>) : Action()
    data class Ability(val arg: String?) : Action()
    data class Ready(val on: Boolean) : Action()
    data class Answer(val q: String, val opt: Int?) : Action()
    data class Cite(val q: String, val slot: Int, val doc: String?) : Action()
    data class Approve(val on: Boolean) : Action()
}

fun Action.toJson(): Map<String, Any?> = when (this) {
    is Action.Share -> linkedMapOf("a" to "share", "doc" to doc, "to" to to)
    is Action.Request -> linkedMapOf("a" to "request", "topic" to topic)
    is Action.Template -> linkedMapOf("a" to "template", "tpl" to tpl, "slots" to slots)
    is Action.Ability -> linkedMapOf("a" to "ability", "arg" to arg)
    is Action.Ready -> linkedMapOf("a" to "ready", "on" to on)
    is Action.Answer -> linkedMapOf("a" to "answer", "q" to q, "opt" to opt)
    is Action.Cite -> linkedMapOf("a" to "cite", "q" to q, "slot" to slot, "doc" to doc)
    is Action.Approve -> linkedMapOf("a" to "approve", "on" to on)
}

fun actionFromJson(m: Map<String, Any?>): Action? = try {
    when (m.str("a")) {
        "share" -> Action.Share(m.str("doc"), m.int("to"))
        "request" -> Action.Request(m.str("topic"))
        "template" -> Action.Template(m.str("tpl"), m.obj("slots").mapValues { it.value as String })
        "ability" -> Action.Ability(m.strOrNull("arg"))
        "ready" -> Action.Ready(m.bool("on"))
        "answer" -> Action.Answer(m.str("q"), (m["opt"] as Number?)?.toInt())
        "cite" -> Action.Cite(m.str("q"), m.int("slot"), m.strOrNull("doc"))
        "approve" -> Action.Approve(m.bool("on"))
        else -> null
    }
} catch (e: Exception) {
    null
}

// ───────────── ما يراه اللاعب (PlayerView) ─────────────

data class Notice(val id: Int, val round: Int, val kind: String, val from: Int, val to: Int, val text: String, val doc: String? = null)

data class PPlayer(
    val seat: Int, val role: String, val name: String, val bot: Boolean, val connected: Boolean,
    val ready: Boolean, val moveUsed: Boolean, val abilityUsed: Boolean,
)

data class PDoc(
    val id: String, val owner: Int, val round: Int, val kind: String, val title: String, val stamp: String,
    val serial: Int, val lines: List<Line>, val topics: List<String>,
    val from: Int,            // -1 = وثيقتي الأصلية، وإلا رقم المرسِل
    val copies: List<Int>,    // المقاعد التي تملك نسخة
    val audit: String?,       // decisive | noise | null (نتيجة تدقيقي)
)

data class PReq(val id: Int, val from: Int, val topic: String, val label: String, val round: Int, val matches: List<String>, val mine: Boolean)

data class PDraft(
    val answers: Map<String, Int?>, val cites: Map<String, List<String?>>, val approvals: List<Boolean>,
    val valid: Boolean, val required: Int, val window: Int,
)

data class PProof(val id: String, val title: String, val owner: Int)
data class PSolution(val q: String, val label: String, val proof: List<PProof>)
data class PResult(
    val win: Boolean, val stars: Int, val correct: List<Boolean>, val ironclad: List<Boolean>,
    val window: Int, val solution: List<PSolution>,
)

data class CaseInfo(
    val id: String, val theme: String, val title: String, val brief: String, val org: String, val date: String,
    val window: List<String>, val persons: List<Person>, val questions: List<Question>,
)

data class PView(
    val phase: String,           // round | accuse | ended
    val round: Int, val window: Int, val endsInMs: Long, val credits: Int, val creditsMax: Int, val seat: Int,
    val players: List<PPlayer>, val info: CaseInfo, val docs: List<PDoc>, val topics: List<Topic>,
    val feed: List<Notice>, val requests: List<PReq>, val interceptArmed: Boolean,
    val draft: PDraft, val result: PResult?,
    /** الوثائق المستشهَد بها في المسودة (عنوان ومالك) كي يراها الجميع وإن لم تصلهم نسخها. */
    val cited: List<PProof> = emptyList(),
)
