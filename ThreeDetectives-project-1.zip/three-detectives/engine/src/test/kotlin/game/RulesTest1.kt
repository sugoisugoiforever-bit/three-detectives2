package game

fun rulesTests1(lib: CaseLibrary) {
    val c = lib.get(0)

    section("التسليم والرؤية")
    run {
        val g = humanGame(c)
        val r1 = c.docs.filter { it.round == 1 }.map { it.id }.toSet()
        check(g.delivered == r1, "وثائق الجولة 1 سُلّمت")
        for (s in 0..2) {
            val v = g.view(s, 0)
            val expect = c.docs.filter { it.round == 1 && it.owner == s }.map { it.id }.toSet()
            check(v.docs.map { it.id }.toSet() == expect, "المقعد $s يرى وثائقه فقط")
            check(v.docs.all { it.from == -1 }, "from=-1 للأصلية")
            val seen = v.docs.flatMap { it.topics }.toSet()
            check(v.topics.filter { it.kind != "person" && it.kind != "place" }.all { it.id in seen }, "لا تسريب لمواضيع لم تُرَ")
            check(v.result == null, "لا نتيجة قبل النهاية")
            check(v.endsInMs == g.cfg.roundMs, "مؤقت الجولة")
        }
        g.allReady(1000)
        check(g.round == 2, "الجميع جاهز → الجولة 2")
        check(g.view(0, 1000).docs.size == c.docs.count { it.round <= 2 && it.owner == 0 }, "تسليم الجولة 2")
    }

    section("المشاركة")
    run {
        val g = humanGame(c)
        val d = c.docs.first { it.round == 1 && it.owner == 0 }
        val other = c.docs.first { it.round == 1 && it.owner == 1 }
        check(g.handle(0, Action.Share(other.id, 1), 0) != null, "لا مشاركة وثائق الغير")
        check(g.handle(0, Action.Share(d.id, 0), 0) != null, "لا مشاركة مع النفس")
        check(g.handle(0, Action.Share(d.id, 1), 0) == null, "مشاركة صحيحة")
        check(g.credits == g.cfg.credits - 1, "المشاركة بقطعة نحاسية")
        check(g.view(1, 0).docs.any { it.id == d.id && it.from == 0 }, "المستلم يرى الوثيقة ومرسلها")
        check(g.view(2, 0).docs.none { it.id == d.id }, "الثالث لا يراها")
        check(g.view(2, 0).feed.none { it.kind == "share" }, "الثالث لا يرى إشعاراً")
        check(g.view(1, 0).docs.first { it.id == d.id }.copies == listOf(0, 1), "نسخ المستلم")
        check(g.view(0, 0).docs.first { it.id == d.id }.copies == listOf(0, 1), "نسخ المرسل")
        check(g.view(0, 0).feed.any { it.kind == "share" }, "إشعار المرسل")
        check(g.view(1, 0).feed.any { it.kind == "share" && it.doc == d.id }, "إشعار المستلم")
        check(g.handle(0, Action.Share(d.id, 2), 0) != null, "حركة واحدة في الجولة")
        g.allReady(0)
        check(g.handle(0, Action.Share(d.id, 1), 0) != null, "الوثيقة عند الزميل أصلاً")
        check(g.handle(0, Action.Share(d.id, 2), 0) == null, "الجولة الجديدة تعيد الحركة")
        check(g.view(1, 0).docs.first { it.id == d.id }.copies == listOf(0, 1), "المستلم لا يعرف النسخة الثالثة")
        check(g.view(0, 0).docs.first { it.id == d.id }.copies == listOf(0, 1, 2), "المرسل يعرف كل نسخه")
        // لا يعاد إرسال نسخة مستلَمة
        val got = g.view(1, 0).docs.first { it.id == d.id }
        check(g.handle(1, Action.Share(got.id, 2), 0) != null, "لا إعادة مشاركة لوثيقة مستلَمة")

        val g2 = humanGame(c, Config(credits = 1))
        val d0 = c.docs.first { it.round == 1 && it.owner == 0 }
        check(g2.handle(0, Action.Share(d0.id, 1), 0) == null, "آخر قطعة")
        g2.allReady(0)
        val d1 = c.docs.first { it.round <= 2 && it.owner == 1 }
        check(g2.handle(1, Action.Share(d1.id, 2), 0) != null, "نفدت القطع")
        check(g2.credits == 0, "الرصيد صفر")
    }

    section("السؤال")
    run {
        val g = humanGame(c)
        while (g.round < 4) g.allReady(1000)
        // رمز يظهر في وثيقتين لمالكَين مختلفَين وكلتاهما سُلّمتا
        val key = c.topics.filter { it.kind == "key" }.first { t ->
            val ds = c.docs.filter { t.id in it.topics && it.round <= 4 }
            ds.size == 2 && ds[0].owner != ds[1].owner
        }
        val ds = c.docs.filter { key.id in it.topics }
        val a = ds[0].owner
        val b = ds[1].owner
        val third = (0..2).first { it != a && it != b }
        check(g.handle(third, Action.Request(key.id), 0) != null, "لا سؤال عن رمز لم يُرَ")
        check(g.handle(a, Action.Request(key.id), 0) == null, "سؤال عن رمز مرئي")
        check(g.handle(a, Action.Request(key.id), 0) != null, "السؤال يستهلك الحركة")
        check(g.view(b, 0).requests.any { it.topic == key.id && ds[1].id in it.matches }, "المجيب يرى الوثيقة المطابقة")
        check(g.view(a, 0).requests.any { it.mine && it.matches.isEmpty() }, "السائل: طلبي")
        check(g.view(third, 0).requests.any { it.label == key.label && it.matches.isEmpty() }, "الثالث يرى السؤال بلا تطابق")
        val person = c.topics.first { it.kind == "person" }
        check(g.handle(third, Action.Request(person.id), 0) == null, "سؤال عن شخص متاح للجميع")
        check(g.handle(b, Action.Request("nope"), 0) != null, "موضوع مجهول")
        check(g.view(0, 0).feed.any { it.kind == "request" }, "إشعار السؤال عام")
    }

    section("القوالب")
    run {
        val g = humanGame(c)
        g.godView()
        val p = c.persons[1]
        check(g.handle(0, Action.Template("T3", mapOf("person" to p.id)), 0) == null, "T3")
        check(g.credits == g.cfg.credits - 1, "القالب بقطعة")
        check(g.view(2, 0).feed.any { it.kind == "template" && it.text.endsWith("أقترح استبعاد ${p.name} من المشتبهين") }, "نص T3 عام")
        check(g.handle(0, Action.Template("T2", mapOf("person" to p.id)), 0) != null, "حركة واحدة")
        g.allReady(0)
        val place = c.topics.first { it.kind == "place" }
        val time = c.topics.first { it.kind == "time" }
        check(g.handle(0, Action.Template("T1", mapOf("person" to p.id, "place" to place.id, "time" to time.id)), 0) == null, "T1")
        val verb = if (p.g == "f") "كانت" else "كان"
        check(g.view(1, 0).feed.any { it.text.endsWith("${p.name} $verb في ${place.label} الساعة ${time.label}") }, "نص T1 وصيغة الجنس")
        g.allReady(0)
        val opt = c.question("how").options[2]
        check(g.handle(0, Action.Template("T4", mapOf("how" to opt.id)), 0) == null, "T4")
        check(g.view(1, 0).feed.any { it.text.endsWith("الأسلوب على الأرجح: ${opt.label}") }, "نص T4")
        g.allReady(0)
        val before = g.credits
        check(g.handle(0, Action.Template("T9", mapOf()), 0) != null, "قالب مجهول")
        check(g.handle(0, Action.Template("T2", mapOf()), 0) != null, "خانة ناقصة")
        check(g.handle(0, Action.Template("T2", mapOf("person" to place.id)), 0) != null, "نوع خانة خاطئ")
        check(g.handle(0, Action.Template("T5", mapOf("why" to "zzz")), 0) != null, "خيار غير موجود")
        check(g.credits == before, "الأخطاء لا تستهلك قطعاً")
        // وقت لم يظهر للاعب لا يُستعمل
        val g2 = humanGame(c)
        val hidden = c.topics.first { t -> t.kind == "time" && c.docs.none { d -> t.id in d.topics && d.owner == 0 && d.round == 1 } }
        check(g2.handle(0, Action.Template("T1", mapOf("person" to p.id, "place" to place.id, "time" to hidden.id)), 0) != null, "وقت غير مرئي")
    }
}
