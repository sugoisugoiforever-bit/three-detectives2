package game

fun libraryTests(lib: CaseLibrary) {
    section("مكتبة القضايا (${lib.size} قضية)")
    check(lib.size >= 90, "عدد القضايا")
    check(lib.themeNames().size == 3, "ثلاث سمات: ${lib.themeNames()}")
    val ids = HashSet<String>()
    for (i in 0 until lib.size) {
        val c = lib.get(i)
        check(ids.add(c.id), "معرّف مكرر ${c.id}")
        check(c.docs.size == 15, "${c.id}: 15 وثيقة")
        check((0..2).all { s -> c.docs.count { it.owner == s } == 5 }, "${c.id}: 5 لكل لاعب")
        check((1..5).map { r -> c.docs.count { it.round == r } } == listOf(5, 4, 3, 2, 1), "${c.id}: توزيع الجولات")
        check(c.docs.all { d -> d.topics.all { it in c.topicById } }, "${c.id}: مواضيع الوثائق")
        check(c.claims.all { cl -> cl.needs.all { it in c.docById } }, "${c.id}: أدلة الادعاءات")
        check(QIDS.all { q -> c.truth[q]!! in 0 until c.optionCount(q) }, "${c.id}: الحقيقة ضمن الخيارات")
        check(QIDS.all { q -> c.proof[q]!!.isNotEmpty() && c.proof[q]!!.all { p -> p.size == 2 && p.all { it in c.docById } } }, "${c.id}: أزواج الإثبات")
        check(c.persons.size == 7 && c.questions.size == 3 && c.questions.all { it.options.size == 7 }, "${c.id}: سبعة خيارات")
        check(c.docs.all { d -> d.lines.isNotEmpty() && d.title.isNotBlank() }, "${c.id}: محتوى الوثائق")
        // القناعة بكل الوثائق = الحقيقة
        val g = humanGame(c)
        check(QIDS.all { q -> g.belief(c.docs.map { it.id }.toSet(), q) == c.truth[q] }, "${c.id}: الحل منطقي")
    }
    // الاختيار حتمي من البذرة
    check(lib.pick("museum", 5).id == lib.pick("museum", 5).id, "اختيار حتمي")
    check(lib.pick("museum", 5).theme == "museum", "تقييد السمة")
}

fun main(args: Array<String>) {
    val t0 = System.currentTimeMillis()
    val lib = loadLibrary()
    if (args.contains("--parity")) { parityMain(); return }
    if (args.contains("--chaos")) { chaosMain(); return }
    val ti = args.indexOf("--trace")
    if (ti >= 0) {
        traceGame(lib, args[ti + 1].toInt(), Config.normal())
        return
    }
    libraryTests(lib)
    rulesTests1(lib)
    rulesTests2(lib)
    rulesTests3(lib)
    oracleTests(lib)
    if (!args.contains("--nosim")) botSims(lib)
    println("فحوصات=$checks إخفاقات=$failures الزمن=${System.currentTimeMillis() - t0}ms")
    if (failures > 0) {
        println("فشل الاختبار الذاتي")
        System.exit(1)
    }
    println("نجح الاختبار الذاتي")
}
