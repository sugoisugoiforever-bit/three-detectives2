package game

fun rulesTests2(lib: CaseLibrary) {
    val c = lib.get(1)

    section("القدرات")
    run {
        // تدقيق
        val g = humanGame(c)
        val doc = c.docs.first { it.round == 1 && it.owner == 0 }
        val other = c.docs.first { it.round == 1 && it.owner == 1 }
        check(g.handle(0, Action.Ability(null), 0) != null, "التدقيق بلا وثيقة")
        check(g.handle(0, Action.Ability(other.id), 0) != null, "وثيقة غير مرئية")
        check(g.handle(0, Action.Ability(doc.id), 0) == null, "تدقيق")
        check(g.view(0, 0).docs.first { it.id == doc.id }.audit == doc.rel, "نتيجة التدقيق = الحقيقة")
        check(g.view(0, 0).players[0].abilityUsed, "القدرة مستهلكة")
        check(g.handle(0, Action.Share(doc.id, 1), 0) == null, "القدرة لا تستهلك الحركة")
        check(g.view(1, 0).docs.first { it.id == doc.id }.audit == null, "نتيجة التدقيق خاصة بالمحلل")
        g.allReady(0)
        check(g.handle(0, Action.Ability(doc.id), 0) != null, "مرة واحدة في اللعبة")

        // مداهمة
        val g2 = humanGame(c)
        val next = c.docs.first { it.round == 2 }
        check(next.id !in g2.delivered, "وثيقة R2 لم تصل بعد")
        check(g2.handle(1, Action.Ability(null), 0) == null, "مداهمة")
        check(next.id in g2.delivered, "وصلت مبكراً")
        check(g2.view(next.owner, 0).docs.any { it.id == next.id }, "المالك يراها")
        check(g2.handle(1, Action.Ability(null), 0) != null, "مرة واحدة")
        g2.allReady(0)
        check(g2.view(0, 0).docs.size == c.docs.count { it.owner == 0 && it.round <= 2 }, "لا تكرار عند وصول الجولة")
        check(g2.view(1, 0).docs.size == c.docs.count { it.owner == 1 && it.round <= 2 }, "لا تكرار (2)")

        // مداهمة بلا وثائق قادمة لا تُستهلك
        val g3 = humanGame(c)
        g3.skipToAccuse()
        g3.tick(1000L + g3.cfg.accuseMs)
        check(g3.round == 5, "الجولة الخامسة")
        check(g3.handle(1, Action.Ability(null), 0) != null, "لا وثائق قادمة")
        check(!g3.seats[1].abilityUsed, "الفشل لا يستهلك القدرة")

        // اعتراض
        val g4 = humanGame(c)
        check(g4.handle(2, Action.Ability(null), 0) == null, "تفعيل الاعتراض")
        check(g4.view(2, 0).interceptArmed && !g4.view(0, 0).interceptArmed, "الاعتراض خاص بالخبير")
        val d2 = c.docs.first { it.owner == 2 && it.round == 1 }
        check(g4.handle(2, Action.Share(d2.id, 0), 0) == null, "مشاركة تخص الخبير")
        check(g4.view(2, 0).feed.none { it.kind == "intercept" }, "لا اعتراض لمشاركته")
        g4.allReady(0)
        val d0 = c.docs.first { it.owner == 0 && it.round <= 2 }
        check(g4.handle(0, Action.Share(d0.id, 1), 0) == null, "مشاركة بين الزميلين")
        val ic = g4.view(2, 0).feed.filter { it.kind == "intercept" }
        check(ic.size == 1, "اعتراض واحد")
        check(ic.isNotEmpty() && ic[0].text.contains(KIND_AR[d0.kind]!!), "الإشعار يذكر نوع الوثيقة")
        check(ic.isNotEmpty() && ic[0].text.contains(d0.title), "الإشعار يكشف العنوان فقط")
        check(ic.isNotEmpty() && d0.lines.mapNotNull { it.v }.none { it.length > 6 && ic[0].text.contains(it) }, "الإشعار لا يكشف المحتوى")
        check(!g4.view(2, 0).interceptArmed, "الاعتراض استُهلك")
        check(g4.view(0, 0).feed.none { it.kind == "intercept" }, "الاعتراض خاص")
    }

    section("الجولات والمؤقتات")
    run {
        val g = humanGame(c)
        val rm = g.cfg.roundMs
        check(g.phase == "round" && g.round == 1, "تبدأ الجولة 1")
        g.tick(rm - 1)
        check(g.round == 1, "لم ينتهِ الوقت")
        g.tick(rm)
        check(g.round == 2, "انتهى الوقت → الجولة 2")
        check(g.view(0, rm).endsInMs == rm, "مؤقت جولة جديدة")
        g.tick(2 * rm)
        g.tick(3 * rm)
        check(g.round == 4, "الجولة 4")
        g.tick(4 * rm)
        check(g.phase == "accuse" && g.window == 1, "نافذة الاتهام الأولى")
        check(g.handle(0, Action.Ready(true), 4 * rm) != null, "لا جاهزية في الاتهام")
        check(g.handle(0, Action.Request(c.topics[0].id), 4 * rm) != null, "لا تواصل في الاتهام")
        val ar = g.cfg.accuseMs
        g.tick(4 * rm + ar)
        check(g.phase == "round" && g.round == 5, "بلا اتهام → الجولة 5")
        check(g.view(0, 0).docs.any { it.round == 5 } || c.docs.none { it.round == 5 && it.owner == 0 }, "وثيقة الجولة 5")
        g.tick(5 * rm + ar)
        check(g.phase == "accuse" && g.window == 2, "نافذة الاتهام الأخيرة")
        check(g.required() == 2, "نافذة 2 تكفيها موافقتان")
        g.tick(5 * rm + 2 * ar)
        check(g.phase == "ended", "انتهت اللعبة")
        check(g.result != null && !g.result!!.win && g.result!!.stars == 0, "بلا اتهام = خسارة")
        check(g.result!!.solution.size == 3 && g.result!!.solution.all { it.proof.size == 2 }, "الحل يُكشف في النهاية")
        check(g.handle(0, Action.Ready(true), 0) != null, "لا أفعال بعد النهاية")
        check(g.view(0, 0).endsInMs == 0L, "المؤقت صفر")

        // انقطاع لاعب لا يعطّل زميليه
        val g2 = humanGame(c)
        g2.seats[2].connected = false
        g2.handle(0, Action.Ready(true), 5)
        check(g2.round == 1, "جاهز واحد والثاني متصل")
        g2.handle(1, Action.Ready(true), 5)
        check(g2.round == 2, "المنقطع لا يعطّل")
        // إلغاء الجاهزية
        val g3 = humanGame(c)
        g3.handle(0, Action.Ready(true), 0)
        g3.handle(0, Action.Ready(false), 0)
        g3.handle(1, Action.Ready(true), 0)
        g3.handle(2, Action.Ready(true), 0)
        check(g3.round == 1, "إلغاء الجاهزية")
    }
}
