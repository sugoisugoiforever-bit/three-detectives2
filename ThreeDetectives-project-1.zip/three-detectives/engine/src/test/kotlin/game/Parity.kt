package game

/**
 * يولّد أثر التكافؤ: ألعاب مبرمجة (بوتات + لاعبون بشريون آليون) تُسجَّل تجزئة منظور كل مقعد كل 10 ثوانٍ.
 * يجب أن يطابق ناتجه حرفياً ناتج server/test/parity-driver.ts.
 */
fun fnv(s: String): Long {
    var h = 0x811c9dc5L
    for (ch in s) {
        h = h xor ch.code.toLong()
        h = (h * 0x01000193L) and 0xFFFFFFFFL
    }
    return h
}

private fun canonView(g: Game, seat: Int, now: Long): String = Json.stringify(g.view(seat, now).toJson(), sortKeys = true)

private val DIFFS = intArrayOf(0, 1, 2, 1, 2, 0)

fun parityTrace(lib: CaseLibrary): List<String> {
    val out = ArrayList<String>()
    for (k in DIFFS.indices) {
        val idx = (k * 37 + 5) % lib.size
        val base = when (DIFFS[k]) { 0 -> Config.easy(); 2 -> Config.hard(); else -> Config.normal() }
        val cfg = if (k % 2 == 1) base.copy(botPace = 0.5) else base
        val humans = when (k % 3) { 0 -> listOf(0); 1 -> listOf(1, 2); else -> emptyList() }
        val g = Game(lib.get(idx), cfg, 1000 + k * 7919, 0L, humans.toSet())
        for (h in humans) g.setSeat(h, "لاعب$h", false)
        val did = HashSet<String>()
        var errHash = 0x811c9dc5L
        var errCount = 0
        val act = { seat: Int, a: Action, now: Long ->
            val e = g.handle(seat, a, now)
            if (e != null) {
                errCount++
                errHash = fnv(errHash.toString(16) + e)
            }
        }
        out.add("case k=$k idx=$idx id=${g.c.id} diff=${DIFFS[k]} humans=${humans.joinToString(",")}")
        for (step in 1..3200) {
            val now = step * 500L
            for (h in humans) humanPolicy(g, h, now, did, act)
            g.tick(now)
            if (step % 20 == 0 || g.phase == "ended") {
                val hs = (0..2).map { fnv(canonView(g, it, now)).toString(16) }
                out.add("t=$now ph=${g.phase} r=${g.round} w=${g.window} cr=${g.credits} feed=${g.feed.size} err=$errCount/${errHash.toString(16)} v=${hs.joinToString(",")}")
            }
            if (g.phase == "ended") break
        }
        val res = g.view(0, 0L).toJson()["result"]
        val stars = g.result?.stars
        out.add("end phase=${g.phase} result=${fnv(Json.stringify(res, sortKeys = true)).toString(16)} stars=$stars")
    }
    return out
}

private fun humanPolicy(g: Game, h: Int, now: Long, did: MutableSet<String>, act: (Int, Action, Long) -> Unit) {
    val seat = g.seats[h]
    if (g.phase == "round") {
        val off = now - (g.phaseEndsAt - g.cfg.roundMs)
        fun key(n: String) = "$n:$h:${g.round}"
        if (off >= 8000 && !seat.moveUsed && key("req") !in did) {
            did.add(key("req"))
            val t = g.c.topics.first { it.kind == "person" }
            act(h, Action.Request(t.id), now)
        }
        if (off >= 20000 && g.round >= 2 && !seat.abilityUsed && key("abi") !in did) {
            did.add(key("abi"))
            val arg = if (h == 0) seat.visible.firstOrNull() else null
            act(h, Action.Ability(arg), now)
        }
        if (off >= 40000 && !seat.moveUsed && key("shr") !in did) {
            did.add(key("shr"))
            val own = seat.visible.firstOrNull { g.c.docById[it]!!.owner == h }
            if (own != null) act(h, Action.Share(own, (h + 1) % 3), now)
        }
        if (off >= 60000 && g.round % 2 == 1 && !seat.ready) act(h, Action.Ready(true), now)
        if (off >= 120000 && !seat.ready) act(h, Action.Ready(true), now)
    } else if (g.phase == "accuse") {
        val off = now - (g.phaseEndsAt - g.cfg.accuseMs)
        fun key(n: String) = "$n:$h:${g.window}"
        if (off >= 6000 && key("fill") !in did) {
            did.add(key("fill"))
            val vis = seat.visible.toList()
            for (q in QIDS) {
                act(h, Action.Answer(q, g.c.truth[q]!!), now)
                val d0 = vis[0]
                val d1 = vis.firstOrNull { g.c.docById[it]!!.owner != g.c.docById[d0]!!.owner }
                act(h, Action.Cite(q, 0, d0), now)
                if (d1 != null) act(h, Action.Cite(q, 1, d1), now)
            }
        }
        if (off >= 40000 && key("ok") !in did) {
            did.add(key("ok"))
            act(h, Action.Approve(true), now)
        }
    }
}

fun parityMain() {
    println(parityTrace(loadLibrary()).joinToString("\n"))
}
