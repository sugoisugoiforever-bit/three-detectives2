package game

/** نظير Kotlin لـ server/test/chaos-driver.ts: يجب أن يطابق أثره حرفياً. */
private fun pickDoc(r: Rng, c: Case): String = if (r.nextInt(10) == 0) "nodoc" else c.docs[r.nextInt(c.docs.size)].id
private fun pickTopic(r: Rng, c: Case): String = if (r.nextInt(10) == 0) "notopic" else c.topics[r.nextInt(c.topics.size)].id
private fun pickKind(r: Rng, c: Case, kind: String): String {
    val list = c.topics.filter { it.kind == kind }
    if (list.isEmpty() || r.nextInt(5) == 0) return pickTopic(r, c)
    return list[r.nextInt(list.size)].id
}
private fun pickOpt(r: Rng, c: Case, q: String): String {
    val o = c.question(q).options
    return o[r.nextInt(o.size)].id
}

private fun m(vararg p: Pair<String, Any?>): Map<String, Any?> = linkedMapOf(*p)

fun chaosAction(r: Rng, c: Case, phase: String): Map<String, Any?> {
    val k = if (phase == "accuse") 4 + r.nextInt(6) else r.nextInt(10)
    return when (k) {
        0 -> { val d = pickDoc(r, c); m("a" to "share", "doc" to d, "to" to r.nextInt(4)) }
        1 -> m("a" to "request", "topic" to pickTopic(r, c))
        2 -> {
            val tpl = "T" + (1 + r.nextInt(6))
            val person = pickKind(r, c, "person"); val place = pickKind(r, c, "place"); val time = pickKind(r, c, "time")
            val how = pickOpt(r, c, "how"); val why = pickOpt(r, c, "why")
            m("a" to "template", "tpl" to tpl, "slots" to m("person" to person, "place" to place, "time" to time, "how" to how, "why" to why))
        }
        3 -> {
            val arg = if (r.nextInt(3) == 0) null else if (r.nextInt(2) == 0) pickDoc(r, c) else pickTopic(r, c)
            m("a" to "ability", "arg" to arg)
        }
        4 -> m("a" to "ready", "on" to (r.nextInt(4) == 0))
        5, 9 -> {
            val q = QIDS[r.nextInt(3)]
            val opt = if (r.nextInt(8) == 0) null else r.nextInt(c.optionCount(q) + 2) - 1
            m("a" to "answer", "q" to q, "opt" to opt)
        }
        6 -> {
            val q = QIDS[r.nextInt(3)]
            val slot = r.nextInt(3)
            val doc = if (r.nextInt(8) == 0) null else pickDoc(r, c)
            m("a" to "cite", "q" to q, "slot" to slot, "doc" to doc)
        }
        7 -> m("a" to "approve", "on" to (r.nextInt(5) != 0))
        else -> when (r.nextInt(3)) {
            0 -> m("a" to "share", "doc" to "x")
            1 -> m("a" to "zzz")
            else -> m("a" to "ready", "on" to "yes")
        }
    }
}

private val SETS = listOf(listOf(0, 1, 2), listOf(0, 1, 2), listOf(1), listOf(0, 2), listOf(0, 1, 2), emptyList())
private val CDIFFS = intArrayOf(1, 2, 0, 1, 2, 0)

fun chaosTrace(lib: CaseLibrary): List<String> {
    val out = ArrayList<String>()
    for (k in SETS.indices) {
        val idx = (k * 53 + 11) % lib.size
        val humans = SETS[k]
        val cfg = when (CDIFFS[k]) { 0 -> Config.easy(); 2 -> Config.hard(); else -> Config.normal() }
        val g = Game(lib.get(idx), cfg, 5000 + k * 31, 0L, humans.toSet())
        for (h in humans) g.setSeat(h, "لاعب$h", false)
        val r = Rng(99 + k)
        var errHash = 0x811c9dc5L
        var errCount = 0
        var bad = 0
        out.add("chaos k=$k idx=$idx id=${g.c.id} humans=${humans.joinToString(",")}")
        for (step in 1..4000) {
            val now = step * 500L
            for (s in 0..2) {
                if (r.nextInt(60) == 0) {
                    if (g.seats[s].bot) g.release(s, "عائد$s") else g.takeover(s, "آلي$s", now)
                }
                if (r.nextInt(5) != 0) continue
                val text = Json.stringify(chaosAction(r, g.c, g.phase))
                val a = actionFromJson(Json.parse(text).asMap())
                if (a == null) { bad++; continue }
                val e = g.handle(s, a, now)
                if (e != null) { errCount++; errHash = fnv(errHash.toString(16) + e) }
            }
            g.tick(now)
            if (step % 40 == 0 || g.phase == "ended") {
                val hs = (0..2).map { fnv(Json.stringify(g.view(it, now).toJson(), sortKeys = true)).toString(16) }
                out.add("t=$now ph=${g.phase} r=${g.round} w=${g.window} cr=${g.credits} feed=${g.feed.size} err=$errCount/${errHash.toString(16)} bad=$bad v=${hs.joinToString(",")}")
            }
            if (g.phase == "ended") break
        }
        val res = g.view(0, 0L).toJson()["result"]
        out.add("end phase=${g.phase} result=${fnv(Json.stringify(res, sortKeys = true)).toString(16)}")
    }
    return out
}

fun chaosMain() {
    println(chaosTrace(loadLibrary()).joinToString("\n"))
}
