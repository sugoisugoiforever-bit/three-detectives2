package game

fun rulesTests3(lib: CaseLibrary) {
    val c = lib.get(2)

    section("الاتهام والنجوم")
    run {
        check(Game(c, Config(), 1, 0).starsFor(3, true, 1) == 3, "3 صحيحة محكمة نافذة 1 = 3 نجوم")
        check(Game(c, Config(), 1, 0).starsFor(3, false, 1) == 2, "3 صحيحة غير محكمة = 2")
        check(Game(c, Config(), 1, 0).starsFor(3, true, 2) == 2, "3 صحيحة نافذة 2 = 2")
        check(Game(c, Config(), 1, 0).starsFor(2, true, 1) == 1, "2 صحيحة = 1")
        check(Game(c, Config(), 1, 0).starsFor(1, true, 1) == 0, "صحيحة واحدة = 0")

        // ثلاث نجوم
        val g = humanGame(c)
        g.godView()
        g.skipToAccuse()
        check(g.phase == "accuse" && g.window == 1 && g.required() == 3, "نافذة 1 تحتاج إجماعاً")
        check(!g.draftValid(), "مسودة فارغة")
        check(g.handle(0, Action.Approve(true), 0) != null, "لا موافقة على مسودة ناقصة")
        g.fillTruth(0)
        check(g.draftValid() && g.draftError() == null, "مسودة صالحة")
        g.handle(0, Action.Approve(true), 0)
        g.handle(1, Action.Approve(true), 0)
        check(g.phase == "accuse", "اثنان لا يكفيان في النافذة 1")
        // تعديل المسودة يلغي الموافقات
        val wrongWho = (0 until 7).first { it != c.truth["who"] }
        g.handle(2, Action.Answer("who", wrongWho), 0)
        check(g.approvals.none { it }, "التعديل يلغي الموافقات")
        g.handle(2, Action.Answer("who", c.truth["who"]), 0)
        g.approveAll()
        check(g.phase == "ended", "انتهت بالإجماع")
        val r = g.result!!
        check(r.stars == 3 && r.window == 1 && r.ironclad.all { it } && r.correct.all { it } && r.win, "3 نجوم")

        // صحيح لكن غير محكم → نجمتان
        val g2 = humanGame(c)
        g2.godView()
        g2.skipToAccuse()
        g2.fillTruth(0)
        val proofSets = QIDS.flatMap { q -> c.proof[q]!!.map { it.toSet() } }
        val d0 = c.proof["how"]!![0][0]
        val weak = c.docs.first { it.owner != c.docById[d0]!!.owner && setOf(d0, it.id) !in proofSets }
        g2.handle(0, Action.Cite("how", 1, weak.id), 0)
        check(g2.draftValid(), "مسودة صالحة وغير محكمة")
        g2.approveAll()
        check(g2.result!!.stars == 2 && !g2.result!!.ironclad[1] && g2.result!!.correct.all { it }, "نجمتان")

        // خطأ في النافذة 1 → الجولة 5 → تصحيح في النافذة 2 → نجمتان
        val g3 = humanGame(c)
        g3.godView()
        g3.skipToAccuse()
        g3.fillTruth(0)
        g3.handle(0, Action.Answer("why", (0 until 7).first { it != c.truth["why"] }), 0)
        g3.approveAll(5)
        check(g3.phase == "round" && g3.round == 5 && g3.result == null, "تهمة ناقصة → الجولة 5")
        check(g3.view(1, 5).feed.any { it.kind == "accuse" && it.text.contains("2 من 3") }, "يُكشف عدد الصحيح فقط")
        check(g3.view(1, 5).feed.none { it.text.contains(c.question("why").options[c.truth["why"]!!].label) }, "لا يُكشف أي خيار صحيح")
        g3.allReady(6)
        check(g3.phase == "accuse" && g3.window == 2, "نافذة 2 بعد الجولة 5")
        check(g3.approvals.none { it }, "الموافقات تبدأ من جديد")
        g3.handle(0, Action.Answer("why", c.truth["why"]), 6)
        g3.handle(0, Action.Approve(true), 6)
        check(g3.phase == "accuse", "موافقة واحدة لا تكفي")
        g3.handle(1, Action.Approve(true), 6)
        check(g3.phase == "ended" && g3.result!!.stars == 2 && g3.result!!.window == 2, "اثنان يكفيان في النافذة 2")

        // إجابتان صحيحتان في النافذة 1 ولا شيء بعدها → نجمة واحدة من النافذة 1
        val g4 = humanGame(c)
        g4.godView()
        g4.skipToAccuse()
        g4.fillTruth(0)
        g4.handle(0, Action.Answer("why", (0 until 7).first { it != c.truth["why"] }), 0)
        g4.approveAll(5)
        g4.allReady(6)
        g4.tick(6 + g4.cfg.accuseMs)
        check(g4.phase == "ended" && g4.result!!.stars == 1 && g4.result!!.win && g4.result!!.window == 1, "أفضل النافذتين")
        check(g4.result!!.correct == listOf(true, true, false), "نتيجة النافذة الفضلى")

        // أخطاء الإحالة
        val g5 = humanGame(c)
        g5.godView()
        g5.skipToAccuse()
        check(g5.handle(1, Action.Cite("who", 0, c.docs.first { it.owner == 0 }.id), 0) != null, "لا استشهاد بوثيقة غير مرئية للمستشهِد")
        val sameOwner = c.docs.filter { it.owner == 0 }
        g5.handle(0, Action.Answer("who", 0), 0)
        g5.handle(0, Action.Cite("who", 0, sameOwner[0].id), 0)
        g5.handle(0, Action.Cite("who", 1, sameOwner[1].id), 0)
        check(g5.draftError() != null, "وثيقتان من مالك واحد")
        g5.handle(0, Action.Cite("who", 1, sameOwner[0].id), 0)
        check(g5.draftError() != null, "الوثيقة نفسها مرتين")
        check(g5.handle(0, Action.Answer("who", 99), 0) != null, "خيار خارج النطاق")
        check(g5.handle(0, Action.Answer("zzz", 1), 0) != null, "سؤال مجهول")
        check(g5.handle(0, Action.Cite("who", 5, null), 0) != null, "خانة إحالة خاطئة")
        check(g5.handle(0, Action.Share(sameOwner[0].id, 1), 0) != null, "المشاركة مغلقة")
    }

    section("JSON والتسلسل")
    run {
        val j = Json.parse("""{"a":[1,2.5,-3,true,null,"x\"y\nا"],"b":{"c":"d"}}""").asMap()
        check(j.list("a").size == 6 && j.list("a")[5] == "x\"y\nا", "تحليل JSON")
        check(Json.stringify(j, true) == """{"a":[1,2.5,-3,true,null,"x\"y\nا"],"b":{"c":"d"}}""".replace("\\u0627", "ا"), "تسلسل JSON")
        var bad = false
        try { Json.parse("{\"a\":") } catch (e: Exception) { bad = true }
        check(bad, "JSON معطوب يُرفض")

        val actions = listOf(
            Action.Share("d3", 1), Action.Request("k1"), Action.Template("T1", mapOf("person" to "p1", "place" to "l2", "time" to "t3")),
            Action.Ability("d4"), Action.Ability(null), Action.Ready(true), Action.Answer("who", 3), Action.Answer("how", null),
            Action.Cite("why", 1, "d9"), Action.Cite("why", 0, null), Action.Approve(false),
        )
        for (a in actions) {
            val back = actionFromJson(Json.parse(Json.stringify(a.toJson())).asMap())
            check(back == a, "حركة ${a::class.simpleName}")
        }
        check(actionFromJson(mapOf("a" to "zzz")) == null, "حركة مجهولة")
        check(actionFromJson(mapOf("a" to "share")) == null, "حركة ناقصة")

        // دورة كاملة لعرض اللاعب في حالات مختلفة
        val g = humanGame(c)
        g.godView()
        g.handle(0, Action.Share(c.docs.first { it.round == 1 && it.owner == 0 }.id, 1), 10)
        g.handle(1, Action.Request(c.topics.first { it.kind == "person" }.id), 10)
        g.handle(2, Action.Ability(null), 10)
        for (s in 0..2) {
            val v = g.view(s, 100)
            val txt = Json.stringify(v.toJson())
            check(pviewFromJson(Json.parse(txt).asMap()) == v, "تدوير العرض للمقعد $s")
            check(!txt.contains("\"claims\"") && !txt.contains("\"truth\""), "لا أسرار في العرض")
        }
        g.skipToAccuse()
        g.fillTruth(0)
        run {
            val cs = (0..2).map { g.view(it, 100).cited }
            check(cs[0].isNotEmpty() && cs[0] == cs[1] && cs[1] == cs[2], "الوثائق المستشهَد بها ظاهرة للجميع")
            check(cs[0].all { p -> c.docById[p.id]!!.title == p.title && c.docById[p.id]!!.owner == p.owner }, "بيانات المستشهَد بها صحيحة")
        }
        g.approveAll()
        for (s in 0..2) {
            val v = g.view(s, 100)
            check(pviewFromJson(Json.parse(Json.stringify(v.toJson())).asMap()) == v, "تدوير العرض النهائي للمقعد $s")
        }
        check(g.view(1, 0).result != null && g.view(1, 0).phase == "ended", "النتيجة في العرض النهائي")
    }
}
