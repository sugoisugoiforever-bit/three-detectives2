package game

class Plan(val shares: List<Triple<String, Int, Int>>, val citers: List<Int>, val pairs: List<List<String>>)

/** جدولة المشاركات: حركة واحدة لكل مالك في الجولة، ولا مشاركة قبل وصول الوثيقة. */
fun schedule(c: Case, shares: List<Pair<String, Int>>, lastRound: Int = 4): List<Triple<String, Int, Int>>? {
    val out = ArrayList<Triple<String, Int, Int>>()
    for ((_, list) in shares.groupBy { c.docById[it.first]!!.owner }) {
        var r = 1
        for (s in list.sortedBy { c.docById[it.first]!!.round }) {
            r = maxOf(r, c.docById[s.first]!!.round)
            if (r > lastRound) return null
            out.add(Triple(s.first, s.second, r))
            r++
        }
    }
    return out
}

/** أرخص خطة تضمن نجاحاً بثلاث نجوم (تعادل مدقّق Python). */
fun oraclePlan(c: Case): Plan? {
    var best: Plan? = null
    for (p0 in c.proof["who"]!!) for (p1 in c.proof["how"]!!) for (p2 in c.proof["why"]!!) {
        val choice = listOf(p0, p1, p2)
        if (choice.any { pair -> pair.any { c.docById[it]!!.round > 4 } }) continue
        for (c0 in 0..2) for (c1 in 0..2) for (c2 in 0..2) {
            val citers = listOf(c0, c1, c2)
            val shares = LinkedHashSet<Pair<String, Int>>()
            for ((k, pair) in choice.withIndex()) for (d in pair) {
                if (c.docById[d]!!.owner != citers[k]) shares.add(Pair(d, citers[k]))
            }
            if (best != null && shares.size >= best.shares.size) continue
            val sched = schedule(c, shares.toList()) ?: continue
            best = Plan(sched, citers, choice)
        }
    }
    return best
}

/** لاعبون مثاليون (بشر) ينفذون الخطة: يجب أن تنتهي القضية بثلاث نجوم. */
fun oracleTests(lib: CaseLibrary) {
    section("لاعب مثالي على كل القضايا")
    var worst = 0
    for (i in 0 until lib.size) {
        val c = lib.get(i)
        val plan = oraclePlan(c)
        check(plan != null, "${c.id}: لا خطة")
        if (plan == null) continue
        for (cfg in listOf(Config.easy(), Config.normal(), Config.hard())) {
            val g = humanGame(c, cfg)
            var now = 1000L
            for (r in 1..4) {
                for ((doc, to, _) in plan.shares.filter { it.third == r }) {
                    val err = g.handle(c.docById[doc]!!.owner, Action.Share(doc, to), now)
                    check(err == null, "${c.id}: مشاركة $doc → $to: $err")
                }
                g.allReady(now)
                now += 1000
            }
            check(g.phase == "accuse" && g.window == 1, "${c.id}: نافذة 1")
            for ((k, q) in QIDS.withIndex()) {
                g.handle(0, Action.Answer(q, c.truth[q]), now)
                for (slot in 0..1) {
                    val err = g.handle(plan.citers[k], Action.Cite(q, slot, plan.pairs[k][slot]), now)
                    check(err == null, "${c.id}: إحالة $q/$slot من ${plan.citers[k]} إلى ${plan.pairs[k][slot]}: $err | خطة=${plan.shares}")
                }
            }
            check(g.draftError() == null, "${c.id}: مسودة المثالي: ${g.draftError()}")
            g.approveAll(now)
            val r = g.result
            check(g.phase == "ended" && r != null && r.stars == 3, "${c.id}: ${cfg.credits} نقاط → ${r?.stars} نجوم")
            worst = maxOf(worst, cfg.credits - g.credits)
        }
    }
    println("  أقصى قطع استُعملت: $worst")
}

class SimResult(val stars: Int, val window: Int, val durSec: Long, val creditsLeft: Int, val shares: Int, val requests: Int)

fun simulate(c: Case, cfg: Config, seed: Int): SimResult {
    val g = Game(c, cfg, seed, 0L)
    var now = 0L
    while (g.phase != "ended") {
        now += 1000
        g.tick(now)
        check(now < 3_600_000, "${c.id}: لا تنتهي")
        if (now >= 3_600_000) break
    }
    val r = g.result
    return SimResult(
        r?.stars ?: -1, r?.window ?: 0, now / 1000, g.credits,
        g.feed.count { it.kind == "share" && it.from == it.to }, g.requests.size,
    )
}

fun botSims(lib: CaseLibrary) {
    section("فريق من البوتات (3 بوتات) على كل القضايا")
    for ((name, cfg) in listOf("سهل" to Config.easy(), "عادي" to Config.normal(), "صعب" to Config.hard())) {
        val dist = IntArray(4)
        var dur = 0L
        var credits = 0
        var shares = 0
        var reqs = 0
        var w2 = 0
        val perTheme = HashMap<String, IntArray>()
        for (i in 0 until lib.size) {
            val c = lib.get(i)
            val s = simulate(c, cfg, 1000 + i)
            check(s.stars in 0..3, "${c.id}: نتيجة غير صالحة")
            if (s.stars in 0..3) dist[s.stars]++
            dur += s.durSec
            credits += s.creditsLeft
            shares += s.shares
            reqs += s.requests
            if (s.window == 2) w2++
            perTheme.getOrPut(c.theme) { IntArray(4) }[s.stars.coerceIn(0, 3)]++
        }
        val n = lib.size
        println(
            "  $name: نجوم 0/1/2/3 = ${dist.toList()}  فوز=${(dist[1] + dist[2] + dist[3]) * 100 / n}%  " +
                "متوسط المدة=${dur / n}ث  قطع متبقية=${"%.1f".format(credits.toDouble() / n)}  " +
                "مشاركات=${"%.1f".format(shares.toDouble() / n)} أسئلة=${"%.1f".format(reqs.toDouble() / n)} نافذة2=$w2",
        )
        for ((t, d) in perTheme) println("      $t: ${d.toList()}")
    }
}

/** يطبع سجل مباراة بوتات كاملة (للمراجعة اليدوية): selfTest --trace N */
fun traceGame(lib: CaseLibrary, idx: Int, cfg: Config) {
    val c = lib.get(idx)
    println("== ${c.id}: ${c.title}")
    println("حقيقة: من=${c.persons[c.truth["who"]!!].name} | كيف=${c.question("how").options[c.truth["how"]!!].label} | لماذا=${c.question("why").options[c.truth["why"]!!].label}")
    val g = Game(c, cfg, 1000 + idx, 0L)
    var now = 0L
    var seen = 0
    while (g.phase != "ended" && now < 3_600_000) {
        now += 1000
        g.tick(now)
        while (seen < g.feed.size) {
            val n = g.feed[seen++]
            println("[%4ds ج%d] %-9s %s -> %s : %s".format(now / 1000, n.round, n.kind, n.from, n.to, n.text))
        }
    }
    val r = g.result!!
    println("النتيجة: نجوم=${r.stars} نافذة=${r.window} صحيح=${r.correct} محكم=${r.ironclad} قطع متبقية=${g.credits}")
    for (q in QIDS) println("  $q: إجابة=${g.answers[q]} حقيقة=${c.truth[q]} إحالات=${g.cites[q]!!.toList()} برهان=${c.proof[q]!![0]}")
}
