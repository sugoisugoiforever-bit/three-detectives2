package game

import java.io.File

var checks = 0
var failures = 0

fun check(cond: Boolean, msg: String) {
    checks++
    if (!cond) {
        failures++
        println("  ✗ $msg")
    }
}

fun section(name: String) = println("• $name")

fun loadLibrary(): CaseLibrary {
    val f = File("app/src/main/assets/cases.jsonl")
    return CaseLibrary(f.readLines().filter { it.isNotBlank() })
}

/** لعبة بكل مقاعدها بشرية فلا تتدخل البوتات (لاختبار القواعد بدقة). */
fun humanGame(c: Case, cfg: Config = Config(), seed: Int = 7): Game = Game(c, cfg, seed, 0L, setOf(0, 1, 2))

fun Game.allReady(now: Long) {
    for (s in 0..2) handle(s, Action.Ready(true), now)
}

/** يتخطى الجولات حتى نافذة الاتهام الأولى. */
fun Game.skipToAccuse(now: Long = 1000L) {
    while (phase == "round" && round <= 4) allReady(now)
}

/** يجعل المقعد 0 يرى كل الوثائق (للتحقق من الحكم دون ترتيب مشاركات). */
fun Game.godView() {
    for (d in c.docs) {
        seats[0].visible.add(d.id)
        copies.getOrPut(d.id) { HashSet() }.add(0)
    }
}

fun Game.fillTruth(seat: Int, pairIndex: Int = 0) {
    for (q in QIDS) {
        handle(seat, Action.Answer(q, c.truth[q]), 0L)
        val pair = c.proof[q]!![pairIndex.coerceAtMost(c.proof[q]!!.size - 1)]
        handle(seat, Action.Cite(q, 0, pair[0]), 0L)
        handle(seat, Action.Cite(q, 1, pair[1]), 0L)
    }
}

fun Game.approveAll(now: Long = 0L) {
    for (s in 0..2) handle(s, Action.Approve(true), now)
}
